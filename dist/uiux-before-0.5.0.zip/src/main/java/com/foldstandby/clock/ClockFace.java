package com.foldstandby.clock;

import android.content.*;
import android.animation.*;
import android.graphics.*;
import android.media.*;
import android.media.session.*;
import android.os.*;
import android.view.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import org.json.*;

public final class ClockFace extends View {
    private static final DateTimeFormatter FMT_24=DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter FMT_12=DateTimeFormatter.ofPattern("hh:mm");
    private static final DateTimeFormatter FMT_SEC=DateTimeFormatter.ofPattern("ss");
    private static final DateTimeFormatter FMT_DATE=DateTimeFormatter.ofPattern("M月d日  EEEE",Locale.SIMPLIFIED_CHINESE);
    private static final DateTimeFormatter FMT_MONTH=DateTimeFormatter.ofPattern("yyyy年 M月");
    private static final DateTimeFormatter FMT_WORLD=DateTimeFormatter.ofPattern("M月d日 · XXX");
    private static final DateTimeFormatter FMT_WEEKDAY=DateTimeFormatter.ofPattern("EEEE",Locale.SIMPLIFIED_CHINESE);
    private static final DateTimeFormatter FMT_SHORT_DATE=DateTimeFormatter.ofPattern("M月d日");
    private static final String[] WEEKDAYS={"一","二","三","四","五","六","日"};
    private static final float[] SIN_60=new float[60],COS_60=new float[60];
    static{for(int i=0;i<60;i++){double a=i*Math.PI/30;SIN_60[i]=(float)Math.sin(a);COS_60[i]=(float)Math.cos(a);}}
    private static final String[][] PREVIEW_SLOTS={
        {"split"},{"digital","date"},{"analog","weather"},{"music","digital"},{"analog","focus"},{"digital","weather","calendar","battery"}
    };

    private final Paint p=new Paint(3);
    private final Rect digitBounds=new Rect(),separatorBounds=new Rect();
    private final Shader[] unitGradients=new Shader[TextGradients.COLORS.length];
    private final Matrix gradientMatrix=new Matrix();
    private final float[] gradientValues=new float[9];
    private int cachedGradientId=-1;private float gradientLeft,gradientTop,gradientRight,gradientBottom;
    private int cachedYear=Integer.MIN_VALUE;private final int[] monthOffsets=new int[12],monthLengths=new int[12];
    private final Typeface regular=Typeface.create("sans-serif",Typeface.NORMAL);
    private final Typeface bold=Typeface.create("sans-serif",Typeface.BOLD);
    private final Typeface numbers=Typeface.create("sans-serif-condensed",Typeface.BOLD);
    private final RectF[] cells={new RectF(),new RectF(),new RectF(),new RectF()};
    private final RectF arcRect=new RectF(115,65,385,335);
    private final RectF batteryArc=new RectF();
    private final RectF barBgRect=new RectF(80,290,420,298);
    private final RectF barFgRect=new RectF();
    private final RectF artRect=new RectF(185,30,315,160);
    private final RectF cardRect=new RectF(12,12,488,388);
    private final Path artClip=new Path();
    private final Map<String,Sandglass> sandglasses=new HashMap<>();
    private final AlarmArtwork alarmArtwork=new AlarmArtwork();
    private final SharedPreferences prefs;
    private final Dashboard config;
    private int ink,muted; private boolean dark;
    private Scene scene; private Scene.Page page; private Scene.Component component;
    private boolean bound; private String loaded=""; private int pageIndex;
    private float pagePosition,sceneShiftX,sceneShiftY;private int pageMotionStyle;
    private ValueAnimator pageAnimator;private boolean motionActive=true;private int fadeFromPage=-1;private float fadeAmount;
    private final Runnable batteryChanged=this::invalidate;
    private final Runnable alarmChanged=()->{invalidate();if(this.externalTick)ClockActivity.onPostureOrDisplayChanged();};
    private int drawingSlot,pressedMusicSlot=-1,pressedMusicButton=-1,feedbackSlot=-1,feedbackButton=-1;private long feedbackAt;
    private final Path iconPath=new Path();
    private MediaController observedMedia;
    private static final int[] MUSIC_ACCESS_ACTIONS={0x01020001,0x01020002,0x01020003};
    private static final int ALARM_ACCESS_ACTION=0x01020004;
    private final MediaController.Callback mediaEvents=new MediaController.Callback(){public void onPlaybackStateChanged(PlaybackState state){invalidate();if(externalTick)ClockActivity.onPostureOrDisplayChanged();}public void onMetadataChanged(MediaMetadata metadata){invalidate();if(externalTick)ClockActivity.onPostureOrDisplayChanged();}public void onSessionDestroyed(){if(DeskData.media!=null&&(DeskData.media==observedMedia||(observedMedia!=null&&DeskData.media.getSessionToken().equals(observedMedia.getSessionToken()))))DeskData.media=null;invalidate();if(externalTick)ClockActivity.onPostureOrDisplayChanged();}};
    private void observeMedia(){MediaController next=null;if(isAttachedToWindow()&&DeskData.musicAllowed)for(int i=0;i<page.count();i++)if(page.slots[i].type.equals("music"))next=DeskData.media;if(next==observedMedia)return;if(next!=null&&observedMedia!=null&&next.getSessionToken().equals(observedMedia.getSessionToken()))return;if(observedMedia!=null)observedMedia.unregisterCallback(mediaEvents);observedMedia=next;if(next!=null)next.registerCallback(mediaEvents,handler);}
    Boolean nightPreview; long testTime=-1;boolean demo;
    private boolean longPressed;
    private final Runnable longPress=()->{if(isLongClickable())longPressed=performLongClick();};
    interface PageSwipe{void swipe(int direction);}
    PageSwipe pageSwipe; Runnable interaction;
    Runnable sceneChanged;
    private static final float TODO_TOP=82,TODO_BOTTOM=327,TODO_ROW=49;
    private final Map<String,Float> todoOffsets=new HashMap<>();
    private int todoTouchSlot=-1;
    private boolean todoDragging;
    private float todoDownOffset;
    private final Map<String,FlipState> flips=new HashMap<>();
    private final Camera camera=new Camera(); private final Matrix matrix=new Matrix();
    // Scene binding also serves the live clock; feedback is enabled only by its host.
    boolean flipFeedbackEnabled;
    private long soundMinute=-1,hapticMinute=-1; private ToneGenerator tone;
    private static final class FlipState {String old,value;long started;}
    private float downX,downY; private long downTime;
    interface SlotTap{void tap(int slot);}
    SlotTap slotTap;
    int previewPreset=-1;
    boolean externalTick;
    boolean managedRefresh;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable refresh=new Runnable(){public void run(){
        if(externalTick||managedRefresh)return;
        if(previewPreset<0&&!bound)DeskData.refresh(getContext(),false);
        invalidate();
        handler.postDelayed(this,nextDelayMs());
    }};
    public ClockFace(Context c){this(c,c.getSharedPreferences("clock",0));}
    ClockFace(Context c,SharedPreferences settings){
        super(c);prefs=settings;config=new Dashboard(settings);
        artClip.addRoundRect(artRect,16,16,Path.Direction.CW);
        setContentDescription("桌面时钟");
    }
    void bind(Scene value,int index){bound=true;scene=value;selectPage(Math.max(0,Math.min(index,value.pages.size()-1)));}
    private void cancelPageAnimator(){if(pageAnimator!=null){pageAnimator.removeAllListeners();pageAnimator.cancel();pageAnimator=null;}}
    void selectPage(int index){cancelPageAnimator();pageIndex=index;pagePosition=index;fadeFromPage=-1;flips.clear();pressedMusicSlot=-1;invalidate();}
    void animatePage(int index,int direction,int style,int duration){if(scene==null||index<0||index>=scene.pages.size())return;if(style==2||!motionActive||!prefs.getBoolean("motion",true)||!ValueAnimator.areAnimatorsEnabled()||!isAttachedToWindow()){selectPage(index);return;}int previous=fadeFromPage>=0&&fadeAmount<.5f?fadeFromPage:pageIndex;cancelPageAnimator();pageIndex=index;pageMotionStyle=style;fadeFromPage=style==1?previous:-1;fadeAmount=0;pressedMusicSlot=-1;float target=PageMotion.destination(pagePosition,index,direction,scene.pages.size());if(Math.abs(target-pagePosition)<.001f){selectPage(index);return;}pageAnimator=ValueAnimator.ofFloat(pagePosition,target);pageAnimator.setDuration(Math.max(120,Math.min(800,duration)));pageAnimator.setInterpolator(new android.view.animation.PathInterpolator(.22f,.75f,.25f,1f));pageAnimator.addUpdateListener(animation->{pagePosition=(float)animation.getAnimatedValue();fadeAmount=animation.getAnimatedFraction();invalidate();});pageAnimator.addListener(new AnimatorListenerAdapter(){public void onAnimationEnd(Animator animation){pageAnimator=null;pagePosition=pageIndex;fadeFromPage=-1;invalidate();}});pageAnimator.start();}
    boolean pageAnimatingForCheck(){return pageAnimator!=null;}
    float pagePositionForCheck(){return pagePosition;}
    void positionForCheck(float position,int style){cancelPageAnimator();pagePosition=position;pageMotionStyle=style;fadeFromPage=-1;invalidate();}
    void setMotionActive(boolean active){motionActive=active;if(!active){selectPage(pageIndex);handler.removeCallbacks(longPress);}invalidate();}
    private void resolve(){
        if(!bound){String json=prefs.getString(Scene.KEY,"");if(scene==null||json.isEmpty()||!json.equals(loaded)){scene=Scene.load(prefs);loaded=json;}pageIndex=Math.max(0,Math.min(pageIndex,scene.pages.size()-1));}
        page=scene.pages.get(pageIndex);config.layout=page.layout;for(int i=0;i<4;i++)config.slots[i]=page.slots[i].type;
    }
    private long wallTime(){return testTime>=0?testTime:System.currentTimeMillis();}
    private ZonedDateTime now(){return Instant.ofEpochMilli(wallTime()).atZone(ZoneId.systemDefault());}
    protected void onAttachedToWindow(){super.onAttachedToWindow();if(!managedRefresh){DeskData.observeBattery(getContext(),batteryChanged);AlarmData.observe(getContext(),alarmChanged);}handler.removeCallbacks(refresh);if(!externalTick&&!managedRefresh)handler.post(refresh);}
    protected void onDetachedFromWindow(){AlarmData.forget(getContext(),alarmChanged);DeskData.forgetBattery(getContext(),batteryChanged);if(observedMedia!=null){observedMedia.unregisterCallback(mediaEvents);observedMedia=null;}cancelPageAnimator();pagePosition=pageIndex;handler.removeCallbacksAndMessages(null);if(tone!=null){tone.release();tone=null;}super.onDetachedFromWindow();}
    protected void onWindowVisibilityChanged(int visibility){super.onWindowVisibilityChanged(visibility);if(visibility!=VISIBLE){cancelPageAnimator();pagePosition=pageIndex;}else invalidate();}
    long nextDelayMs(){
        long now=System.currentTimeMillis();
        if(previewPreset>=0)return 60000L-(now%60000L)+50L;
        resolve();
        boolean fast=false;for(int i=0;i<page.count();i++)if(page.slots[i].bool("seconds",false)&&!night())fast=true;
        if(!fast){
            boolean focusRunning=prefs.getLong("focusEnd",0)>0&&DeskData.remaining(prefs)>0;
            boolean musicPlaying=DeskData.isMusicPlaying();
            for(int i=0;i<config.count();i++){
                String s=config.slots[i];
                if((focusRunning&&"focus".equals(s))||(musicPlaying&&"music".equals(s))){fast=true;break;}
            }
        }
        return fast?(1000L-(now%1000L)+5L):(60000L-(now%60000L)+5L);
    }
    public boolean night(){if(nightPreview!=null)return nightPreview;LocalTime t=LocalTime.now();int minute=t.getHour()*60+t.getMinute(),start=prefs.getInt("nightStart",22)*60+prefs.getInt("nightStartMinute",0),end=prefs.getInt("nightEnd",7)*60+prefs.getInt("nightEndMinute",0);return prefs.getBoolean("night",true)&&(start<end?minute>=start&&minute<end:minute>=start||minute<end);}
    private int color(String role){return scene.color(page,component,role,dark,prefs.getBoolean("nightOwnColors",false));}
    private void inkShader(float l,float t,float r,float b){if(!dark&&scene!=null&&page!=null&&component!=null&&scene.gradient(page,component)>0)timeShader(l,t,r,b);else p.setShader(null);}
    private void txt(Canvas c,String s,float x,float y,float size,int color,Typeface font,float width){p.setStyle(Paint.Style.FILL);p.setTypeface(font);p.setTextSize(size);p.setTextAlign(Paint.Align.CENTER);p.setColor(color);if(p.measureText(s)>width)p.setTextSize(size*width/p.measureText(s));if(p.getShader()==null&&color==ink)inkShader(x-width/2,y-size,x+width/2,y);c.drawText(s,x,y,p);p.setShader(null);}
    private void timeText(Canvas c,String s,float x,float y,float size,float width){timeShader(x-width/2,y-size,x+width/2,y);txt(c,s,x,y,size,ink,font(component),width);p.setShader(null);}
    /** Keep the separator compact and vertically centered within the time numerals. */
    private void digitalTimeText(Canvas c,String s,float x,float y,float size,float width){
        int colon=s.indexOf(':');
        if(colon<0){timeText(c,s,x,y,size,width);return;}
        p.setStyle(Paint.Style.FILL);p.setTypeface(font(component));p.setTextSize(size);
        float hoursWidth=p.measureText(s,0,colon),minutesWidth=p.measureText(s,colon+1,s.length());
        p.setTextSize(size*.6f);float colonWidth=p.measureText(":");
        float measured=hoursWidth+colonWidth+minutesWidth,fit=Math.min(1f,width/Math.max(1f,measured));
        float left=x-measured*fit/2;
        p.setColor(ink);p.setTextAlign(Paint.Align.LEFT);p.setTextSize(size*fit);
        p.getTextBounds("0",0,1,digitBounds);
        timeShader(x-width/2,y-size,x+width/2,y);
        c.drawText(s,0,colon,left,y,p);
        c.drawText(s,colon+1,s.length(),left+(hoursWidth+colonWidth)*fit,y,p);
        p.setTextSize(size*.6f*fit);p.getTextBounds(":",0,1,separatorBounds);
        float baseline=y+(digitBounds.top+digitBounds.bottom-separatorBounds.top-separatorBounds.bottom)*.5f;
        c.drawText(":",left+hoursWidth*fit,baseline,p);
        p.setShader(null);
    }
    private void timeShader(float x,float y,float right,float bottom){
        int index=scene.gradient(page,component);
        if(dark||index==0){p.setShader(null);return;}
        Shader shader=unitGradients[index];
        if(shader==null){shader=TextGradients.unitShader(index);unitGradients[index]=shader;}
        if(cachedGradientId!=index||gradientLeft!=x||gradientTop!=y||gradientRight!=right||gradientBottom!=bottom){
            cachedGradientId=index;gradientLeft=x;gradientTop=y;gradientRight=right;gradientBottom=bottom;
            TextGradients.applyBounds(shader,gradientMatrix,gradientValues,x,y,right,bottom);
        }
        p.setShader(shader);
    }
    private void line(Canvas c,float x,float y,float ex,float ey,int color,float weight){p.setColor(color);p.setStrokeWidth(weight);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(x,y,ex,ey,p);}
    private String time(ZonedDateTime t){return t.format(component==null||component.bool("h24",true)?FMT_24:FMT_12);}
    private void header(Canvas c,String s){txt(c,s,250,48,20,muted,regular,430);}
    private void foot(Canvas c,String s){txt(c,s,250,365,18,muted,regular,430);}
    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        if(DeskData.systemStateAt==0)DeskData.updateSystemState(getContext(),true);
        resolve();
        observeMedia();
        canvas.drawColor(Color.BLACK);int lower=(int)Math.floor(pagePosition);float fraction=pagePosition-lower;
        if(fadeFromPage>=0&&pageAnimator!=null){drawFadedPage(canvas,fadeFromPage,1-fadeAmount);drawFadedPage(canvas,pageIndex,fadeAmount);}else if(fraction<.001f)drawPage(canvas,PageMotion.index(lower,scene.pages.size()));else{drawMovingPage(canvas,lower,1-fraction);drawMovingPage(canvas,lower+1,fraction);}
        resolve();
    }
    private void drawFadedPage(Canvas canvas,int index,float alpha){int save=canvas.saveLayerAlpha(0,0,getWidth(),getHeight(),Math.round(255*alpha));drawPage(canvas,index);canvas.restoreToCount(save);}
    private void drawMovingPage(Canvas canvas,int virtual,float visibility){int save=canvas.save();canvas.clipRect(0,0,getWidth(),getHeight());if(pageMotionStyle==1)canvas.saveLayerAlpha(0,0,getWidth(),getHeight(),Math.round(255*visibility));else{canvas.translate(0,(virtual-pagePosition)*getHeight());float scale=.985f+.015f*visibility;canvas.scale(scale,scale,getWidth()/2f,getHeight()/2f);}drawPage(canvas,PageMotion.index(virtual,scene.pages.size()));canvas.restoreToCount(save);}
    private void drawPage(Canvas canvas,int index){
        page=scene.pages.get(index);config.layout=page.layout;for(int i=0;i<4;i++)config.slots[i]=page.slots[i].type;
        if(previewPreset>=0){
            String[] ps=PREVIEW_SLOTS[previewPreset];
            System.arraycopy(ps,0,config.slots,0,ps.length);
            config.layout=previewPreset==0?0:previewPreset==5?3:1;
        }
        dark=night();component=null;
        float w=getWidth(),h=getHeight(),gap=Math.min(w,h)*.025f,pad=gap*1.4f;
        if(config.layout==0)cells[0].set(pad,pad,w-pad,h-pad);
        else if(config.layout==3){float cw=(w-2*pad-gap)/2,ch=(h-2*pad-gap)/2;for(int i=0;i<4;i++)cells[i].set(pad+(i%2)*(cw+gap),pad+(i/2)*(ch+gap),pad+(i%2)*(cw+gap)+cw,pad+(i/2)*(ch+gap)+ch);}
        else {float split=config.layout==2?.62f:.5f;float cw=(w-2*pad-gap)*split;cells[0].set(pad,pad,pad+cw,h-pad);cells[1].set(pad+cw+gap,pad,w-pad,h-pad);}
        long minute=System.currentTimeMillis()/60000L;
        float shiftX=externalTick?((minute%7)-3)*6f:0f;
        float shiftY=externalTick?(((minute/7)%5)-2)*7f:0f;
        sceneShiftX=shiftX;sceneShiftY=shiftY;
        for(int i=0;i<config.count();i++){
            drawingSlot=i;
            p.reset();p.setFlags(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
            component=page.slots[i];ink=color(component.type.equals("clock")||component.type.equals("world")?"time":"accent");muted=color("secondary");
            RectF r=cells[i];canvas.save();canvas.clipRect(r);
            float scale=Math.min(r.width()/540f,r.height()/432f);
            canvas.translate(r.centerX()+(shiftX-250f)*scale,r.centerY()+(shiftY-200f)*scale);
            canvas.scale(scale,scale);
            if(!component.type.equals("clock")){float cs=component.options.optInt("scale",100)/100f;if(Math.abs(cs-1f)>.001f){canvas.translate(250,200);canvas.scale(cs,cs);canvas.translate(-250,-200);}}
            if(!dark&&component.bool("card",!prefs.getBoolean("simple",true))){
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);
                p.setColor(color("plate"));
                canvas.drawRoundRect(cardRect,24,24,p);
                p.setStyle(Paint.Style.FILL);
            }
            if(component.type.equals("clock"))clock(canvas,component);else render(canvas,config.slots[i]);canvas.restore();
        }
    }
    private void render(Canvas c,String type){ZonedDateTime now=now();String date=now.format(FMT_DATE);
        switch(type){
            case "split": case "digital":
                if(prefs.getBoolean("date",true))header(c,date);
                if(type.equals("split")){
                    String[] t=time(now).split(":");txt(c,t[0],137,277,200,ink,numbers,215);txt(c,t[1],363,277,200,dark?ink:0xffe8eaf0,numbers,215);
                    p.setColor(ink);c.drawCircle(250,194,4,p);c.drawCircle(250,235,4,p);
                }else txt(c,time(now),250,263,158,ink,numbers,450);
                if(prefs.getBoolean("seconds",false)&&!dark)foot(c,now.format(FMT_SEC));else if(!prefs.getBoolean("h24",true))foot(c,now.getHour()<12?"上午":"下午");
                break;
            case "analog":
                for(int n=0;n<60;n++){float r=n%5==0?151:160;line(c,250+SIN_60[n]*r,200-COS_60[n]*r,250+SIN_60[n]*168,200-COS_60[n]*168,n%5==0?ink:muted,n%5==0?3:1);}
                hand(c,(now.getHour()%12+now.getMinute()/60f)*30,88,7,ink);hand(c,now.getMinute()*6,131,4,dark?ink:0xffeeeeed);
                if(prefs.getBoolean("seconds",false)&&!dark)hand(c,now.getSecond()*6,140,2,muted);
                p.setColor(ink);c.drawCircle(250,200,7,p);break;
            case "date":month(c,now);break;
            case "calendar":
                agenda(c);break;
            case "todo":todo(c);break;
            case "alarm":alarm(c,now);break;
            case "weather":weather(c);break;
            case "music":music(c);break;
            case "focus":
                focus(c);break;
            case "battery":battery(c);break;
            case "world":
                world(c,now);break;
        }
    }
    private Typeface font(Scene.Component slot){int f=slot.options.optInt("font",0);return f==1?regular:f==2?Typeface.MONOSPACE:f==3?Typeface.SERIF:numbers;}
    private void clock(Canvas c,Scene.Component slot){
        ZonedDateTime t=now();JSONObject o=slot.styleOptions();boolean seconds=slot.bool("seconds",false)&&!dark;
        String value=time(t);float size=slot.options.optInt("scale",100)/100f;
        c.save();c.translate(250,200);c.scale(size,size);c.translate(-250,-200);
        if(slot.style.equals("analog")||slot.style.equals("industrial")){analog(c,t,o,slot.style.equals("industrial"),seconds);c.restore();return;}
        if(slot.bool("date",true)&&!dark)txt(c,t.format(FMT_DATE),250,48,20,ink,regular,430);
        switch(slot.style){
            case "flip":
                String[] parts=value.split(":");flip(c,slot.id+"h",parts[0],20,94,216,228,170,o,true);flip(c,slot.id+"m",parts[1],264,94,216,228,170,o,true);
                p.setColor(ink);timeShader(20,94,480,322);c.drawCircle(250,189,3,p);c.drawCircle(250,226,3,p);p.setShader(null);
                if(seconds){if(o.optBoolean("flipSeconds",false))flip(c,slot.id+"s",t.format(FMT_SEC),216,334,68,49,38,o,true);else foot(c,t.format(FMT_SEC));}
                break;
            case "led":electronic(c,value,seconds?t.format(FMT_SEC):null,o,false);break;
            case "dot":electronic(c,value,seconds?t.format(FMT_SEC):null,o,true);break;
            default:if(seconds){digitalTimeText(c,value,208,260,142,360);timeText(c,t.format(FMT_SEC),438,260,54,72);}else digitalTimeText(c,value,250,260,158,450);
        }
        if(!seconds&&!slot.bool("h24",true))foot(c,t.getHour()<12?"上午":"下午");c.restore();
    }
    private void analog(Canvas c,ZonedDateTime t,JSONObject o,boolean industrial,boolean seconds){
        if(industrial&&!dark){p.setColor(Color.BLACK);c.drawRoundRect(67,17,433,383,24,24,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);p.setColor(color("plate"));c.drawRoundRect(67,17,433,383,24,24,p);p.setStyle(Paint.Style.FILL);}
        boolean major=o.optBoolean("major",true),minor=o.optBoolean("minor",true);int labels=o.optInt("labels",industrial?1:0);
        for(int n=0;n<60;n++){boolean hour=n%5==0;if(hour&&!major||!hour&&!minor)continue;float outer=164;
            float inner=outer-(hour?o.optInt("majorLength",industrial?19:15):o.optInt("minorLength",6));float weight=hour?o.optInt("majorWidth",industrial?5:3):o.optInt("minorWidth",1);
            if(hour)inkShader(86,36,414,364);line(c,250+SIN_60[n]*inner,200-COS_60[n]*inner,250+SIN_60[n]*outer,200-COS_60[n]*outer,color(hour?"major":"minor"),weight);p.setShader(null);
        }
        String[] roman={"XII","I","II","III","IV","V","VI","VII","VIII","IX","X","XI"};
        if(labels>0)for(int n=0;n<12;n++){if(labels==1&&n%3!=0)continue;int idx=n*5;float x=250+SIN_60[idx]*125,y=200-COS_60[idx]*125+8;txt(c,labels==3?roman[n]:String.valueOf(n==0?12:n),x,y,industrial?23:21,color("numerals"),font(component),54);}
        boolean smooth=seconds&&o.optBoolean("smooth",false);float sec=t.getSecond()+(smooth?t.getNano()/1000000000f:0);
        float strength=o.optInt("handWidth",industrial?9:6);
        inkShader(100,50,400,350);hand(c,(t.getHour()%12+t.getMinute()/60f)*30,labels>0?72:88,strength,color("hour"));hand(c,(t.getMinute()+sec/60f)*6,labels>0?109:131,Math.max(2,strength*.55f),color("minute"));p.setShader(null);
        if(seconds){hand(c,sec*6,143,industrial?2.5f:1.5f,color("second"));if(smooth&&testTime<0)animateEffect(33);}
        inkShader(240,190,260,210);p.setColor(color("hour"));c.drawCircle(250,200,industrial?8:6,p);p.setShader(null);if(component.bool("date",true)&&!dark)txt(c,t.format(FMT_DATE),250,382,12,ink,regular,400);
    }
    private void flip(Canvas c,String key,String value,float x,float y,float w,float h,float textSize,JSONObject o,boolean animate){
        long current=wallTime();FlipState f=flips.get(key);if(f==null){f=new FlipState();f.value=value;f.old=value;flips.put(key,f);}
        if(!value.equals(f.value)){f.old=f.value;f.value=value;f.started=current;
            flipFeedback(o,current);
        }
        float progress=Math.min(1,(current-f.started)/(float)o.optInt("duration",420));boolean moving=animate&&progress<1&&!f.old.equals(f.value)&&!dark;
        c.save();c.translate(x,y);p.setColor(Color.BLACK);c.drawRoundRect(0,0,w,h,12,12,p);
        if(!moving){flipHalf(c,value,w,h,textSize,0,false);flipHalf(c,value,w,h,textSize,1,false);}
        else{
            flipHalf(c,f.value,w,h,textSize,0,false);flipHalf(c,f.old,w,h,textSize,1,false);
            c.save();camera.save();camera.setLocation(0,0,-9);camera.rotateX(progress<.5f?-180*progress:180*(1-progress));camera.getMatrix(matrix);camera.restore();matrix.preTranslate(-w/2,-h/2);matrix.postTranslate(w/2,h/2);c.concat(matrix);
            int half=progress<.5f?0:1;flipHalf(c,half==0?f.old:f.value,w,h,textSize,half,true);p.setColor(Color.argb((int)(110*Math.sin(progress*Math.PI)),0,0,0));c.drawRect(0,half==0?0:h/2,w,half==0?h/2:h,p);c.restore();
            if(testTime<0)postInvalidateOnAnimation();
        }
        line(c,1,h/2,w-1,h/2,0xff070a0e,2);p.setColor(0xff414955);c.drawRoundRect(0,h/2-6,4,h/2+6,2,2,p);c.drawRoundRect(w-4,h/2-6,w,h/2+6,2,2,p);c.restore();
    }
    private void flipFeedback(JSONObject options,long current){
        if(!flipFeedbackEnabled||demo||dark||!motionActive||!isAttachedToWindow()||!isShown()||getWindowVisibility()!=VISIBLE||page!=scene.pages.get(pageIndex))return;
        long minute=current/60000;
        if(options.optBoolean("haptic",false)&&hapticMinute!=minute){
            hapticMinute=minute;
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        }
        if(options.optBoolean("sound",false)&&soundMinute!=minute){
            soundMinute=minute;
            try{
                if(tone==null)tone=new ToneGenerator(AudioManager.STREAM_MUSIC,25);
                tone.startTone(ToneGenerator.TONE_PROP_BEEP,35);
            }catch(RuntimeException error){
                android.util.Log.w("ClockFace","Unable to play flip sound",error);
            }
        }
    }
    private void flipHalf(Canvas c,String value,float w,float h,float textSize,int half,boolean moving){
        c.save();c.clipRect(0,half==0?0:h/2,w,half==0?h/2:h);p.setColor(Color.BLACK);c.drawRoundRect(0,0,w,h,12,12,p);
        p.setTypeface(font(component));p.setTextSize(textSize);p.setTextAlign(Paint.Align.CENTER);p.setColor(ink);float measured=p.measureText(value);if(measured>w-18)p.setTextSize(textSize*(w-18)/measured);
        Paint.FontMetrics fm=p.getFontMetrics();timeShader(0,0,w,h);c.drawText(value,w/2,h/2-(fm.ascent+fm.descent)/2,p);p.setShader(null);
        p.setColor(color("plate"));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);c.drawRoundRect(.5f,.5f,w-.5f,h-.5f,12,12,p);p.setStyle(Paint.Style.FILL);c.restore();
    }
    private static final int[] SEGMENTS={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};
    private void electronic(Canvas c,String value,String seconds,JSONObject o,boolean dot){c.save();if(seconds!=null){c.translate(0,32);c.scale(.8f,.8f);}if(dot)dots(c,value,o);else segments(c,value,o);c.restore();if(seconds!=null){c.save();c.translate(402,174);c.scale(.34f,.34f);if(dot)dots(c,seconds,o);else segments(c,seconds,o);c.restore();}}
    private void segments(Canvas c,String value,JSONObject o){
        float x=24,y=132,unit=1.5f;for(char ch:value.toCharArray()){
            if(ch==':'){p.setColor(ink);timeShader(24,132,460,260);c.drawCircle(x+12,y+40,4,p);c.drawCircle(x+12,y+94,4,p);p.setShader(null);x+=35;continue;}
            int bits=SEGMENTS[ch-'0'];float[][] lines={{9,3,42,3},{46,8,46,38},{46,46,46,76},{9,81,42,81},{4,46,4,76},{4,8,4,38},{9,42,42,42}};
            for(int i=0;i<7;i++){boolean on=(bits&(1<<i))!=0;int col=on?ink:(ink&0x00ffffff)|0x18000000;float[] l=lines[i];p.setStrokeCap(Paint.Cap.SQUARE);p.setStrokeWidth(o.optInt("thickness",5)*unit);p.setColor(col);if(on)timeShader(24,132,460,260);else p.setShader(null);c.drawLine(x+l[0]*unit,y+l[1]*unit,x+l[2]*unit,y+l[3]*unit,p);}x+=100;p.setShader(null);
        }
    }
    private static final String[] DOTS={"01110100011001110101110011000101110","00100011000010000100001000010001110","01110100010000100010001000100011111","11110000010000101110000010000111110","00010001100101010010111110001000010","11111100001111000001000011000101110","00110010001000011110100011000101110","11111000010001000100010000100001000","01110100011000101110100011000101110","01110100011000101111000010001001100"};
    private void dots(Canvas c,String value,JSONObject o){float start=28,top=133,step=17;for(char ch:value.toCharArray()){
        if(ch==':'){p.setColor(ink);timeShader(28,133,460,250);c.drawCircle(start+8,top+step*2,4,p);c.drawCircle(start+8,top+step*4,4,p);p.setShader(null);start+=34;continue;}
        String map=DOTS[ch-'0'];for(int row=0;row<7;row++)for(int col=0;col<5;col++){boolean on=map.charAt(row*5+col)=='1';p.setColor(on?ink:(ink&0x00ffffff)|0x12000000);if(on)timeShader(28,133,460,250);else p.setShader(null);float x=start+col*step,y=top+row*step,r=o.optInt("radius",4);if(o.optBoolean("square",false))c.drawRect(x-r,y-r,x+r,y+r,p);else c.drawCircle(x,y,r,p);}start+=100;p.setShader(null);}}
    private void hand(Canvas c,float angle,float length,float weight,int color){double a=Math.toRadians(angle);line(c,250,200,250+(float)Math.sin(a)*length,200-(float)Math.cos(a)*length,color,weight);}
    private String privateAgenda(boolean today){if(demo)return "09:30  规划今日\n14:00  项目讨论\n18:30  阅读";if(getContext().checkSelfPermission(android.Manifest.permission.READ_CALENDAR)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return "未授权日历";if(DeskData.keyguardLocked&&!prefs.getBoolean("private",false))return "解锁查看事项";String value=today?DeskData.todayAgenda:DeskData.agenda;return value.isEmpty()?"读取中":value;}
    private int variant(){return ComponentStyles.selectedIndex(component);}
    private void outline(Canvas c,float l,float t,float r,float b,float radius,int color,float width){
        p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(width);p.setColor(color);
        c.drawRoundRect(l,t,r,b,radius,radius,p);p.setStyle(Paint.Style.FILL);
    }
    private void primaryRect(Canvas c,float l,float t,float r,float b,float radius){
        if(r<=l||b<=t)return;p.setStyle(Paint.Style.FILL);p.setColor(ink);inkShader(l,t,r,b);
        c.drawRoundRect(l,t,r,b,radius,radius,p);p.setShader(null);
    }
    private void progress(Canvas c,float l,float y,float width,float fraction,float weight){
        line(c,l,y,l+width,y,(muted&0xffffff)|0x40000000,weight);
        if(fraction>0){inkShader(l,y-weight,l+width,y+weight);line(c,l,y,l+width*Math.min(1,fraction),y,ink,weight);p.setShader(null);}
    }
    private void agendaPreview(Canvas c,float y){
        if(component.bool("showAgenda",true))txt(c,shorten(privateAgenda(true).split("\n")[0],30),250,y,19,muted,regular,430);
    }
    private void dateVariant(Canvas c,ZonedDateTime now,int style){
        LocalDate today=now.toLocalDate();
        if(style==1){
            header(c,now.format(FMT_MONTH));
            timeText(c,String.format(Locale.ROOT,"%02d",today.getDayOfMonth()),250,234,176,400);
            txt(c,now.format(FMT_WEEKDAY),250,284,29,ink,regular,430);
            progress(c,100,311,300,today.getDayOfMonth()/(float)today.lengthOfMonth(),3);
            agendaPreview(c,365);
        }else if(style==2){
            header(c,now.format(FMT_MONTH));
            txt(c,now.format(FMT_DATE),250,112,34,ink,bold,430);
            LocalDate monday=today.minusDays(today.getDayOfWeek().getValue()-1);
            for(int i=0;i<7;i++){
                LocalDate day=monday.plusDays(i);float x=46+i*68;
                txt(c,WEEKDAYS[i],x,182,19,muted,regular,56);
                if(day.equals(today))primaryRect(c,x-27,202,x+27,260,15);
                txt(c,""+day.getDayOfMonth(),x,241,30,day.equals(today)?Color.BLACK:muted,numbers,50);
                if(day.getMonth()!=today.getMonth())txt(c,day.getMonthValue()+"月",x,286,13,muted,regular,56);
            }
            agendaPreview(c,352);
        }else{
            int year=today.getYear();
            if(year!=cachedYear){
                cachedYear=year;
                for(int m=1;m<=12;m++){
                    LocalDate first=today.withMonth(m).withDayOfMonth(1);
                    monthOffsets[m-1]=first.getDayOfWeek().getValue()-1;
                    monthLengths[m-1]=first.lengthOfMonth();
                }
            }
            header(c,year+" 年 · 全年一览");
            int normalColor=(muted&0xffffff)|0x78000000;
            for(int m=1;m<=12;m++){
                int col=(m-1)%4,row=(m-1)/4;float x=30+col*120,y=88+row*85;
                txt(c,m+"月",x+39,y,16,m==today.getMonthValue()?ink:muted,bold,95);
                int offset=monthOffsets[m-1],len=monthLengths[m-1];
                p.setShader(null);p.setColor(normalColor);
                for(int d=1;d<=len;d++){
                    int pos=offset+d-1;float dx=x+(pos%7)*13,dy=y+15+(pos/7)*8;
                    if(m==today.getMonthValue()&&d==today.getDayOfMonth()){
                        p.setColor(ink);inkShader(dx-4,dy-4,dx+4,dy+4);
                        c.drawCircle(dx,dy,4,p);
                        p.setShader(null);p.setColor(normalColor);
                    }else{
                        c.drawCircle(dx,dy,2,p);
                    }
                }
            }
            if(component.bool("showAgenda",true))agendaPreview(c,365);else foot(c,now.format(FMT_DATE));
        }
    }
    private void agenda(Canvas c){
        header(c,component.bool("agendaToday",false)?"今日事项":"接下来 24 小时");
        String value=privateAgenda(component.bool("agendaToday",false));
        String[] rows=value.split("\n");int style=variant();
        // Permission, privacy and empty-state messages never become fabricated agenda cards.
        if(!rows[0].contains("  ")){txt(c,rows[0],250,215,27,muted,regular,420);return;}
        if(style==3){
            String[] first=rows[0].split("  ",2);
            txt(c,"范围内首项",250,94,17,muted,regular,420);
            timeText(c,first[0],250,184,86,420);
            txt(c,first[1],250,249,35,ink,bold,430);
            line(c,180,283,320,283,color("plate"),2);
            txt(c,rows.length>1?"随后 · "+rows[1]:"暂无更多事项",250,333,20,muted,regular,430);
            return;
        }
        if(style==1)line(c,117,92,117,319,color("plate"),2);
        for(int i=0;i<Math.min(4,rows.length);i++){
            float y=113+i*65;String[] parts=rows[i].split("  ",2);
            if(style==0){
                txt(c,rows[i],250,y,26,i==0?ink:muted,regular,420);
                if(i<rows.length-1)line(c,40,y+24,460,y+24,color("plate"),1);
            }else if(style==1){
                txt(c,parts[0],64,y,21,muted,numbers,83);
                p.setColor(ink);inkShader(111,y-13,123,y-1);c.drawCircle(117,y-7,i==0?6:4,p);p.setShader(null);
                txt(c,parts.length>1?parts[1]:"日程",299,y,25,i==0?ink:muted,regular,320);
            }else{
                outline(c,30,y-34,470,y+20,12,i==0?ink:color("plate"),1.5f);
                txt(c,parts[0],91,y,23,ink,numbers,98);
                line(c,155,y-19,155,y+5,color("plate"),1);
                txt(c,parts.length>1?parts[1]:"日程",314,y,24,muted,regular,280);
            }
        }
    }
    private void alarm(Canvas c,ZonedDateTime now){
        AlarmData.State state=AlarmData.state;
        long trigger=demo?now.plusDays(1).withHour(7).withMinute(30).withSecond(0).withNano(0).toInstant().toEpochMilli():state.triggerAt;
        boolean available=demo||state.upcoming(wallTime());
        if(!available){
            header(c,"闹钟");alarmIcon(c,250,135,.85f);
            txt(c,state.unavailable?"闹钟暂不可用":"未设置闹钟",250,235,34,muted,regular,420);
            txt(c,state.unavailable?"可前往系统时钟查看":"添加闹钟后自动显示下次响铃",250,282,19,muted,regular,430);
            foot(c,state.unavailable?"轻触管理闹钟":"轻触设置闹钟");return;
        }
        ZonedDateTime at=Instant.ofEpochMilli(trigger).atZone(now.getZone());
        boolean h24=component.bool("h24",true),showDate=component.bool("alarmDate",true),countdown=component.bool("alarmCountdown",true);
        String value=AlarmData.time(at,h24),period=h24?"":" · "+AlarmData.period(at);
        String date=showDate?AlarmData.date(at,now):"";
        String remaining=countdown?"距响铃 "+AlarmData.remaining(trigger,wallTime()):"";
        int style=variant();
        header(c,"下次闹钟"+period);
        if(style==0){
            alarmIcon(c,250,109,.5f);
            timeText(c,value,250,240,132,440);
            txt(c,date,250,286,22,muted,regular,430);
            txt(c,remaining,250,324,22,ink,regular,430);
        }else if(style==1){
            alarmArtwork.palette(ink,muted,color("plate"),dark?0:scene.gradient(page,component));
            alarmArtwork.draw(c,250,175,1.02f,at.getHour(),at.getMinute(),true);
            timeText(c,value,250,292,30,190);
            txt(c,date,250,319,18,muted,regular,430);
            txt(c,remaining,250,342,18,ink,regular,430);
        }else if(style==2){
            long minutes=Math.max(1,(trigger-wallTime()+59999)/60000);
            String left=(minutes>=1440?minutes/1440+"天 ":"")+String.format(Locale.ROOT,"%02d:%02d",minutes/60%24,minutes%60);
            alarmIcon(c,250,111,.46f);
            timeText(c,countdown?left:value,250,227,106,440);
            txt(c,countdown?(trigger-wallTime()<60000?"即将响铃":"小时 : 分钟"):("响铃时刻"+period),250,266,21,muted,regular,420);
            txt(c,countdown?"响铃 "+value+period:"",250,307,25,ink,regular,430);
            txt(c,date,250,337,19,muted,regular,430);
        }else{
            outline(c,44,85,456,331,22,color("plate"),2);
            alarmIcon(c,116,164,.75f);
            txt(c,"响铃时刻",298,131,18,muted,regular,266);
            timeText(c,value,298,204,87,266);
            line(c,76,232,424,232,color("plate"),1.5f);
            txt(c,date,250,273,20,muted,regular,360);
            txt(c,remaining,250,309,22,ink,regular,360);
        }

    }
    private void alarmIcon(Canvas c,float x,float y,float size){
        alarmArtwork.palette(ink,muted,color("plate"),dark?0:scene.gradient(page,component));
        alarmArtwork.draw(c,x,y,size*.55f,10,10,false);
    }
    private void focus(Canvas c){
        header(c,"专注");
        int style=variant();
        long total=Math.max(1,prefs.getInt("focusMinutes",25))*60000L;
        long left=demo?total*3/5:DeskData.remaining(prefs);float fraction=Math.max(0,Math.min(1,left/(float)total));
        long frameTime=testTime>=0?testTime:SystemClock.elapsedRealtime(),resetAt=prefs.getLong("focusResetAt",-1);
        float resetFrom=prefs.getFloat("focusResetFrom",0);
        if(demo){
            resetAt=-1;
            if(style==3&&effectsEnabled()){
                long phase=frameTime%Sandglass.DEMO_CYCLE_MS;
                fraction=phase<Sandglass.DEMO_DRAIN_MS?1-phase/(float)Sandglass.DEMO_DRAIN_MS:1;
                left=Math.round(total*fraction);
                if(phase>=Sandglass.DEMO_DRAIN_MS){resetAt=frameTime-(phase-Sandglass.DEMO_DRAIN_MS);resetFrom=0;}
            }
        }
        String value=String.format(Locale.ROOT,"%02d:%02d",left/60000,(left/1000)%60);
        if(style==0){
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(6);p.setColor(color("plate"));c.drawArc(arcRect,-90,360,false,p);
            p.setColor(ink);inkShader(arcRect.left,arcRect.top,arcRect.right,arcRect.bottom);c.drawArc(arcRect,-90,360*fraction,false,p);p.setShader(null);p.setStyle(Paint.Style.FILL);
            timeText(c,value,250,222,65,250);
        }else if(style==1){
            timeText(c,value,250,232,129,440);
            progress(c,45,285,410,fraction,5);
            txt(c,"共 "+prefs.getInt("focusMinutes",25)+" 分钟",250,326,20,muted,regular,430);
        }else if(style==2){
            timeText(c,value,250,193,96,420);
            for(int i=0;i<20;i++){
                float x=43+i*21;
                if(i<Math.ceil(fraction*20))primaryRect(c,x,239,x+13,282,5);
                else outline(c,x,239,x+13,282,5,color("plate"),1);
            }
            txt(c,Math.round(fraction*100)+"% 剩余",250,324,20,muted,regular,420);
        }else{
            boolean running=prefs.getLong("focusEnd",0)>0&&left>0;
            Sandglass glass=sandglasses.get(component.id);
            if(glass==null){glass=new Sandglass();sandglasses.put(component.id,glass);}
            glass.palette(ink,muted,color("time"),color("plate"),dark?0:scene.gradient(page,component));
            if(glass.draw(c,fraction,demo||running,effectsEnabled(),frameTime,resetAt,resetFrom))animateEffect(33);
            boolean resetting=glass.isResetting();
            timeText(c,value,358,204,69,246);
            txt(c,"剩余 "+Math.round(fraction*100)+"%",358,248,21,muted,regular,246);
            txt(c,resetting?"翻转复位中":left==0?"沙已落尽":demo||running?"落沙中":fraction<.999f?"已暂停":"准备开始",358,280,16,muted,regular,246);
        }
        foot(c,demo?"预览":left==0?"已完成":prefs.getLong("focusEnd",0)>0?"专注中":"轻触开始 · 长按重置");
    }
    Sandglass sandglassForCheck(){return component==null?null:sandglasses.get(component.id);}
    private void world(Canvas c,ZonedDateTime local){
        String zone=component.options.optString("zone",prefs.getString("zone","Asia/Shanghai"));ZonedDateTime other;
        try{other=local.withZoneSameInstant(ZoneId.of(zone));}catch(Exception e){other=local;zone=local.getZone().getId();}
        String city=zone.substring(zone.lastIndexOf('/')+1).replace('_',' ');header(c,city);
        int style=variant();
        if(style==0)timeText(c,time(other),250,250,134,440);
        else if(style==1){
            float cx=250,cy=202,r=126;
            for(int i=0;i<60;i++){
                float inner=i%5==0?r-13:r-4;
                line(c,cx+SIN_60[i]*inner,cy-COS_60[i]*inner,cx+SIN_60[i]*r,cy-COS_60[i]*r,i%5==0?ink:color("plate"),i%5==0?3:1);
            }
            for(int i=1;i<=4;i++){int idx=(i*15)%60;txt(c,""+(i*3),cx+SIN_60[idx]*94,cy-COS_60[idx]*94+7,21,muted,numbers,40);}
            worldHand(c,cx,cy,(other.getHour()%12+other.getMinute()/60f)*30,64,7);
            worldHand(c,cx,cy,other.getMinute()*6,99,4);
            p.setColor(ink);c.drawCircle(cx,cy,6,p);txt(c,time(other),250,278,22,muted,numbers,140);
        }else if(style==2){
            txt(c,"所选时区",140,106,17,muted,regular,200);txt(c,"本地",368,106,17,muted,regular,200);
            timeText(c,time(other),140,208,79,208);timeText(c,time(local),368,208,79,208);
            line(c,254,92,254,278,color("plate"),2);
            txt(c,other.format(FMT_SHORT_DATE),140,258,21,muted,regular,205);
            txt(c,local.format(FMT_SHORT_DATE),368,258,21,muted,regular,205);
            long minutes=(other.getOffset().getTotalSeconds()-local.getOffset().getTotalSeconds())/60;
            txt(c,minutes==0?"与本地同一时刻":"比本地"+(minutes>0?"快 ":"慢 ")+Math.abs(minutes)/60+"小时"+(Math.abs(minutes)%60==0?"":Math.abs(minutes)%60+"分"),250,313,20,ink,regular,430);
        }else{
            RectF orbit=new RectF(115,67,385,337);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(color("plate"));c.drawOval(orbit,p);
            p.setColor(muted);c.drawArc(orbit,180,180,false,p);p.setStyle(Paint.Style.FILL);
            float hour=other.getHour()+other.getMinute()/60f;double a=Math.toRadians(hour*15+90);
            float x=250+(float)Math.cos(a)*135,y=202+(float)Math.sin(a)*135;
            p.setColor(ink);inkShader(x-8,y-8,x+8,y+8);c.drawCircle(x,y,8,p);p.setShader(null);
            timeText(c,time(other),250,217,76,249);
            txt(c,hour>=6&&hour<18?"日间 · 06—18 时":"夜间 · 18—06 时",250,255,18,muted,regular,240);
            txt(c,"12",250,91,14,muted,regular,30);txt(c,"00",250,320,14,muted,regular,30);
        }
        foot(c,other.format(FMT_WORLD));
    }
    private void worldHand(Canvas c,float cx,float cy,float angle,float length,float width){
        double a=Math.toRadians(angle);inkShader(cx-length,cy-length,cx+length,cy+length);
        line(c,cx,cy,cx+(float)Math.sin(a)*length,cy-(float)Math.cos(a)*length,ink,width);p.setShader(null);
    }
    private void month(Canvas c,ZonedDateTime now){if(variant()>0){dateVariant(c,now,variant());return;}boolean combined=component.bool("showAgenda",true);float center=combined?160:250,step=combined?41:62,left=combined?37:65;txt(c,now.format(FMT_MONTH),center,48,22,ink,bold,combined?280:430);LocalDate first=now.toLocalDate().withDayOfMonth(1);int offset=first.getDayOfWeek().getValue()-1;for(int i=0;i<7;i++)txt(c,WEEKDAYS[i],left+i*step,97,17,muted,regular,step-5);for(int day=1;day<=first.lengthOfMonth();day++){int pos=offset+day-1;float x=left+(pos%7)*step,y=141+(pos/7)*38;if(day==now.getDayOfMonth()){p.setColor(ink);inkShader(x-18,y-24,x+18,y+12);c.drawCircle(x,y-7,combined?15:18,p);p.setShader(null);}txt(c,""+day,x,y,combined?18:20,day==now.getDayOfMonth()?color("background"):muted,bold,step-5);}if(!combined)return;line(c,318,44,318,354,color("plate"),2);txt(c,"今日事项",405,78,20,ink,bold,154);String[] rows=privateAgenda(true).split("\n");for(int i=0;i<Math.min(3,rows.length);i++){String[] parts=rows[i].split("  ",2);float y=132+i*76;txt(c,parts[0],405,y,18,muted,regular,150);if(parts.length>1)txt(c,shorten(parts[1],12),405,y+28,20,ink,regular,150);}if(rows.length>3)txt(c,"另有 "+(rows.length-3)+" 项",405,355,15,muted,regular,150);}
    private void todo(Canvas c){
        if(!demo&&DeskData.keyguardLocked&&!prefs.getBoolean("private",false)){header(c,"待办");txt(c,"解锁查看待办",250,215,27,muted,regular,420);return;}
        JSONArray tasks=TodoItems.all(component);int style=variant(),completed=0;
        for(int i=0;i<tasks.length();i++)if(tasks.optJSONObject(i)!=null&&tasks.optJSONObject(i).optBoolean("done"))completed++;
        if(style==3){
            txt(c,"今日待办",130,47,24,ink,bold,180);
            txt(c,completed+" / "+tasks.length(),416,47,24,ink,numbers,110);
            progress(c,42,67,414,tasks.length()==0?0:completed/(float)tasks.length(),4);
        }else header(c,style==1?"待办卡片":style==2?"行动清单":"待办");
        if(tasks.length()==0){txt(c,"暂无待办",250,204,30,ink,regular,420);foot(c,"在组件编辑中添加");return;}
        int[] visible=TodoItems.visible(component);
        float offset=todoOffset(component);
        c.save();c.clipRect(29,TODO_TOP,470,TODO_BOTTOM);
        int first=Math.max(0,(int)(offset/TODO_ROW));
        int last=Math.min(visible.length,(int)Math.ceil((offset+TODO_BOTTOM-TODO_TOP)/TODO_ROW));
        for(int i=first;i<last;i++){
            JSONObject task=tasks.optJSONObject(visible[i]);if(task==null)continue;
            float y=112+i*TODO_ROW-offset;boolean done=task.optBoolean("done");
            if(style==1)outline(c,29,y-30,470,y+12,10,done?color("plate"):muted,1);
            if(style==2){
                txt(c,done?"✓":String.format(Locale.ROOT,"%02d",i+1),55,y,22,done?muted:ink,numbers,45);
                if(i<visible.length-1)line(c,88,y+15,459,y+15,color("plate"),1);
            }else{
                p.setColor(done?muted:ink);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);
                if(!done)inkShader(38,y-21,60,y+1);
                c.drawRoundRect(38,y-21,60,y+1,4,4,p);p.setShader(null);p.setStyle(Paint.Style.FILL);
                if(done){line(c,42,y-12,48,y-6,muted,2);line(c,48,y-6,57,y-17,muted,2);}
            }
            txt(c,shorten(task.optString("text"),26),276,y,25,done?muted:ink,regular,366);
            if(done)line(c,94,y-8,455,y-8,muted,1);
        }
        c.restore();
        if(visible.length>5){
            float track=TODO_BOTTOM-TODO_TOP,thumb=track*5f/visible.length;
            line(c,478,TODO_TOP,478,TODO_BOTTOM,color("plate"),2);
            float top=TODO_TOP+(track-thumb)*offset/todoMaxOffset(component);
            line(c,478,top,478,top+thumb,muted,3);
        }
        foot(c,completed+" / "+tasks.length()+" 已完成");
    }
    private void weather(Canvas c){header(c,demo?"天气预览":WeatherCities.simplified(prefs.getString("city","天气")));JSONObject w=DeskData.weather;
        if(demo){weatherContent(c,23,24,58,0,26,19,25,18);foot(c,"示例数据 · 选择城市后使用实况");return;}
        if(!prefs.contains("city")){txt(c,"选择城市",250,204,30,muted,regular,420);foot(c,"在组件编辑或设置中选择");return;}
        if(w==null){txt(c,DeskData.weatherBusy?"正在更新天气":DeskData.weatherError.isEmpty()?"等待天气更新":DeskData.weatherError,250,204,26,muted,regular,420);foot(c,"可在设置中重试，或使用经纬度设置城市");return;}
        try{JSONObject cur=w.getJSONObject("current"),daily=w.getJSONObject("daily");
            JSONArray highs=daily.getJSONArray("temperature_2m_max"),lows=daily.getJSONArray("temperature_2m_min");
            weatherContent(c,cur.getDouble("temperature_2m"),cur.optDouble("apparent_temperature",Double.NaN),cur.isNull("relative_humidity_2m")?-1:cur.optInt("relative_humidity_2m",-1),cur.optInt("weather_code",-1),highs.optDouble(0,Double.NaN),lows.optDouble(0,Double.NaN),highs.optDouble(1,Double.NaN),lows.optDouble(1,Double.NaN));
            boolean stale=System.currentTimeMillis()-DeskData.weatherAt>3600000||!DeskData.weatherError.isEmpty();foot(c,(stale?"已缓存 · ":"")+"Open-Meteo · "+Instant.ofEpochMilli(DeskData.weatherAt).atZone(ZoneId.systemDefault()).format(FMT_24));
        }catch(Exception e){txt(c,"天气不可用",250,220,28,muted,regular,420);}
    }
    private String temperature(double value){return Double.isFinite(value)?Math.round(prefs.getBoolean("fahrenheit",false)?value*1.8+32:value)+(prefs.getBoolean("fahrenheit",false)?"°F":"°"):"—";}
    private void weatherContent(Canvas c,double temp,double feels,int humidity,int code,double high,double low,double nextHigh,double nextLow){
        int style=variant();String condition=code<0?"天气未知":DeskData.condition(code);
        String apparent="体感 "+temperature(feels),wet="湿度 "+(humidity<0?"—":humidity+"%");
        String range="↑ "+temperature(high)+"    ↓ "+temperature(low);
        String detail=component.bool("tomorrow",false)?"明日  "+temperature(nextLow)+" — "+temperature(nextHigh):wet+"  ·  "+range;
        if(style==0){
            timeText(c,temperature(temp),250,202,105,420);
            txt(c,condition+" · "+apparent,250,253,24,muted,regular,420);
            txt(c,detail,250,308,21,muted,regular,430);
        }else if(style==1){
            weatherIcon(c,126,168,code);
            timeText(c,temperature(temp),332,205,96,250);
            txt(c,condition+" · "+apparent,250,271,24,muted,regular,420);
            txt(c,detail,250,316,21,muted,regular,430);
        }else if(style==2){
            timeText(c,temperature(temp),161,181,95,244);
            txt(c,condition,375,143,27,ink,bold,170);txt(c,apparent,375,181,20,muted,regular,180);
            line(c,286,88,286,199,color("plate"),2);
            outline(c,36,228,464,289,12,color("plate"),1.5f);
            txt(c,wet,139,267,23,ink,regular,194);txt(c,range,352,267,23,ink,regular,194);
            txt(c,component.bool("tomorrow",false)?detail:"当前实况 · "+apparent,250,326,20,muted,regular,430);
        }else{
            timeText(c,temperature(temp),250,177,102,420);
            txt(c,condition+" · "+apparent,250,219,21,muted,regular,420);
            line(c,62,266,438,266,color("plate"),5);
            for(int i=0;i<=10;i++)line(c,62+i*37.6f,258,62+i*37.6f,274,muted,1);
            if(Double.isFinite(high)&&Double.isFinite(low)&&Double.isFinite(temp)){
                float fraction=high==low?.5f:(float)Math.max(0,Math.min(1,(temp-low)/(high-low)));
                primaryRect(c,54+376*fraction,253,70+376*fraction,279,7);
            }
            txt(c,temperature(low),81,308,24,muted,numbers,100);txt(c,temperature(high),419,308,24,muted,numbers,100);
            txt(c,component.bool("tomorrow",false)?detail:"当日低温 — 高温",250,310,18,muted,regular,220);
        }
    }
    private void weatherIcon(Canvas c,float x,float y,int code){
        if(code<0){txt(c,"?",x,y+20,80,muted,numbers,140);return;}
        if(code<=3){
            float sx=code==0?x:x-22,sy=code==0?y:y-23;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(ink);inkShader(x-80,y-80,x+80,y+80);c.drawCircle(sx,sy,29,p);
            for(int i=0;i<8;i++){double a=i*Math.PI/4;line(c,sx+(float)Math.cos(a)*42,sy+(float)Math.sin(a)*42,sx+(float)Math.cos(a)*54,sy+(float)Math.sin(a)*54,ink,3);}p.setShader(null);p.setStyle(Paint.Style.FILL);
            if(code==0)return;
        }
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(ink);inkShader(x-80,y-65,x+80,y+65);
        iconPath.reset();iconPath.moveTo(x-49,y+26);iconPath.cubicTo(x-83,y+22,x-69,y-25,x-40,y-18);iconPath.cubicTo(x-33,y-62,x+25,y-60,x+34,y-18);iconPath.cubicTo(x+72,y-28,x+82,y+25,x+48,y+26);iconPath.close();c.drawPath(iconPath,p);p.setShader(null);p.setStyle(Paint.Style.FILL);
        if(code>=45&&code<=48){for(int i=0;i<2;i++)line(c,x-49,y+43+i*14,x+49,y+43+i*14,muted,3);}
        else if(code>=71&&code<=77||code>=85&&code<=86){for(int i=0;i<3;i++){float sx=x-34+i*34;line(c,sx-5,y+48,sx+5,y+48,ink,2);line(c,sx,y+43,sx,y+53,ink,2);}}
        else if(code>=95){line(c,x+1,y+35,x-16,y+59,ink,4);line(c,x-16,y+59,x+8,y+59,ink,4);line(c,x+8,y+59,x-3,y+78,ink,4);}
        else if(code>=51){for(int i=0;i<3;i++)line(c,x-33+i*34,y+43,x-40+i*34,y+58,ink,3);}
    }
    private boolean effectsEnabled(){return motionActive&&prefs.getBoolean("motion",true)&&ValueAnimator.areAnimatorsEnabled()&&!night();}
    boolean chargingAnimationForCheck(){return (demo||DeskData.batteryCharging)&&(demo||!DeskData.batteryFull)&&effectsEnabled();}
    private void animateEffect(long delay){if(testTime<0&&isAttachedToWindow()&&getWindowVisibility()==VISIBLE&&isShown()&&effectsEnabled())postInvalidateDelayed(delay);}
    private void batteryVariant(Canvas c){
        int level=demo?76:Math.max(0,Math.min(100,DeskData.batteryLevel));
        boolean full=!demo&&DeskData.batteryFull,charging=demo||DeskData.batteryCharging;
        int accent=level<=20&&!dark?0xffff987d:ink,style=variant();
        String status=full?"已充满":charging?"正在充电":DeskData.batteryPlugged?"已连接电源":"电池供电";
        header(c,"电量");float fillLeft=50,fillRight=450,fillY=277;
        if(style==1){
            outline(c,59,101,428,209,19,muted,3);line(c,442,133,442,177,muted,7);
            energyRect(c,69,111,69+349*level/100f,199,11,accent);
            txt(c,level+"%",250,292,76,accent,numbers,420);
            fillLeft=69;fillRight=418;fillY=155;
        }else if(style==2){
            txt(c,level+"%",250,233,153,accent,numbers,430);
            line(c,50,277,450,277,color("plate"),5);
            if(level>0){if(accent==ink)inkShader(50,272,450,282);line(c,50,277,50+4*level,277,accent,5);p.setShader(null);}
        }else{
            for(int i=0;i<10;i++){
                float x=45+i*42;
                if(i<Math.ceil(level/10f))energyRect(c,x,111,x+31,195,7,accent);
                else outline(c,x,111,x+31,195,7,color("plate"),1.5f);
            }
            txt(c,level+"%",250,285,82,accent,numbers,420);
            fillLeft=45;fillRight=454;fillY=216;
        }
        txt(c,(charging&&!full?"ϟ  ":"")+status,250,329,24,accent,bold,430);
        foot(c,demo?"充电效果预览":String.format(Locale.ROOT,"电池温度 %.1f°C",DeskData.batteryTempTenths/10f));
        if(charging&&!full&&effectsEnabled()&&level>0){
            float x=fillLeft+(fillRight-fillLeft)*level/100f*(wallTime()%2400L/2400f);
            p.setColor(accent);c.drawCircle(x,fillY,style==1?5:3,p);animateEffect(33);
        }
    }
    private void energyRect(Canvas c,float l,float t,float r,float b,float radius,int accent){
        if(r<=l)return;p.setStyle(Paint.Style.FILL);p.setColor(accent);if(accent==ink)inkShader(l,t,r,b);
        c.drawRoundRect(l,t,r,b,radius,radius,p);p.setShader(null);
    }
    private void battery(Canvas c){if(variant()>0){batteryVariant(c);return;}int level=demo?76:DeskData.batteryLevel;boolean full=!demo&&DeskData.batteryFull,charging=demo||DeskData.batteryCharging,plugged=demo||DeskData.batteryPlugged;int accent=level<=20&&!dark?0xffff987d:ink;boolean useGrad=accent==ink;header(c,"电量");batteryArc.set(64,84,296,316);p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(7);p.setColor((muted&0xffffff)|0x46000000);c.drawArc(batteryArc,135,270,false,p);p.setColor(accent);if(level>0){if(useGrad)inkShader(batteryArc.left,batteryArc.top,batteryArc.right,batteryArc.bottom);c.drawArc(batteryArc,135,270*level/100f,false,p);p.setShader(null);}p.setStyle(Paint.Style.FILL);txt(c,String.valueOf(level),172,222,84,accent,numbers,195);txt(c,"%",250,220,23,muted,regular,35);
        String status=full?"已充满":charging?"正在充电":plugged?"已连接电源":"电池供电";txt(c,status,384,173,25,accent,bold,170);txt(c,full?"电量已就绪":charging?"能量补充中":plugged?"当前未充电":level<=20?"建议连接充电器":"可继续使用",384,210,18,muted,regular,170);
        float bx=360,by=247;p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(accent);if(useGrad)inkShader(bx,by,bx+46,by+23);c.drawRoundRect(bx,by,bx+43,by+23,5,5,p);line(c,bx+46,by+8,bx+46,by+15,accent,3);p.setStyle(Paint.Style.FILL);if(level>0){p.setColor(accent);c.drawRoundRect(bx+4,by+4,bx+4+35*level/100f,by+19,2,2,p);}p.setShader(null);if(charging){iconPath.reset();iconPath.moveTo(184,264);iconPath.lineTo(169,285);iconPath.lineTo(180,285);iconPath.lineTo(175,300);iconPath.lineTo(193,277);iconPath.lineTo(182,277);iconPath.close();p.setColor(accent);if(useGrad)inkShader(165,260,196,302);c.drawPath(iconPath,p);p.setShader(null);if(effectsEnabled()&&!full){float phase=wallTime()%2400L/2400f,angle=-90+360*phase;batteryArc.set(54,74,306,326);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.5f);p.setColor((accent&0xffffff)|0xaa000000);if(useGrad)inkShader(batteryArc.left,batteryArc.top,batteryArc.right,batteryArc.bottom);c.drawArc(batteryArc,angle-20,20,false,p);p.setStyle(Paint.Style.FILL);double rad=Math.toRadians(angle);c.drawCircle(180+(float)Math.cos(rad)*126,200+(float)Math.sin(rad)*126,4,p);p.setShader(null);animateEffect(33);}}
        foot(c,demo?"充电动画预览":full?"电量 100%":String.format(Locale.ROOT,"电池温度 %.1f°C",DeskData.batteryTempTenths/10f));
    }
    private void music(Canvas c){MediaController controller=DeskData.media;MediaMetadata meta=controller==null||!demo&&!DeskData.musicAllowed?null:controller.getMetadata();PlaybackState state=controller==null?null:controller.getPlaybackState();boolean available=demo||DeskData.musicAllowed&&meta!=null,playing=demo||state!=null&&state.getState()==PlaybackState.STATE_PLAYING;long actions=demo?~0L:state==null?0:state.getActions();Bitmap art=demo||meta==null?null:meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);if(art==null&&meta!=null&&!demo)art=meta.getBitmap(MediaMetadata.METADATA_KEY_ART);
        String title=demo?"夜行 · Nightfall":meta==null?(DeskData.musicAllowed?"暂无播放":"音乐未授权"):meta.getString(MediaMetadata.METADATA_KEY_TITLE),artist=demo?"音乐组件预览":meta==null?(DeskData.musicAllowed?"在播放器中选择音乐":"在设置中开启音乐访问"):meta.getString(MediaMetadata.METADATA_KEY_ARTIST);
        musicVisual(c,art,title,artist,available,playing);
        long duration=demo?213000:meta==null?0:meta.getLong(MediaMetadata.METADATA_KEY_DURATION),pos=demo?74000:state==null?0:Math.max(0,state.getPosition());if(!demo&&playing&&state!=null&&state.getLastPositionUpdateTime()>0)pos+=(long)(Math.max(0,SystemClock.elapsedRealtime()-state.getLastPositionUpdateTime())*Math.max(0,state.getPlaybackSpeed()));pos=Math.max(0,duration>0?Math.min(pos,duration):pos);line(c,54,202,446,202,(muted&0xffffff)|0x60000000,3);if(duration>0){float end=54+392*pos/(float)duration;inkShader(54,190,446,214);line(c,54,202,end,202,ink,3);p.setColor(ink);c.drawCircle(end,202,4,p);p.setShader(null);}txt(c,available?MediaControls.time(pos):"—:—",82,237,16,muted,regular,90);txt(c,duration>0?MediaControls.time(duration):"—:—",418,237,16,muted,regular,90);
        for(int button=0;button<3;button++)musicButton(c,button,playing,available&&MediaControls.enabled(actions,playing,button));
    }
    private void musicVisual(Canvas c,Bitmap art,String title,String artist,boolean available,boolean playing){
        int style=variant();String status=available?(playing?"正在播放":"已暂停"):"音乐";
        if(style==0){
            coverArt(c,art,42,42,144,144,false);
            txt(c,shorten(title,40),320,80,26,available?ink:muted,bold,290);
            txt(c,shorten(artist,44),320,116,18,muted,regular,290);
            txt(c,status,320,150,14,muted,regular,290);
        }else if(style==1){
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);
            for(int r=40;r<=76;r+=6){p.setColor(r==76?muted:color("plate"));c.drawCircle(117,105,r,p);}p.setStyle(Paint.Style.FILL);
            coverArt(c,art,84,72,150,138,true);
            p.setColor(Color.BLACK);c.drawCircle(117,105,5,p);
            line(c,179,37,198,44,muted,3);line(c,198,44,180,121,muted,3);line(c,180,121,170,129,ink,5);
            txt(c,shorten(title,40),350,85,30,available?ink:muted,bold,247);
            txt(c,shorten(artist,44),350,124,18,muted,regular,247);
            txt(c,status,350,157,14,muted,regular,247);
        }else if(style==2){
            txt(c,status+"  /  MUSIC",250,44,15,muted,regular,430);
            txt(c,shorten(title,60),250,117,51,available?ink:muted,bold,428);
            txt(c,shorten(artist,60),250,163,23,muted,regular,430);
        }else{
            txt(c,shorten(title,50),250,61,31,available?ink:muted,bold,430);
            txt(c,shorten(artist,60),250,94,18,muted,regular,430);
            boolean moving=available&&playing&&effectsEnabled();float phase=moving?wallTime()%3200L/3200f:0;
            for(int i=0;i<31;i++){
                float wave=(float)(.5+.5*Math.sin(i*1.37+phase*Math.PI*2));
                float height=available&&playing?12+wave*48:5;
                primaryRect(c,52+i*13,149-height/2,58+i*13,149+height/2,3);
            }
            if(moving)animateEffect(80);
        }
    }
    private void coverArt(Canvas c,Bitmap art,float l,float t,float r,float b,boolean round){
        artRect.set(l,t,r,b);float radius=round?(r-l)/2:18;
        p.setShader(null);p.setStyle(Paint.Style.FILL);p.setAlpha(255);
        if(art!=null&&!dark){artClip.reset();artClip.addRoundRect(artRect,radius,radius,Path.Direction.CW);int save=c.save();c.clipPath(artClip);c.drawBitmap(art,null,artRect,p);c.restoreToCount(save);}
        else{
            outline(c,l,t,r,b,radius,muted,1.5f);float cx=(l+r)/2,cy=(t+b)/2,s=(r-l)/102;
            inkShader(l,t,r,b);line(c,cx-10*s,cy+15*s,cx-10*s,cy-23*s,ink,3*s);line(c,cx-10*s,cy-23*s,cx+18*s,cy-29*s,ink,3*s);line(c,cx+18*s,cy-29*s,cx+18*s,cy+7*s,ink,3*s);
            p.setColor(ink);c.drawOval(cx-24*s,cy+10*s,cx-9*s,cy+21*s,p);c.drawOval(cx+4*s,cy+2*s,cx+19*s,cy+13*s,p);p.setShader(null);
        }
    }
    private void musicButton(Canvas c,int button,boolean playing,boolean enabled){float x=MediaControls.X[button],y=MediaControls.Y,radius=button==1?43:31;int foreground=enabled?ink:(muted&0xffffff)|0x68000000;boolean pressed=pressedMusicSlot==drawingSlot&&pressedMusicButton==button;float feedback=feedbackSlot==drawingSlot&&feedbackButton==button?Math.max(0,1-(SystemClock.uptimeMillis()-feedbackAt)/220f):0;c.save();if(pressed)c.scale(.94f,.94f,x,y);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(button==1?2.5f:1.5f);p.setColor(button==1?foreground:(muted&0xffffff)|0x80000000);if(button==1&&enabled)inkShader(x-radius,y-radius,x+radius,y+radius);c.drawCircle(x,y,radius,p);p.setShader(null);if((pressed||feedback>0)&&enabled){p.setStrokeWidth(2);p.setColor((ink&0xffffff)|((int)(160*(pressed?1:feedback))<<24));c.drawCircle(x,y,radius+5+(1-feedback)*4,p);if(!pressed)animateEffect(16);}p.setStyle(Paint.Style.FILL);p.setColor(foreground);if(button==1&&enabled)inkShader(x-radius,y-radius,x+radius,y+radius);if(button==1&&playing){c.drawRoundRect(x-10,y-13,x-3,y+13,2,2,p);c.drawRoundRect(x+3,y-13,x+10,y+13,2,2,p);}else{iconPath.reset();if(button==0){iconPath.moveTo(x+9,y-10);iconPath.lineTo(x-6,y);iconPath.lineTo(x+9,y+10);}else{iconPath.moveTo(x-(button==1?7:9),y-(button==1?14:10));iconPath.lineTo(x+(button==1?13:6),y);iconPath.lineTo(x-(button==1?7:9),y+(button==1?14:10));}iconPath.close();c.drawPath(iconPath,p);if(button!=1)c.drawRoundRect(button==0?x-12:x+9,y-11,button==0?x-8:x+13,y+11,1,1,p);}p.setShader(null);c.restore();}
    private int musicHit(int slot,float x,float y){RectF r=cells[slot];float scale=Math.min(r.width()/540f,r.height()/432f);float cs=page.slots[slot].type.equals("clock")?1f:page.slots[slot].options.optInt("scale",100)/100f;return MediaControls.hit(250+((x-r.centerX())/scale-sceneShiftX)/cs,200+((y-r.centerY())/scale-sceneShiftY)/cs);}
    private boolean musicAction(int button){MediaController controller=DeskData.media;if(demo||!DeskData.musicAllowed||controller==null)return false;PlaybackState state=controller.getPlaybackState();boolean playing=state!=null&&state.getState()==PlaybackState.STATE_PLAYING;if(state==null||!MediaControls.enabled(state.getActions(),playing,button))return false;MediaController.TransportControls controls=controller.getTransportControls();try{if(button==0)controls.skipToPrevious();else if(button==2)controls.skipToNext();else if(playing)controls.pause();else controls.play();return true;}catch(SecurityException error){return false;}}
    private String shorten(String s,int n){if(s==null)return "";return s.length()>n?s.substring(0,n-1)+"…":s;}
    private float todoMaxOffset(Scene.Component item){return Math.max(0,TodoItems.visible(item).length*TODO_ROW-(TODO_BOTTOM-TODO_TOP));}
    private float todoOffset(Scene.Component item){
        float value=Math.max(0,Math.min(todoMaxOffset(item),todoOffsets.getOrDefault(item.id,0f)));
        todoOffsets.put(item.id,value);return value;
    }
    private float componentScale(int slot){
        RectF r=cells[slot];return Math.min(r.width()/540f,r.height()/432f)*page.slots[slot].options.optInt("scale",100)/100f;
    }
    private float componentX(int slot,float x){float cs=page.slots[slot].options.optInt("scale",100)/100f;return 250+(x-cells[slot].centerX())/componentScale(slot)-sceneShiftX/cs;}
    private float componentY(int slot,float y){float cs=page.slots[slot].options.optInt("scale",100)/100f;return 200+(y-cells[slot].centerY())/componentScale(slot)-sceneShiftY/cs;}
    private boolean todoAllowed(){return !DeskData.keyguardLocked||prefs.getBoolean("private",false);}
    private void scrollTodoTouch(float y){
        Scene.Component item=page.slots[todoTouchSlot];
        float value=todoDownOffset-(y-downY)/componentScale(todoTouchSlot);
        todoOffsets.put(item.id,Math.max(0,Math.min(todoMaxOffset(item),value)));invalidate();
    }
    private void releaseTodoTouch(){todoTouchSlot=-1;todoDragging=false;if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);}
    public boolean onTouchEvent(MotionEvent e){
        int action=e.getActionMasked();
        if(action==MotionEvent.ACTION_DOWN){
            resolve();downX=e.getX();downY=e.getY();downTime=SystemClock.uptimeMillis();longPressed=false;
            releaseTodoTouch();
            if(isLongClickable())handler.postDelayed(longPress,ViewConfiguration.getLongPressTimeout());
            if(interaction!=null)interaction.run();pressedMusicSlot=-1;
            if(slotTap==null&&!pageAnimatingForCheck())for(int i=0;i<config.count();i++){
                if(!cells[i].contains(downX,downY))continue;
                if(config.slots[i].equals("music")){
                    int hit=musicHit(i,downX,downY);if(hit>=0){pressedMusicSlot=i;pressedMusicButton=hit;invalidate();}
                }else if(config.slots[i].equals("todo")&&!demo&&todoAllowed()&&todoMaxOffset(page.slots[i])>0){
                    float x=componentX(i,downX),y=componentY(i,downY);
                    if(x>=29&&x<=482&&y>=TODO_TOP&&y<TODO_BOTTOM){todoTouchSlot=i;todoDownOffset=todoOffset(page.slots[i]);}
                }
                break;
            }
            return true;
        }
        if(action==MotionEvent.ACTION_CANCEL){handler.removeCallbacks(longPress);pressedMusicSlot=-1;releaseTodoTouch();invalidate();return true;}
        float dx=e.getX()-downX,dy=e.getY()-downY;
        int slop=ViewConfiguration.get(getContext()).getScaledTouchSlop();
        if(action==MotionEvent.ACTION_MOVE){
            if(Math.abs(dy)+Math.abs(dx)>slop)handler.removeCallbacks(longPress);
            if(todoTouchSlot>=0&&(todoDragging||Math.abs(dy)>slop&&Math.abs(dy)>Math.abs(dx)*1.25f)){
                todoDragging=true;
                if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);
                scrollTodoTouch(e.getY());if(interaction!=null)interaction.run();return true;
            }
        }
        if(action==MotionEvent.ACTION_UP){
            handler.removeCallbacks(longPress);
            if(longPressed){releaseTodoTouch();return true;}
            if(todoTouchSlot>=0&&(todoDragging||Math.abs(dy)>slop&&Math.abs(dy)>Math.abs(dx)*1.25f)){
                scrollTodoTouch(e.getY());releaseTodoTouch();return true;
            }
            releaseTodoTouch();
            float threshold=40*getResources().getDisplayMetrics().density;
            if(Math.abs(dy)>threshold&&Math.abs(dy)>Math.abs(dx)*1.25f&&pageSwipe!=null){pressedMusicSlot=-1;pageSwipe.swipe(dy<0?1:-1);return true;}
            if(Math.abs(dx)+Math.abs(dy)>slop){pressedMusicSlot=-1;invalidate();return true;}
            if(pageAnimatingForCheck())return true;
            if(previewPreset>=0||demo&&hasOnClickListeners()){performClick();return true;}
            for(int i=0;i<config.count();i++)if(cells[i].contains(e.getX(),e.getY())){
                if(slotTap!=null){slotTap.tap(i);return true;}
                String type=config.slots[i];
                if(type.equals("todo")&&todoAllowed()){
                    Scene.Component item=page.slots[i];float x=componentX(i,e.getX()),y=componentY(i,e.getY());
                    int[] ordered=TodoItems.visible(item);int index=(int)Math.floor((y-TODO_TOP+todoOffset(item))/TODO_ROW);
                    if(x>=29&&x<=470&&y>=TODO_TOP&&y<TODO_BOTTOM&&index>=0&&index<ordered.length){
                        TodoItems.toggle(item,ordered[index]);
                        if(sceneChanged!=null)sceneChanged.run();else if(!bound)scene.save(prefs);
                        invalidate();
                    }
                    return true;
                }
                if(type.equals("focus")&&e.getY()>cells[i].centerY()){
                    if(SystemClock.uptimeMillis()-downTime>600)DeskData.resetFocus(prefs);else DeskData.toggleFocus(prefs);invalidate();return true;
                }
                if(type.equals("alarm")){if(!demo)AlarmData.openNext(getContext());return true;}
                if(type.equals("music")){
                    int hit=musicHit(i,e.getX(),e.getY());
                    if(pressedMusicSlot==i&&hit==pressedMusicButton&&musicAction(hit)){feedbackSlot=i;feedbackButton=hit;feedbackAt=SystemClock.uptimeMillis();}
                    pressedMusicSlot=-1;invalidate();return true;
                }
            }
            performClick();return true;
        }
        return true;
    }
    public boolean performClick(){super.performClick();return true;}
    public void onInitializeAccessibilityNodeInfo(android.view.accessibility.AccessibilityNodeInfo info){
        super.onInitializeAccessibilityNodeInfo(info);if(demo||slotTap!=null||pageAnimatingForCheck())return;resolve();
        boolean music=false,alarm=false;for(int i=0;i<page.count();i++){music|=page.slots[i].type.equals("music");alarm|=page.slots[i].type.equals("alarm");}
        if(todoAllowed())for(int i=0;i<page.count();i++)if(page.slots[i].type.equals("todo")&&todoMaxOffset(page.slots[i])>0){
            Scene.Component item=page.slots[i];info.setScrollable(true);
            if(todoOffset(item)<todoMaxOffset(item))info.addAction(android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD);
            if(todoOffset(item)>0)info.addAction(android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD);
        }
        if(alarm){
            info.addAction(new android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction(ALARM_ACCESS_ACTION,"管理闹钟"));
            CharSequence description=info.getContentDescription();
            info.setContentDescription((description==null?"闹钟":description)+" · "+AlarmData.status(System.currentTimeMillis()));
        }
        if(!music||!DeskData.musicAllowed||DeskData.media==null)return;
        PlaybackState state=DeskData.media.getPlaybackState();if(state==null)return;boolean playing=state.getState()==PlaybackState.STATE_PLAYING;
        String[] names={"上一首",playing?"暂停":"播放","下一首"};for(int i=0;i<3;i++)if(MediaControls.enabled(state.getActions(),playing,i))info.addAction(new android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction(MUSIC_ACCESS_ACTIONS[i],names[i]));
    }
    public boolean performAccessibilityAction(int action,Bundle args){
        if((action==android.view.accessibility.AccessibilityNodeInfo.ACTION_SCROLL_FORWARD||action==android.view.accessibility.AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)&&slotTap==null&&!demo&&!pageAnimatingForCheck()&&todoAllowed()){
            resolve();int direction=action==android.view.accessibility.AccessibilityNodeInfo.ACTION_SCROLL_FORWARD?1:-1;
            for(int i=0;i<page.count();i++)if(page.slots[i].type.equals("todo")){
                Scene.Component item=page.slots[i];float old=todoOffset(item),next=Math.max(0,Math.min(todoMaxOffset(item),old+direction*(TODO_BOTTOM-TODO_TOP)));
                if(next!=old){todoOffsets.put(item.id,next);if(interaction!=null)interaction.run();invalidate();return true;}
            }
            return false;
        }
        if(action==ALARM_ACCESS_ACTION&&slotTap==null&&!demo&&!pageAnimatingForCheck()){
            resolve();for(int slot=0;slot<page.count();slot++)if(page.slots[slot].type.equals("alarm"))return AlarmData.openNext(getContext());return false;
        }
        for(int i=0;i<3;i++)if(action==MUSIC_ACCESS_ACTIONS[i]&&slotTap==null&&!pageAnimatingForCheck()){resolve();for(int slot=0;slot<page.count();slot++)if(page.slots[slot].type.equals("music")){boolean sent=musicAction(i);invalidate();return sent;}return false;}
        return super.performAccessibilityAction(action,args);
    }
}
