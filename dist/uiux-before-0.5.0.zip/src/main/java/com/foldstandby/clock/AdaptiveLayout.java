package com.foldstandby.clock;

/** Layout policy depends on available space, including height and text scaling. */
final class AdaptiveLayout {
    final boolean parallel,shortWindow;
    final int rail,left;
    AdaptiveLayout(int width,int height,float fontScale){
        shortWindow=height<480;
        int detailMin=(int)(300*Math.max(1f,fontScale*.85f));
        rail=width>=680?76:0;
        parallel=width-rail>=280+detailMin;
        left=parallel?Math.min(520,Math.max(280,(int)((width-rail)*.48f))):width;
    }
}
