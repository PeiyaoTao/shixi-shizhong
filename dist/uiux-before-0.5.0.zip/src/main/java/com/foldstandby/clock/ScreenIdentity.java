package com.foldstandby.clock;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.view.Display;

/** Fold8 native modes verified through dumpsys display on SM-F971U1.
 * Window dimensions are deliberately excluded: cutouts and rotation change them.
 */
final class ScreenIdentity {
    static boolean isVerifiedCover(String model, int width, int height) {
        return model != null && model.startsWith("SM-F971") && Math.min(width,height)==1248
                && Math.max(width,height)==1972;
    }

    static boolean isPrimaryCover(Context ctx) {
        try {
            DisplayManager dm = ctx.getSystemService(DisplayManager.class);
            Display d = dm != null ? dm.getDisplay(Display.DEFAULT_DISPLAY) : null;
            if (d != null && d.getMode() != null) {
                Display.Mode m = d.getMode();
                if (Build.MODEL != null && Build.MODEL.startsWith("SM-F971")) {
                    return isVerifiedCover(Build.MODEL, m.getPhysicalWidth(), m.getPhysicalHeight());
                }
                return Math.min(m.getPhysicalWidth(), m.getPhysicalHeight()) < 1500;
            }
        } catch (Throwable ignored) {}
        return Fold.currentState == 0 || Fold.currentState == 1 || Fold.forcedOuter;
    }
}
