package com.foldstandby.clock;

import android.app.*;
import android.content.*;
import android.hardware.*;
import android.hardware.display.DisplayManager;
import android.os.*;
import android.provider.Settings;

public class StandbyService extends Service implements SensorEventListener {
    static volatile boolean running, active, resting;
    private static volatile StandbyService currentInstance;
    private static volatile float restAngle;
    static void enterRest(Context c){
        resting=true;restAngle=angle;c.getSharedPreferences("clock",0).edit().putBoolean("sessionResting",true).apply();
        StandbyService svc=currentInstance;
        if(svc!=null)svc.handler.post(()->svc.pauseMonitorIfIdle(SystemClock.elapsedRealtime()));
    }
    static void leaveRest(Context c){resting=false;c.getSharedPreferences("clock",0).edit().putBoolean("sessionResting",false).apply();}
    static volatile float angle=Float.NaN,x,y,z;
    static volatile long suppressedUntil;
    static volatile String status="未启动";
    private SensorManager sensors;
    private Sensor hinge, gravity;
    private DisplayManager displayManager;
    private KeyguardManager km;
    private PowerManager pm;
    private android.media.AudioManager audio;
    private SharedPreferences prefs;
    private PowerManager.WakeLock cpu, tentWake;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final PostureGate gate=new PostureGate();
    private long sampleTime, lastActiveWindowUntil, pendingTentWakeUntil, lastLaunchTime;
    private boolean launched, gravityRegistered, screenReceiverRegistered;
    private final Runnable tick=new Runnable(){ public void run(){
        evaluate();
        long now=SystemClock.elapsedRealtime();
        if(!pauseMonitorIfIdle(now)){
            long interval=(active && launched && gate.isStill(now)) ? 2000L : 400L;
            handler.postDelayed(this,interval);
        }
    }};
    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            if(Intent.ACTION_SCREEN_OFF.equals(intent.getAction())&&ClockActivity.sessionOpen&&active&&launched&&SystemClock.elapsedRealtime()-lastLaunchTime>=1500L)enterRest(context);
            if(Intent.ACTION_SCREEN_ON.equals(intent.getAction())||Intent.ACTION_USER_PRESENT.equals(intent.getAction())){
                DeskData.keyguardAt=0L;
                if(resting){leaveRest(context);launched=ClockActivity.sessionOpen;}
            }
            if(resting) pauseMonitorIfIdle(SystemClock.elapsedRealtime());
            else wakeMonitor(PostureGate.isPartlyFolded(angle)?35000L:8000L);
        }
    };
    private final DisplayManager.DisplayListener displayListener = new DisplayManager.DisplayListener() {
        public void onDisplayAdded(int displayId) {}
        public void onDisplayRemoved(int displayId) {}
        public void onDisplayChanged(int displayId) {
            if (displayId == android.view.Display.DEFAULT_DISPLAY) {
                handler.post(() -> {
                    if (!resting && !gravityRegistered && km != null && km.isKeyguardLocked() && PostureGate.isPartlyFolded(angle)) {
                        wakeMonitor(6000L);
                    } else {
                        evaluate();
                    }
                    if (ClockActivity.sessionOpen) ClockActivity.onPostureOrDisplayChanged();
                });
            }
        }
    };
    @android.annotation.SuppressLint("WakelockTimeout") // Released when monitoring pauses or the service is destroyed.
    @SuppressWarnings("deprecation")
    public void onCreate(){
        super.onCreate();
        currentInstance=this;
        angle=Float.NaN; x=y=z=0;
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("monitor","姿态检测",NotificationManager.IMPORTANCE_LOW));
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,StandbyService.class).setAction("stop"),PendingIntent.FLAG_IMMUTABLE);
        startForeground(1,new Notification.Builder(this,"monitor").setSmallIcon(com.foldstandby.clock.R.drawable.ic_clock)
            .setContentTitle("折光时钟 · 姿态检测").setContentText("检测已开启 · 点击管理").setContentIntent(open)
            .addAction(new Notification.Action.Builder(null,"停止检测",stop).build()).setOngoing(true).build());
        sensors=getSystemService(SensorManager.class);
        hinge=sensors.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE);
        gravity=sensors.getDefaultSensor(Sensor.TYPE_GRAVITY);
        if(gravity==null) gravity=sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if(hinge==null || gravity==null){ status="未提供铰链或姿态传感器，自动模式不可用"; stopSelf(); return; }
        sensors.registerListener(this,hinge,SensorManager.SENSOR_DELAY_NORMAL);
        km=getSystemService(KeyguardManager.class);
        audio=getSystemService(android.media.AudioManager.class);
        prefs=getSharedPreferences("clock",0);
        resting=false;prefs.edit().putBoolean("sessionResting",false).apply();restAngle=Float.NaN;
        pm = getSystemService(PowerManager.class);
        cpu=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"FoldStandby:posture");
        cpu.setReferenceCounted(false);
        tentWake=pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP,"FoldStandby:tentWake");
        tentWake.setReferenceCounted(false);
        Fold.watch(this, () -> handler.post(() -> {
            if (!resting && !gravityRegistered && km != null && km.isKeyguardLocked() && PostureGate.isPartlyFolded(angle)) {
                wakeMonitor(6000L);
            } else {
                evaluate();
            }
            if (ClockActivity.sessionOpen) ClockActivity.onPostureOrDisplayChanged();
        }));
        displayManager = getSystemService(DisplayManager.class);
        if (displayManager != null) displayManager.registerDisplayListener(displayListener, handler);
        IntentFilter sf = new IntentFilter();
        sf.addAction(Intent.ACTION_SCREEN_OFF);
        sf.addAction(Intent.ACTION_SCREEN_ON);
        sf.addAction(Intent.ACTION_USER_PRESENT);
        registerReceiver(screenReceiver, sf);
        screenReceiverRegistered = true;
        running=true; status="等待锁屏与稳定的帐篷或支架姿态";
        wakeMonitor(8000L);
    }
    @android.annotation.SuppressLint("WakelockTimeout")
    private void wakeMonitor(long durationMs){
        long now=SystemClock.elapsedRealtime();
        lastActiveWindowUntil=Math.max(lastActiveWindowUntil,now+durationMs);
        if(cpu!=null && !cpu.isHeld()) cpu.acquire();
        if(!gravityRegistered && sensors!=null && gravity!=null){
            sensors.registerListener(this,gravity,200000);
            gravityRegistered=true;
        }
        handler.removeCallbacks(tick);
        handler.post(tick);
    }
    private boolean pauseMonitorIfIdle(long now){
        boolean inFoldRange = Float.isNaN(angle) || PostureGate.isPartlyFolded(angle);
        boolean locked = km != null && km.isKeyguardLocked();
        boolean screenOn = pm == null || pm.isInteractive();
        boolean idlePastWindow = now > lastActiveWindowUntil;
        boolean shouldPause = resting
                || (!inFoldRange && !active && idlePastWindow)
                || (!locked && screenOn && !active && idlePastWindow);
        if(shouldPause){
            if(gravityRegistered && sensors!=null){
                sensors.unregisterListener(this,gravity);
                gravityRegistered=false;
            }
            if(cpu!=null && cpu.isHeld()) cpu.release();
            return true;
        }
        return false;
    }
    public int onStartCommand(Intent i,int flags,int id){ if(i!=null && "stop".equals(i.getAction()))stopSelf(); return START_NOT_STICKY; }
    public void onSensorChanged(SensorEvent e){
        if(e.sensor.getType()==Sensor.TYPE_HINGE_ANGLE){
            float prev = angle;
            angle=e.values[0];
            if(resting){if(!PostureGate.isPartlyFolded(angle)||!Float.isFinite(restAngle)||Math.abs(angle-restAngle)>12f){leaveRest(this);gate.reset();active=false;launched=false;wakeMonitor(6000L);if(ClockActivity.sessionOpen)ClockActivity.onPostureOrDisplayChanged();}else return;}
            long now=SystemClock.elapsedRealtime();
            if(Float.isNaN(prev) || PostureGate.isPartlyFolded(angle) || Math.abs(angle - prev) >= 1f){
                wakeMonitor(6000L);
            }
            if(!PostureGate.isPartlyFolded(angle) && Fold.requestedByApp){
                Fold.cancelRequest(this);
            }
            // If the phone is locked and held horizontally (landscape tent roll |x|>4, |y|<3.5)
            // and just closed to 0° (or just opened from <5° into tent range), briefly hold awake=true
            // for 2.5s so Samsung's FlexibleDeviceStatePolicy.adjustState hits "apply tent mode!!".
            if ((prev >= 8f && angle < 5f) || (prev < 5f && angle >= 5f && angle < 90f)) {
                if (now - sampleTime < 1500L) {
                    if (Math.abs(x) > 4f && Math.abs(y) < 3.5f && z < -0.5f && km != null && km.isKeyguardLocked()) {
                        if (tentWake != null) tentWake.acquire(2500);
                    }
                } else {
                    pendingTentWakeUntil = now + 600L;
                }
            }
            return;
        }
        long now=SystemClock.elapsedRealtime();
        boolean wasStill=gate.isStill(now);
        x=e.values[0];y=e.values[1];z=e.values[2];sampleTime=now;
        gate.observe(angle,x,y,z,now);
        boolean still=gate.isStill(now);
        if(!still){
            if(km!=null && km.isKeyguardLocked() && PostureGate.isPartlyFolded(angle)){
                lastActiveWindowUntil=Math.max(lastActiveWindowUntil,now+6000L);
            }
            if(wasStill && active && launched){
                handler.removeCallbacks(tick);
                handler.post(tick);
            }
        }
        if(now < pendingTentWakeUntil){
            pendingTentWakeUntil = 0L;
            if (Math.abs(x) > 4f && Math.abs(y) < 3.5f && z < -0.5f && km != null && km.isKeyguardLocked()) {
                if (tentWake != null) tentWake.acquire(2500);
            }
            evaluate();
        }
    }
    private void evaluate(){
        if(resting){
            if(!ClockActivity.sessionOpen && (km == null || !km.isKeyguardLocked() || !PostureGate.isPartlyFolded(angle))){
                leaveRest(this);
            } else {
                status="当前会话正在休眠，等待系统唤醒";return;
            }
        }
        long now=SystemClock.elapsedRealtime();
        int posture=PostureGate.classify(angle,x,y,z);
        boolean pose=posture==PostureGate.TENT ? prefs.getBoolean("detectTent",true)
                : posture==PostureGate.STAND && prefs.getBoolean("detectStand",true);
        boolean locked=km!=null && km.isKeyguardLocked();
        boolean quiet=audio==null || audio.getMode()==android.media.AudioManager.MODE_NORMAL;
        boolean closed = Fold.currentState == 0 || (Float.isFinite(angle) && angle < 5f);
        boolean stillEnough = gate.isStill(now);
        boolean wasActive=active;
        active=gate.update(!closed && pose && locked && quiet && now-sampleTime<2500 && stillEnough && now>suppressedUntil,now);
        if(wasActive && !active && ClockActivity.sessionOpen) ClockActivity.onPostureOrDisplayChanged();
        if(!active){
            launched=false;
            if(!locked)status="等待锁屏后自动进入待机";
            else if(!Float.isFinite(angle))status="等待铰链传感器数据";
            else if(closed)status="手机已合拢，等待半折支起";
            else if(!PostureGate.isPartlyFolded(angle))status="手机已展开，等待半折支起";
            else if(!quiet)status="通话期间暂停待机";
            else if(now<=suppressedUntil)status="温度保护中，暂缓启动";
            else if(now-sampleTime>=2500)status="等待姿态传感器数据";
            else if(posture==PostureGate.NONE)status="等待有效的半折支撑姿态";
            else if(!pose)status="当前姿态的自动检测已关闭";
            else if(!stillEnough)status="已识别支撑姿态，等待静置稳定";
            else status="已识别"+(posture==PostureGate.TENT?"帐篷":"支架")+"姿态，确认中";
            return;
        }
        boolean cover=ScreenIdentity.isPrimaryCover(this);
        if (!cover) {
            status="已识别支撑姿态，等待外屏就绪（请合拢后重新支起）";
            return;
        }
        if(!Settings.canDrawOverlays(this)){status="请开启悬浮窗权限以启动待机";return;}
        if(!launched){
            launched=true;
            lastLaunchTime=now;
            status="已在外屏启动待机时钟";
            if(pm!=null && !pm.isInteractive() && tentWake!=null) tentWake.acquire(2500);
            try { startActivity(new Intent(this,ClockActivity.class).putExtra("auto",true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
            catch(RuntimeException ex){status="系统阻止后台启动，请检查悬浮窗权限";}
        }
    }
    protected void dump(java.io.FileDescriptor fd, java.io.PrintWriter out, String[] args){
        long now=SystemClock.elapsedRealtime();
        out.println("running="+running+" active="+active+" resting="+resting+" launched="+launched);
        out.println("hinge="+angle+" gravity="+x+","+y+","+z+" posture="+PostureGate.classify(angle,x,y,z));
        out.println("sampleAgeMs="+(now-sampleTime)+" still="+gate.isStill(now)+" cover="+ScreenIdentity.isPrimaryCover(this)+" deviceState="+Fold.currentState);
        out.println("status="+status);
    }
    public void onAccuracyChanged(Sensor s,int a){}
    public IBinder onBind(Intent i){return null;}
    public void onDestroy(){
        if(currentInstance==this)currentInstance=null;
        handler.removeCallbacksAndMessages(null);
        if(screenReceiverRegistered){try{unregisterReceiver(screenReceiver);}catch(Exception ignored){}screenReceiverRegistered=false;}
        if(displayManager!=null)displayManager.unregisterDisplayListener(displayListener);
        if(sensors!=null)sensors.unregisterListener(this);
        gravityRegistered=false;
        if(tentWake!=null&&tentWake.isHeld())tentWake.release();
        if(cpu!=null&&cpu.isHeld())cpu.release();
        running=false;active=false;
        super.onDestroy();
    }
}
