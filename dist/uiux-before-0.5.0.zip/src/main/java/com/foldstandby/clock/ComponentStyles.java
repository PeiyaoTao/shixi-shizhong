package com.foldstandby.clock;

/** Visual styles are independent of data options such as date range and forecast day. */
final class ComponentStyles {
    private static final String[][] IDS = {
        Scene.STYLES,
        {"month", "almanac", "week", "year"},
        {"agenda", "timeline", "agenda_cards", "spotlight"},
        {"weather", "weather_icon", "weather_panel", "weather_split"},
        {"cover", "record", "music_type", "spectrum"},
        {"focus_ring", "focus_type", "focus_segments", "hourglass"},
        {"gauge", "battery_cell", "battery_type", "battery_segments"},
        {"world_digital", "world_dial", "world_split", "world_orbit"},
        {"checklist", "todo_cards", "todo_numbers", "todo_progress"},
        {"alarm_digital", "alarm_dial", "alarm_countdown", "alarm_card"}
    };
    private static final String[][] NAMES = {
        Scene.STYLE_NAMES,
        {"经典月历", "大字日签", "本周一览", "全年光点"},
        {"简洁清单", "时间轴", "日程卡片", "事项聚焦"},
        {"极简温度", "天气图标", "气象面板", "温差刻度"},
        {"封面播放器", "黑胶唱片", "文字海报", "律动频谱"},
        {"专注圆环", "大字倒计时", "分段进度", "流沙计时"},
        {"环形仪表", "电池轮廓", "大字电量", "能量分格"},
        {"城市数字", "城市表盘", "双城对照", "昼夜轨道"},
        {"勾选清单", "待办卡片", "编号列表", "完成进度"},
        {"极简闹钟", "唤醒表盘", "剩余时间", "闹钟卡片"}
    };
    private static final String[][] NOTES = {
        {"", "", "", "", "", ""},
        {"月视图与可选今日事项", "突出日期与星期", "本周七日与今日事项", "十二个月的日期点阵"},
        {"清晰分隔每条事项", "沿时间线排列日程", "独立描边卡片", "突出所选范围的首条事项"},
        {"大温度与天气摘要", "矢量天气符号与温度", "体感、湿度与高低温", "沿刻度查看当日温差"},
        {"封面、曲名与播放控制", "唱片纹理与唱片标签", "以曲名为主视觉", "装饰频谱随播放状态律动"},
        {"环形剩余进度", "远距离易读的倒计时", "二十格剩余进度", "自然流沙、沙量变化与翻转复位"},
        {"电量、充电状态与温度", "横向电池与能量填充", "突出百分比与状态", "十格电量与充电指示"},
        {"城市、时间与 UTC 偏移", "独立时区的指针表盘", "所选时区与本地对照", "24 小时轨道与当前时刻"},
        {"复选框与完成划线", "每项独立描边卡片", "编号排列与完成标记", "完成比例与可勾选列表"},
        {"下次响铃时间与日期", "指针呈现下次响铃时刻", "突出距响铃的剩余时长", "闹钟图标与描边信息卡片"}
    };

    private ComponentStyles() {}
    private static int index(String type) {
        for (int i = 0; i < Scene.TYPES.length; i++) if (Scene.TYPES[i].equals(type)) return i;
        return 0;
    }
    static String[] ids(String type) { return IDS[index(type)]; }
    static String[] names(String type) { return NAMES[index(type)]; }
    static String[] notes(String type) { return NOTES[index(type)]; }
    static String selected(Scene.Component c) { return Scene.valid(c.style, ids(c.type), ids(c.type)[0]); }
    static int selectedIndex(Scene.Component c) {
        String[] ids = ids(c.type);
        for (int i = 0; i < ids.length; i++) if (ids[i].equals(selected(c))) return i;
        return 0;
    }
    static void select(Scene.Component c, String type, int variant) {
        c.setType(type);
        String[] ids = ids(c.type);
        c.style = ids[Math.max(0, Math.min(ids.length - 1, variant))];
        Scene.put(c.options, "style:" + c.type, c.style);
    }
}
