package com.foldstandby.clock;
public class AdaptiveLayoutTest {
    private static void check(boolean b,String name){if(!b)throw new AssertionError(name);}
    public static void main(String[] args){
        check(!new AdaptiveLayout(440,820,1).parallel,"narrow cover uses focused workspace");
        check(new AdaptiveLayout(820,1088,1).parallel,"portrait inner supports parallel workspaces");
        check(new AdaptiveLayout(1088,820,1).parallel,"landscape inner");
        check(new AdaptiveLayout(876,500,1).parallel,"landscape cover");
        check(new AdaptiveLayout(876,320,1).shortWindow,"short height policy");
        check(!new AdaptiveLayout(700,900,2).parallel,"large text needs wider inspector");
        check(new AdaptiveLayout(1600,1000,1).left<=520,"preview pane has a width cap");
        System.out.println("PASS: 7 adaptive layout policies");
    }
}
