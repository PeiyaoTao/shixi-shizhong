# Domain Glossary — Fold 待机时钟 (`com.foldstandby.clock`)

This glossary defines the canonical domain terms used across the Fold Standby Clock codebase, UI copy, and architecture reviews.

## Core Domain Terms

- **Scene (`场景`)**: The root saved configuration (`Scene.java`, key `scene_v3`) representing a complete standby desk setup, including its name, home page identity, scene-level day theme, scene-level night theme, and ordered list of Pages. Named Scenes are persisted under `scene_saved_<name>`.
- **Page (`页面`)**: A full-screen standby canvas (`Scene.Page`) within a Scene, carrying an immutable UUID `id`, display `name` (optionally auto-derived from its visible Components), a 1-to-4 Slot `layout` (`整屏` / `双栏` / `主次` / `四格`), a page-level theme override, and four Slot entries.
- **Slot (`槽位`)**: One of up to four rectangular regions (`Scene.Page.slots[0..3]`) inside a Page, determined by the Page's `layout`. A layout activates 1 (`整屏`), 2 (`双栏` / `主次`), or 4 (`四格`) Slots.
- **Component (`组件`)**: The content unit bound to a Slot (`Scene.Component`), identified by one of nine `type` values (`clock`, `date`, `calendar`, `weather`, `music`, `focus`, `battery`, `world`, `todo`), shared `options` (including per-component `scale` 75%–125%), and per-style parameter maps.
- **Clock Style (`时钟样式`)**: One of six visual clock renderers (`digital` 极简数字, `flip` 机械翻页, `analog` 经典指针, `industrial` 工业指针, `led` 七段数码, `dot` 点阵) stored on a `clock` Component (`style`) with isolated per-style parameters (`styles[style]`).
- **Color Role (`配色角色`)**: One of the semantic visual channels (`background` 背景 [always `#000000`], `time` 时间文字, `secondary` 次级信息, `accent` 强调色, `hour` 时针, `minute` 分针, `second` 秒针, `major` 小时刻度, `minor` 分钟刻度, `numerals` 表盘数字, `plate` 结构线) rendered as compact color-filled pill buttons in `PaletteEditor`.
- **Theme Gradient (`组件主题渐变`)**: One of six gradient presets (`纯色`, `极光`, `晨曦`, `海洋`, `莓果`, `金霞` in `TextGradients.java`) stored under `timeGradient` and applied across all nine Components' primary visual channels (digits, analog hands and major ticks, countdown/battery arcs, calendar highlight, todo text/boxes, music progress/play button).
- **Theme Scope (`主题作用域`)**: The inheritance hierarchy governing resolved colors and gradients: `Component` overrides `Page`, which overrides `Scene` (or `Night Theme` during active night hours when independent night colors are enabled).
- **Watch Carousel (`页面透视轮播`)**: The sole live preview surface (`WatchCarouselScrollView`), displaying true-aspect (`1972:1248`) `#000000` Page frames without outer card containers—enlarging and highlighting the selected Page while shrinking and 3D-tilting (`rotationX`) neighboring Pages between fixed header/footer bars.
- **Collapsible Navigation (`可隐藏式导航栏`)**: The zero-chrome-by-default drawer (`☰` toggle in `MainActivity`) housing Scene switching, Workspace/Settings mode switching, and quick navigation without permanent top or side toolbars.
- **Studio Workspace (`工作台视窗`)**: The unified configuration interface (`MainActivity` + `AdaptiveLayout`) combining Page management, Component Style selection, parameter inspection (`ComponentInspector`), and scoped `PaletteEditor`. Uses parallel side-by-side panes in landscape and a pinned Watch Carousel + independently scrollable Workbench (with a secondary full-screen Style Gallery) in portrait.
- **Posture Gate (`姿态门限`)**: The debounced hinge-angle and gravity-vector filter (`PostureGate.java`) inside `StandbyService` that validates tent posture before launching `ClockActivity`.
- **Rest Session (`休眠会话`)**: The night-mode on-demand viewing state in `ClockActivity` / `StandbyService` that releases `FLAG_KEEP_SCREEN_ON` after the configured `nightViewSeconds` timeout so the system can sleep without posture re-triggering.
- **Cover Display (`外屏`)**: The verified outer display of the foldable device (`ScreenIdentity.java`, `SM-F971U1`) targeted by `ClockActivity` in landscape tent mode.
