package com.foldstandby.clock;
public class AdaptiveLayoutTest {
    private static void check(boolean b,String name){if(!b)throw new AssertionError(name);}
    public static void main(String[] args){
        check(!new AdaptiveLayout(440,820,1).parallel,"narrow cover uses focused workspace");
        check(new AdaptiveLayout(820,1088,1).parallel,"portrait inner supports parallel workspaces");
        check(new AdaptiveLayout(1088,820,1).parallel,"landscape inner");
        check(new AdaptiveLayout(876,500,1).parallel,"landscape cover");
        check(new AdaptiveLayout(876,320,1).shortWindow,"short height policy");
        check(!new AdaptiveLayout(700,900,2).parallel,"large text needs wider inspector");
        check(new AdaptiveLayout(1600,1000,1).left<=520,"preview pane has a width cap");
        check(!new AdaptiveLayout(560,700,1).parallel,"narrow window keeps one pane");
        check(new AdaptiveLayout(580,700,1).parallel,"usable minimum parallel panes");
        check(new AdaptiveLayout(679,700,1).parallel==new AdaptiveLayout(680,700,1).parallel,"no unused rail threshold jump");
        check(!new AdaptiveLayout(820,210,1).parallel,"extremely short windows prioritize content");
        for(int height:new int[]{240,320,500,820})for(float font:new float[]{1,1.3f,2.08f}){
            int preview=AdaptiveLayout.previewHeight(400,height,false,false,false,font);
            check(preview>=76&&preview<=height,"preview fits available height");
            check(AdaptiveLayout.previewHeight(400,height,false,false,true,font)<=110,"keyboard preview remains compact");
        }
        System.out.println("PASS: adaptive panes, threshold continuity, preview budgets and keyboard sizes");
    }
}
