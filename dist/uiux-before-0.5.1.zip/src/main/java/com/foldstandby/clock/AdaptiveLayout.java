package com.foldstandby.clock;

/** Layout policy depends on available space, including height and text scaling. */
final class AdaptiveLayout {
    final boolean parallel,shortWindow;
    final int rail,left;
    AdaptiveLayout(int width,int height,float fontScale){
        shortWindow=height<480;
        int detailMin=(int)(290*Math.max(1f,fontScale*.85f));
        rail=0;
        parallel=width>=260+detailMin+22&&height>=230;
        left=parallel?Math.min(width-detailMin-22,Math.min(520,Math.max(260,(int)(width*.44f)))):width;
    }
    static int previewHeight(int width,int height,boolean browsing,boolean expanded,boolean keyboard,float fontScale){
        int reserve=Math.round(180*Math.max(1f,fontScale*.75f));
        int target=keyboard?110:expanded?Math.round(height*.56f):browsing?Math.round(height*.44f):Math.min(230,Math.round(height*.30f));
        return Math.max(76,Math.min(target,Math.max(76,height-reserve)));
    }
}
