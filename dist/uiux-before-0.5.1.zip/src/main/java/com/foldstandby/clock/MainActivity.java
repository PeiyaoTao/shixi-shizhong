package com.foldstandby.clock;

import android.animation.ValueAnimator;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.*;
import android.view.*;
import android.view.animation.PathInterpolator;
import android.widget.*;
import java.util.*;
import java.util.function.Consumer;
import org.json.*;

/**
 * Unified Studio Workspace organized around a persistent 3D-perspective Smartwatch Page Carousel,
 * a collapsible navigation drawer, an object-focused Workbench (Content / Appearance / Palette), and
 * adaptive previews, explicit component/style selectors, local history and persistent recovery.
 */
public class MainActivity extends Activity implements UiKit.EditTransactions {
    private SharedPreferences prefs;
    Scene draft;
    private String baseline, pageId;
    private int tab = 1, slot, category, paletteScope = 2, inspectorGroup;
    private boolean testMode, previewNight, pageOverview, navExpanded, portraitStyleScreen;
    private String libraryType;
    private int widthDp, heightDp, windowWidthDp, navigationWidthDp;
    private AdaptiveLayout policy;
    private LinearLayout workspace, first, second, workbenchHost;
    private TextView brandButton;
    private WatchCarouselScrollView carouselScroll;
    private final ArrayList<ClockFace> previews = new ArrayList<>();
    private final ArrayList<ClockFace> carouselPreviews = new ArrayList<>();
    private final Map<String, ScrollView> scrollViews = new HashMap<>();
    private final Map<String, Integer> scrolls = new HashMap<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private PaletteEditor colorEditor;
    private final PaletteEditor.State colorState = new PaletteEditor.State();
    private String colorContext = "";
    private final EditHistory history = new EditHistory();
    private String historyState;
    private boolean browsingPages = true, previewExpanded, componentPicker, imeVisible, horizontalFold;
    private int studioPanel, contentInsetLeft, contentInsetTop, safeLeft, safeTop, safeWidth, safeHeight;
    private Rect localFold;
    private int previewPaneWidth, editorPaneWidth;
    private Dialog studioDialog;
    private TextView undoButton, savedStatus, pageTitle;
    private FrameLayout noticeHost;
    private String noticeText;
    private long noticeUntil;
    private Rect foldBounds;
    private FoldLayoutObserver folds;
    private WeatherLocation.Request locationRequest;
    private AlertDialog locationDialog, searchDialog;
    private InputDialog inputDialog;
    private static final int WEATHER_LOCATION_PERMISSION = 14;
    private final Rect visiblePreviewRect = new Rect();
    private boolean pulseRunning;
    private final Runnable refreshSceneData = () -> { if (!testMode) DeskData.refresh(this, false); };
    private final Runnable alarmChanged = () -> {
        for (ClockFace f : previews) f.invalidate();
        updateAlarmStatus();
    };
    private void updateAlarmStatus() {
        View status = getWindow().getDecorView().findViewWithTag("alarm:status");
        if (status instanceof TextView) ((TextView) status).setText(AlarmData.status(System.currentTimeMillis()));
    }
    private final Runnable clockPulse = new Runnable() {
        public void run() {
            if (!testMode) AlarmData.refresh(MainActivity.this, false);
            updateAlarmStatus();
            long delay = 15000L;
            for (ClockFace f : previews) {
                if (!f.isAttachedToWindow() || !f.isShown()) continue;
                if (f.getWidth() == 0) {
                    delay = 1000L;
                } else if (f.getGlobalVisibleRect(visiblePreviewRect)) {
                    f.invalidate();
                    delay = Math.min(delay, f.nextDelayMs());
                }
            }
            delay = Math.max(1000L, Math.min(15000L, delay));
            handler.postDelayed(this, delay);
        }
    };

    private int dp(float n) { return UiKit.dp(this, n); }

    private ScrollView scroll(LinearLayout host, String key, boolean fill) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(fill);
        s.setClipToPadding(true);
        s.setPadding(dp(10), dp(8), dp(10), dp(14));
        s.setVerticalScrollBarEnabled(true);
        host.addView(s, new LinearLayout.LayoutParams(-1, 0, 1));
        scrollViews.put(key, s);
        Integer y = scrolls.get(key);
        if (y != null) s.post(() -> s.scrollTo(0, y));
        return s;
    }

    private LinearLayout scrollColumn(LinearLayout host, String key) {
        ScrollView s = scroll(host, key, false);
        LinearLayout c = UiKit.column(this);
        s.addView(c);
        return c;
    }

    private void rememberScroll() {
        for (Map.Entry<String, ScrollView> e : scrollViews.entrySet()) {
            scrolls.put(e.getKey(), e.getValue().getScrollY());
        }
    }

    private Scene.Page page() { return draft.pages.get(draft.index(pageId)); }

    private Scene.Component component() {
        slot = Math.min(slot, page().count() - 1);
        return page().slots[slot];
    }

    private void changed() {
        for (Scene.Page p : draft.pages) p.refreshName();
        String next = captureEditorState();
        history.record(historyState, next);
        historyState = next;
        persistDraft();
        if (undoButton != null) { undoButton.setEnabled(history.canUndo()); undoButton.setAlpha(history.canUndo() ? 1f : .35f); }
        if (savedStatus != null) savedStatus.setText("已自动保存");
        if (brandButton != null) {
            brandButton.setText("折光 / " + draft.name + " ▾");
        }
        for (ClockFace f : previews) f.invalidate();
        if (pulseRunning) {
            handler.removeCallbacks(clockPulse);
            handler.postDelayed(clockPulse, 1000);
        }
    }

    /** Only committed, valid form values enter the model; incomplete input stays in its field. */
    private void persistDraft() {
        String json = draft.json();
        if (json.equals(baseline)) return;
        prefs.edit().putString(Scene.KEY, json).apply();
        baseline = json;
        handler.removeCallbacks(refreshSceneData);
        handler.postDelayed(refreshSceneData, 350);
    }

    private void saveNamedScene(String name) {
        if(prefs.contains("scene_saved_"+name)){
            new StudioAlertBuilder().setTitle("已有同名快照").setMessage("快照包含页面、配色、待办内容与完成状态。请选择覆盖或另存副本。")
                .setPositiveButton("覆盖快照",(d,n)->{saveRecoveryPoint("覆盖「"+name+"」前");completeSave(name);})
                .setNeutralButton("保存副本",(d,n)->{String copy=name+" 副本";int i=2;while(prefs.contains("scene_saved_"+copy))copy=name+" 副本 "+i++;completeSave(copy);})
                .setNegativeButton("取消",null).show();
        }else completeSave(name);
    }
    private void completeSave(String name){
        history.finish();draft.name=name;prefs.edit().putString("scene_saved_"+name,draft.json()).apply();changed();show();showNotice("已保存完整场景快照");
    }

    private void launchFullscreenPreview() {
        startActivity(
            new Intent(this, ClockActivity.class)
                .putExtra("scenePreview", draft.json())
                .putExtra("previewPage", pageId)
                .putExtra("previewNight", previewNight)
                .putExtra("uiCheck", testMode)
        );
    }

    public void beginEdit() { history.begin(); }
    public void endEdit() { history.end(); }
    private String captureEditorState() {
        JSONObject state = new JSONObject(), snapshots = new JSONObject();
        Scene.put(state, "scene", draft.json()); Scene.put(state, "page", pageId); Scene.put(state, "slot", slot);
        for (String key : new TreeSet<>(prefs.getAll().keySet())) if (key.startsWith("scene_saved_")) Scene.put(snapshots, key, prefs.getString(key, ""));
        Scene.put(state, "snapshots", snapshots); return state.toString();
    }
    private void selectionBaseline() { history.finish(); historyState = captureEditorState(); }
    private void restoreEditorState(String value) {
        if (value == null) return;
        try {
            JSONObject state = new JSONObject(value);
            Scene scene = Scene.parse(state.getString("scene")); if (scene == null) return;
            draft = scene; pageId = state.optString("page", scene.home); pageId = page().id;
            slot = Math.max(0, Math.min(state.optInt("slot"), page().count()-1));
            JSONObject snapshots = state.optJSONObject("snapshots");
            SharedPreferences.Editor edit = prefs.edit();
            for (String key : prefs.getAll().keySet()) if (key.startsWith("scene_saved_")) edit.remove(key);
            if (snapshots != null) for (Iterator<String> keys = snapshots.keys(); keys.hasNext();) { String key=keys.next(); if(key.startsWith("scene_saved_"))edit.putString(key,snapshots.optString(key)); }
            edit.apply(); historyState = captureEditorState(); libraryType = component().type;
            colorState.hex = null; colorContext = ""; portraitStyleScreen = componentPicker = false;
            persistDraft(); show();
        } catch (JSONException e) { message("恢复点不可用，当前配置已保留。"); }
    }
    private void undoEdit() { history.finish(); restoreEditorState(history.undo()); }
    private void redoEdit() { history.finish(); restoreEditorState(history.redo()); }
    private void saveRecoveryPoint(String label) {
        history.finish();
        JSONArray points;
        try { points = new JSONArray(prefs.getString("studio_recovery", "[]")); } catch (JSONException e) { points = new JSONArray(); }
        JSONArray next = new JSONArray(); JSONObject point = new JSONObject();
        Scene.put(point,"label",label); Scene.put(point,"time",System.currentTimeMillis()); Scene.put(point,"state",captureEditorState()); next.put(point);
        for(int i=0;i<Math.min(4,points.length());i++)next.put(points.optJSONObject(i));
        prefs.edit().putString("studio_recovery",next.toString()).apply();
    }
    private void showRecoveryPoints() {
        try {
            JSONArray points = new JSONArray(prefs.getString("studio_recovery", "[]"));
            if(points.length()==0){message("暂无恢复点。载入、恢复默认或覆盖快照前会自动保留。");return;}
            String[] names=new String[points.length()];
            for(int i=0;i<names.length;i++){JSONObject p=points.getJSONObject(i);names[i]=p.optString("label")+" · "+android.text.format.DateFormat.format("MM-dd HH:mm",p.optLong("time"));}
            new StudioAlertBuilder().setTitle("恢复点 · 含待办内容与完成状态").setItems(names,(d,n)->{
                String before=captureEditorState(); saveRecoveryPoint("恢复前的配置");
                restoreEditorState(points.optJSONObject(n).optString("state"));
                history.record(before,captureEditorState()); historyState=captureEditorState(); show();showNotice("已恢复配置");
            }).setNegativeButton("关闭",null).show();
        }catch(JSONException e){message("暂无可用的恢复点。");}
    }
    private void showNotice(String text) {
        noticeText=text; noticeUntil=SystemClock.uptimeMillis()+5500; renderNotice();
        handler.postDelayed(()->{if(SystemClock.uptimeMillis()>=noticeUntil&&noticeHost!=null){noticeHost.removeAllViews();noticeHost.setVisibility(View.GONE);}},5600);
    }
    private void renderNotice() {
        if(noticeHost==null)return; noticeHost.removeAllViews();
        boolean visible=noticeText!=null&&SystemClock.uptimeMillis()<noticeUntil;
        noticeHost.setVisibility(visible?View.VISIBLE:View.GONE); if(!visible)return;
        LinearLayout row=UiKit.row(this);row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10),dp(4),dp(10),dp(4));row.setBackground(UiKit.surface(this,UiKit.ACTIVE_BG,10,UiKit.ACTIVE_BORDER,1));
        TextView text=UiKit.text(this,noticeText,11,UiKit.TEXT);text.setMaxLines(2);row.addView(text,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(UiKit.compactButton(this,"撤销",UiKit.ACTIVE_BG,0,UiKit.ACCENT,this::undoEdit));
        noticeHost.addView(row,new FrameLayout.LayoutParams(-1,-2));noticeHost.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
    }

    public void onCreate(Bundle state) {
        super.onCreate(state);
        testMode = getIntent().getBooleanExtra("uiCheck", false);
        prefs = getSharedPreferences(testMode ? "ui_checks" : "clock", 0);
        draft = Scene.load(prefs);
        baseline = draft.json();
        prefs.edit().putString(Scene.KEY,baseline).apply();
        pageId = draft.home;
        historyState = captureEditorState();
        if (state != null) {
            browsingPages = state.getBoolean("browsingPages", true);
            previewExpanded = state.getBoolean("previewExpanded");
            studioPanel = state.getInt("studioPanel");
            componentPicker = state.getBoolean("componentPicker");
            history.restore(state.getStringArrayList("undoStates"), state.getStringArrayList("redoStates"));
            pageOverview = state.getBoolean("pageOverview");
            navExpanded = state.getBoolean("navExpanded");
            portraitStyleScreen = state.getBoolean("portraitStyleScreen");
            libraryType = state.getString("libraryType");
            Scene restored = Scene.parse(state.getString("draft", ""));
            if (restored != null) draft = restored;
            baseline = state.getString("baseline", baseline);
            pageId = state.getString("page", draft.home);
            tab = state.getInt("tab", 1);
            slot = state.getInt("slot");
            category = state.getInt("category");
            inspectorGroup = state.getInt("inspectorGroup");
            paletteScope = state.getInt("paletteScope", 2);
            colorState.mode = state.getInt("colorMode");
            colorState.role = state.getInt("colorRole", 1);
            colorState.hex = state.getString("colorHex");
            colorContext = state.getString("colorContext", "");
            previewNight = state.getBoolean("previewNight");
            try {
                JSONObject j = new JSONObject(state.getString("scrolls", "{}"));
                Iterator<String> keys = j.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    scrolls.put(key, j.optInt(key));
                }
            } catch (Exception ignored) {}
        }
        historyState = captureEditorState();
        getWindow().setStatusBarColor(UiKit.BG);
        getWindow().setNavigationBarColor(UiKit.BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        show();
        if (!testMode) {
            DeskData.refresh(this, false);
            folds = new FoldLayoutObserver(this, bounds -> {
                foldBounds = bounds;
                rememberScroll();
                show();
            });
            folds.start();
        }
    }

    private void show() {
        if(getWindow()==null)return;
        rememberScroll();
        WindowMetrics metrics = getWindowManager().getCurrentWindowMetrics();
        Insets insets = metrics.getWindowInsets().getInsetsIgnoringVisibility(
            WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout()
        );
        float density = getResources().getDisplayMetrics().density;
        contentInsetLeft = insets.left; contentInsetTop = insets.top;
        int w = Math.round((metrics.getBounds().width() - insets.left - insets.right) / density);
        int h = Math.round((metrics.getBounds().height() - insets.top - insets.bottom) / density);
        setContentView(createUi(w, h));
        getWindow().getDecorView().setOnApplyWindowInsetsListener((v, value) -> {
            boolean visible = value.isVisible(WindowInsets.Type.ime());
            if (imeVisible != visible) { imeVisible = visible; if (activeStage != null) activeStage.requestLayout(); }
            return v.onApplyWindowInsets(value);
        });
    }

    private int leftPaneWidthDp() { return horizontalFold ? widthDp - 12 : policy.parallel ? policy.left : widthDp - 12; }

    private int paneInnerWidth(boolean left) { return Math.max(100,(left?previewPaneWidth:editorPaneWidth)-28); }

    private WatchStageContainer activeStage;
    private Rect foldDp(int w, int h) {
        if(foldBounds==null)return null;
        float density=getResources().getDisplayMetrics().density;
        Rect r=new Rect(Math.round((foldBounds.left-contentInsetLeft)/density),Math.round((foldBounds.top-contentInsetTop)/density),
            Math.round((foldBounds.right-contentInsetLeft)/density),Math.round((foldBounds.bottom-contentInsetTop)/density));
        if(r.right<0||r.bottom<0||r.left>w||r.top>h)return null;
        return r;
    }
    private Rect largestRegion(int w,int h,Rect fold) {
        if(fold==null||fold.right<0||fold.bottom<0||fold.left>=w||fold.top>=h)return new Rect(0,0,w,h);
        Rect a,b;
        if(fold.width()>fold.height()){a=new Rect(0,0,w,Math.min(h,Math.max(0,fold.top)));b=new Rect(0,Math.min(h,fold.bottom),w,h);}
        else{a=new Rect(0,0,Math.min(w,Math.max(0,fold.left)),h);b=new Rect(Math.min(w,fold.right),0,w,h);}
        return a.width()*a.height()>=b.width()*b.height()?a:b;
    }
    View createUi(int w, int h) {
        int originalW=w,originalH=h;
        UiKit.customFontScale = prefs != null ? prefs.getFloat("uiFontScale", 1.0f) : 1.0f;
        float scale=getResources().getConfiguration().fontScale*UiKit.customFontScale;
        Rect fold=foldDp(w,h),region=new Rect(0,0,w,h);
        int nav=w>h&&navExpanded?Math.min(220,Math.max(160,Math.round(w*.22f))):0;
        boolean canSplit=fold!=null&&(fold.width()>fold.height()?fold.top>=120&&h-fold.bottom>=220:
            fold.left-nav>=220&&w-fold.right>=Math.round(250*Math.max(1f,scale*.8f)));
        if(fold!=null&&(!canSplit||tab==3||portraitStyleScreen))region=largestRegion(w,h,fold);
        safeLeft=region.left;safeTop=region.top;safeWidth=w=region.width();safeHeight=h=region.height();
        windowWidthDp=w;
        navigationWidthDp=w>h&&navExpanded?Math.min(220,Math.max(150,Math.round(w*.22f))):0;
        widthDp=w-navigationWidthDp;heightDp=h;
        localFold=fold==null?null:new Rect(fold.left-safeLeft-navigationWidthDp-6,fold.top-safeTop-5,
            fold.right-safeLeft-navigationWidthDp-6,fold.bottom-safeTop-5);
        horizontalFold=canSplit&&region.left==0&&region.top==0&&fold.width()>fold.height()&&tab!=3&&!portraitStyleScreen;
        policy=new AdaptiveLayout(widthDp,h,scale);
        boolean split=canSplit&&region.left==0&&region.top==0&&tab!=3&&!portraitStyleScreen;
        previewPaneWidth=editorPaneWidth=widthDp-12;
        if(split&&!horizontalFold){previewPaneWidth=localFold.left;editorPaneWidth=widthDp-12-localFold.right;}
        else if(policy.parallel&&!horizontalFold){previewPaneWidth=policy.left;editorPaneWidth=widthDp-policy.left-20;}
        previews.clear();carouselPreviews.clear();scrollViews.clear();colorEditor=null;brandButton=null;carouselScroll=null;workbenchHost=null;activeStage=null;
        LinearLayout root=UiKit.column(this);root.setBackgroundColor(UiKit.BG);
        if(tab==3)renderSettingsShell(root);
        else if(portraitStyleScreen)renderPortraitStyleScreen(root);
        else{
            workspace=new FoldWorkspace(this);workspace.setOrientation(LinearLayout.HORIZONTAL);workspace.setPadding(dp(6),dp(5),dp(6),dp(6));
            root.addView(workspace,new LinearLayout.LayoutParams(-1,0,1));
            first=UiKit.column(this);first.setBackground(UiKit.surface(this,UiKit.PANEL,14,UiKit.PANEL_BORDER,1));
            if(policy.parallel||split){
                workspace.addView(first,new LinearLayout.LayoutParams(dp(leftPaneWidthDp()),-1));
                second=new EditorPane(this);second.setBackground(UiKit.surface(this,UiKit.PANEL,14,UiKit.PANEL_BORDER,1));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.leftMargin=dp(8);workspace.addView(second,lp);
                if(split)applyFoldPanes();
                buildWatchCarouselStage(first,true);workbenchHost=second;buildIntegratedWorkbench(second,true);
            }else{
                workspace.addView(first,new LinearLayout.LayoutParams(-1,-1));second=first;
                activeStage=new WatchStageContainer(this,0);activeStage.setBackground(UiKit.surface(this,0xff0d121a,12,UiKit.CARD_BORDER,1));
                first.addView(activeStage,new LinearLayout.LayoutParams(-1,-2));buildWatchCarouselStage(activeStage,false);
                workbenchHost=new EditorPane(this);first.addView(workbenchHost,new LinearLayout.LayoutParams(-1,0,1));buildIntegratedWorkbench(workbenchHost,false);
            }
        }
        FrameLayout content=new FrameLayout(this);content.addView(withNavigation(root),new FrameLayout.LayoutParams(-1,-1));
        noticeHost=new FrameLayout(this);FrameLayout.LayoutParams toastLp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);toastLp.setMargins(dp(12),0,dp(12),dp(10));content.addView(noticeHost,toastLp);renderNotice();
        if(region.left==0&&region.top==0&&region.width()==originalW&&region.height()==originalH)return content;
        FrameLayout safe=new SafeRegionContainer(this,fold);safe.setBackgroundColor(UiKit.BG);safe.addView(content,new FrameLayout.LayoutParams(dp(w),dp(h)));safe.setTag("fold:safe");return safe;
    }

    final class EditorPane extends LinearLayout {
        LinearLayout fixedHeader,extras,body;boolean compact;
        EditorPane(Context c){super(c);setOrientation(LinearLayout.VERTICAL);}
        protected void onMeasure(int w,int h){
            boolean small=MeasureSpec.getSize(h)<dp(260*Math.max(1f,Math.min(1.5f,getResources().getConfiguration().fontScale*UiKit.customFontScale)));
            if(extras!=null&&body!=null&&small!=compact){
                ((ViewGroup)extras.getParent()).removeView(extras);compact=small;
                if(small)body.addView(extras,0);else fixedHeader.addView(extras);
            }
            super.onMeasure(w,h);
        }
    }

    final class SafeRegionContainer extends FrameLayout {
        private final Rect fold;
        SafeRegionContainer(Context c,Rect bounds){super(c);fold=bounds==null?null:new Rect(dp(bounds.left),dp(bounds.top),dp(bounds.right),dp(bounds.bottom));}
        protected void onMeasure(int w,int h){
            Rect region=largestRegion(MeasureSpec.getSize(w),MeasureSpec.getSize(h),fold);
            if(getChildCount()>0){FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)getChildAt(0).getLayoutParams();lp.width=region.width();lp.height=region.height();lp.leftMargin=region.left;lp.topMargin=region.top;}
            super.onMeasure(w,h);
        }
    }
    final class FoldWorkspace extends LinearLayout {
        FoldWorkspace(Context c){super(c);}
        protected void onMeasure(int w,int h){
            if(horizontalFold&&localFold!=null&&first!=null&&second!=null){
                int available=MeasureSpec.getSize(h),top=dp(localFold.top),bottom=dp(localFold.bottom);
                if(available-bottom>=dp(200)){
                    setPadding(dp(6),dp(5),dp(6),dp(6));first.setVisibility(View.VISIBLE);first.getLayoutParams().height=top;
                    View tools=first.findViewWithTag("preview:tools");if(tools!=null)tools.setVisibility(View.VISIBLE);
                    if(carouselScroll!=null&&carouselScroll.getChildCount()>0){ViewGroup track=(ViewGroup)carouselScroll.getChildAt(0);for(int i=0;i<track.getChildCount();i++)((ViewGroup)track.getChildAt(i)).getChildAt(0).setVisibility(browsingPages?View.VISIBLE:View.GONE);}
                    LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)second.getLayoutParams();lp.topMargin=dp(Math.max(1,localFold.height()));
                }else{
                    Rect area=largestRegion(MeasureSpec.getSize(w),available,new Rect(0,top+dp(5),MeasureSpec.getSize(w),bottom+dp(5)));
                    setPadding(dp(6),Math.max(dp(5),area.top),dp(6),Math.max(dp(6),available-area.bottom));
                    int preview=Math.min(dp(110),Math.max(0,area.height()-dp(200)));
                    first.setVisibility(preview>=dp(76)?View.VISIBLE:View.GONE);first.getLayoutParams().height=preview;
                    ((LinearLayout.LayoutParams)second.getLayoutParams()).topMargin=0;
                    View tools=first.findViewWithTag("preview:tools");if(tools!=null)tools.setVisibility(View.GONE);
                    if(carouselScroll!=null&&carouselScroll.getChildCount()>0){ViewGroup track=(ViewGroup)carouselScroll.getChildAt(0);for(int i=0;i<track.getChildCount();i++)((ViewGroup)track.getChildAt(i)).getChildAt(0).setVisibility(View.GONE);}
                }
            }
            super.onMeasure(w,h);
        }
    }

    /** Landscape reserves drawer space; portrait keeps the modal overlay. */
    private View withNavigation(View content) {
        content.setTag("workspace:content");
        if (navigationWidthDp > 0) {
            LinearLayout split = UiKit.row(this);
            View drawer = buildCollapsibleNav();
            drawer.setTag("navigation:drawer");
            drawer.setAccessibilityPaneTitle("导航菜单");
            split.addView(drawer, new LinearLayout.LayoutParams(dp(navigationWidthDp), -1));
            split.addView(content, new LinearLayout.LayoutParams(0, -1, 1));
            return split;
        }
        FrameLayout overlay = new FrameLayout(this);
        overlay.addView(content, new FrameLayout.LayoutParams(-1, -1));
        if (!navExpanded) return overlay;
        content.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
        View scrim = new View(this);
        scrim.setBackgroundColor(0x99000000);
        scrim.setContentDescription("关闭导航菜单");
        scrim.setOnClickListener(v -> { navExpanded = false; show(); });
        overlay.addView(scrim, new FrameLayout.LayoutParams(-1, -1));
        View drawer = buildCollapsibleNav();
        drawer.setTag("navigation:drawer");
        drawer.setAccessibilityPaneTitle("导航菜单");
        drawer.setElevation(dp(16));
        overlay.addView(drawer, new FrameLayout.LayoutParams(dp(Math.min(280, windowWidthDp - 48)), -1, Gravity.LEFT));
        return overlay;
    }

    private void refreshWorkbenchInPlace() {
        if (tab == 3 || workbenchHost == null) {
            show();
            return;
        }
        rememberScroll();
        scrollViews.clear();
        colorEditor = null;
        previews.clear();
        previews.addAll(carouselPreviews);
        workbenchHost.removeAllViews();
        buildIntegratedWorkbench(workbenchHost, policy.parallel);
    }

    private void selectPageInPlace(int pageIdx, int nextSlot, boolean switchFromPageTab, boolean smoothScroll) {
        history.finish();
        if (pageIdx < 0 || pageIdx >= draft.pages.size()) return;
        pageId = draft.pages.get(pageIdx).id;
        slot = Math.max(0, Math.min(nextSlot, page().count() - 1));
        libraryType = component().type;
        if (switchFromPageTab && browsingPages) { browsingPages=false;tab=1;selectionBaseline();show();return; }
        if (switchFromPageTab && tab == 2) tab = 1;
        selectionBaseline();
        if(pageTitle!=null)pageTitle.setText((draft.index(pageId)+1)+"/"+draft.pages.size()+" · "+page().name+" ▾");
        for(ClockFace f:carouselPreviews){f.editorSlot=f.pageIdForEditor().equals(pageId)?slot:-1;f.invalidate();}
        refreshWorkbenchInPlace();
        if (carouselScroll != null) {
            carouselScroll.setSelectedIndex(browsingPages?pageIdx:0, smoothScroll);
        }
    }

    private void applyFoldPanes() {
        if(localFold==null)return;
        if(horizontalFold){
            workspace.setOrientation(LinearLayout.VERTICAL);
            first.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(Math.max(0,localFold.top))));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,0,1);lp.topMargin=dp(Math.max(1,localFold.height()));second.setLayoutParams(lp);
        }else{
            first.setLayoutParams(new LinearLayout.LayoutParams(dp(Math.max(0,localFold.left)),-1));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1);lp.leftMargin=dp(Math.max(1,localFold.width()));second.setLayoutParams(lp);
        }
    }
    Rect dialogSafeBounds() { return dialogSafeBounds(null); }
    Rect dialogSafeBounds(WindowInsets override) {
        WindowMetrics metrics=getWindowManager().getCurrentWindowMetrics();
        WindowInsets value=override!=null?override:getWindow().getDecorView().getRootWindowInsets();if(value==null)value=metrics.getWindowInsets();
        Insets bars=value.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());
        Rect area=new Rect(bars.left,bars.top,metrics.getBounds().width()-bars.right,metrics.getBounds().height()-bars.bottom);
        if(foldBounds!=null){Rect f=new Rect(foldBounds);f.offset(-area.left,-area.top);Rect safe=largestRegion(area.width(),area.height(),f);safe.offset(area.left,area.top);return safe;}
        return area;
    }

    /** Collapsible navigation drawer replacing permanent top and side navigation chrome. */
    private View buildCollapsibleNav() {
        LinearLayout drawer = UiKit.column(this);
        drawer.setBackground(UiKit.surface(this, UiKit.PANEL, 0, UiKit.PANEL_BORDER, 1f));
        drawer.setPadding(dp(8), dp(8), dp(8), dp(8));

        LinearLayout top = UiKit.row(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = UiKit.text(this, "导航菜单", 12, UiKit.TEXT);
        heading.setTypeface(null, Typeface.BOLD);
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        top.addView(UiKit.compactButton(this, "收起 ×", UiKit.ROW, UiKit.ROW_BORDER, UiKit.MUTED, () -> {
            navExpanded = false;
            show();
        }));
        drawer.addView(top);
        UiKit.gap(this, drawer, 6);

        brandButton = UiKit.compactButton(
            this,
            "折光 / " + draft.name + " ▾",
            UiKit.SELECTOR_BG,
            UiKit.SELECTOR_BORDER,
            UiKit.TEXT,
            this::showSceneManagerDialog
        );
        brandButton.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.bottomMargin = dp(6);
        drawer.addView(brandButton, bp);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(true);
        LinearLayout col = UiKit.column(this);
        populateNavItems(col);
        sv.addView(col);
        drawer.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        return drawer;
    }

    private void populateNavItems(LinearLayout host) {
        UiKit.action(this, host, "⌂ 页面工作台", () -> {
            navExpanded = false;
            if (tab == 3) tab = 1;
            show();
        });
        UiKit.action(this, host, "⚙ 待机与全局设置", () -> {
            navExpanded = false;
            tab = 3;
            show();
        });
        String[] groups = { "显示与夜间", "页面与轮播", "组件数据", "检测与权限", "我的场景", "关于" };
        for (int i = 0; i < groups.length; i++) {
            final int n = i;
            TextView sub = UiKit.compactButton(this, "  · " + groups[i], UiKit.BG, 0, UiKit.MUTED, () -> {
                navExpanded = false;
                tab = 3;
                category = n;
                show();
            });
            sub.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(2);
            host.addView(sub, lp);
        }
    }

    /** Smartwatch-style 3D perspective page carousel acting as the sole real-time preview stage. */
    private void buildWatchCarouselStage(LinearLayout host, boolean fullHeight) {
        LinearLayout header=UiKit.row(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(6),dp(4),dp(6),0);
        header.addView(icon(navExpanded?"✕":"☰","导航菜单",()->{navExpanded=!navExpanded;show();}));
        TextView title=pageTitle=UiKit.text(this,(draft.index(pageId)+1)+"/"+draft.pages.size()+" · "+page().name+" ▾",12,UiKit.TEXT);
        title.setTypeface(null,Typeface.BOLD);title.setMaxLines(1);title.setEllipsize(android.text.TextUtils.TruncateAt.END);title.setMinHeight(dp(40));
        title.setGravity(Gravity.CENTER_VERTICAL);title.setPadding(dp(6),0,dp(4),0);title.setContentDescription("浏览页面 · "+page().name);
        title.setOnClickListener(v->{browsingPages=!browsingPages;portraitStyleScreen=false;show();});header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        header.addView(UiKit.compactButton(this,"布局",UiKit.PANEL,0,UiKit.TEXT,()->showLayoutPicker(false)));
        undoButton=icon("↶","撤销上一步",this::undoEdit);undoButton.setEnabled(history.canUndo());undoButton.setAlpha(history.canUndo()?1f:.35f);header.addView(undoButton);
        header.addView(icon("⋯","页面更多操作",this::showPageMenu));host.addView(header,new LinearLayout.LayoutParams(-1,-2));
        // 2. Scrollable Middle Carousel (enlarged selected page + shrunk 3D perspective neighbors, no outer boxes)
        carouselScroll = new WatchCarouselScrollView(this);
        carouselScroll.setVerticalScrollBarEnabled(false);
        carouselScroll.setClipToPadding(true);
        carouselScroll.setOverScrollMode(View.OVER_SCROLL_ALWAYS);

        LinearLayout track = UiKit.column(this);
        track.setGravity(Gravity.CENTER_HORIZONTAL);
        track.setPadding(dp(8), dp(2), dp(8), dp(2));

        int availW = paneInnerWidth(true);
        int selectedIndex = browsingPages ? draft.index(pageId) : 0;
        // Initial dimensions are refined from the actual viewport in carousel.onMeasure.
        int selectedH = Math.round(availW * 1248f / 1972f);

        final ArrayList<LinearLayout> itemViews = new ArrayList<>();
        for (int i = 0; i < draft.pages.size(); i++) {
            final int pageIdx = i;
            final Scene.Page p = draft.pages.get(i);
            if(!browsingPages&&!p.id.equals(pageId))continue;
            boolean selected = p.id.equals(pageId);

            LinearLayout item = UiKit.column(this);
            item.setGravity(Gravity.CENTER_HORIZONTAL);
            item.setTag("page:" + p.id);
            item.setContentDescription("页面预览 · " + p.name + " · 长按拖动排序");

            // Minimal floating label directly above preview (preserves exact "2  日历" hook)
            LinearLayout labelRow = UiKit.row(this);
            labelRow.setGravity(Gravity.CENTER);
            TextView label = UiKit.text(
                this,
                (i + 1) + "  " + p.name,
                11.5f,
                selected ? UiKit.ACCENT : UiKit.MUTED
            );
            label.setTypeface(null, selected ? Typeface.BOLD : Typeface.NORMAL);
            label.setMaxLines(1);label.setEllipsize(android.text.TextUtils.TruncateAt.END);label.setGravity(Gravity.CENTER);
            label.setPadding(dp(4), dp(1), dp(4), dp(2));
            labelRow.addView(label,new LinearLayout.LayoutParams(0,-2,1));
            if (p.id.equals(draft.home)) {
                TextView homeTag = UiKit.badge(this, "主页", UiKit.ACTIVE_BG, UiKit.ACTIVE_BORDER, UiKit.ACCENT);
                labelRow.addView(homeTag);
            }
            if(!browsingPages)labelRow.setVisibility(View.GONE);
            item.addView(labelRow, new LinearLayout.LayoutParams(-1, -2));

            // Pure black cover-ratio preview with unified layout size so scaleX/Y animates smoothly
            int previewH = selectedH;
            int previewW = Math.min(availW - 4, Math.round(previewH * 1972f / 1248f));
            AspectPreview frame = new AspectPreview(this);
            int borderPad = dp(2);
            frame.setPadding(borderPad, borderPad, borderPad, borderPad);
            GradientDrawable frameBg = UiKit.surface(
                this,
                0xff000000,
                10,
                selected ? UiKit.ACCENT : 0xff222d3d,
                selected ? 2.2f : 1.0f
            );
            frame.setBackground(frameBg);
            ClockFace face = new ClockFace(this, prefs);
            face.managedRefresh = true;
            face.bind(draft, i);
            face.nightPreview = previewNight;
            face.editorSlot=selected?slot:-1;
            face.setContentDescription("实时预览 · " + p.name);
            frame.addView(face);
            carouselPreviews.add(face);
            previews.add(face);
            item.addView(frame, new LinearLayout.LayoutParams(dp(previewW), dp(previewH)));

            // Apply initial 3D smartwatch perspective relative to selected page
            float density = getResources().getDisplayMetrics().density;
            item.setCameraDistance(4200 * density);
            if (selected) {
                item.setScaleX(1.0f);
                item.setScaleY(1.0f);
                item.setRotationX(0f);
                item.setTranslationZ(dp(6));
                item.setAlpha(1.0f);
            } else {
                int diff = i - selectedIndex;
                item.setScaleX(0.62f);
                item.setScaleY(0.62f);
                item.setRotationX(diff < 0 ? 20f : -20f);
                item.setTranslationZ(0f);
                item.setAlpha(0.44f);
            }

            // Selecting a page or slot updates workbench in-place with smooth centering
            label.setOnClickListener(v -> selectPageInPlace(pageIdx, 0, false, true));
            labelRow.setOnClickListener(v -> selectPageInPlace(pageIdx, 0, false, true));
            item.setOnClickListener(v -> selectPageInPlace(pageIdx, 0, false, true));
            face.slotTap = n -> selectPageInPlace(pageIdx, n, true, true);
            face.setOnClickListener(v -> selectPageInPlace(pageIdx, p.id.equals(pageId) ? slot : 0, true, true));

            View.OnLongClickListener drag = v -> {
                pageOverview = true;
                if(!browsingPages){browsingPages=true;show();return true;}
                if (v.isAttachedToWindow()) {
                    return v.startDragAndDrop(
                        ClipData.newPlainText("page", p.id),
                        new View.DragShadowBuilder(frame),
                        p.id,
                        0
                    );
                }
                return true;
            };
            item.setOnLongClickListener(drag);
            face.setOnLongClickListener(drag);
            label.setOnLongClickListener(drag);

            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
            ip.bottomMargin = (i + 1 < draft.pages.size()) ? dp(fullHeight ? 6 : 4) : 0;
            track.addView(item, ip);
            itemViews.add(item);
        }

        carouselScroll.bind(itemViews, selectedIndex, pageIdx -> {
            if (browsingPages && pageIdx >= 0 && pageIdx < draft.pages.size()) {
                String nextId = draft.pages.get(pageIdx).id;
                if (!nextId.equals(pageId)) {
                    selectPageInPlace(pageIdx, 0, false, false);
                }
            }
        });
        carouselScroll.onMove = (id, target) -> {
            draft.movePage(id, target);
            pageId = id;
            changed();
            handler.post(this::show);
        };
        carouselScroll.addView(track, new ViewGroup.LayoutParams(-1, -2));
        host.addView(carouselScroll, new LinearLayout.LayoutParams(-1, 0, 1));
        WatchCarouselScrollView stageScroll = carouselScroll;
        stageScroll.post(() -> {
            if (carouselScroll == stageScroll && stageScroll.snapAnimator == null) {
                stageScroll.centerIndex(stageScroll.selectedIndex, false);
            }
        });

        LinearLayout footer=UiKit.row(this);footer.setGravity(Gravity.CENTER_VERTICAL);footer.setTag("preview:tools");footer.setPadding(dp(6),dp(3),dp(6),dp(4));
        footer.addView(UiKit.compactButton(this,"＋ 页面",UiKit.ROW,UiKit.ROW_BORDER,UiKit.ACCENT,()->showLayoutPicker(true)));
        View spacer=new View(this);footer.addView(spacer,new LinearLayout.LayoutParams(0,1,1));
        footer.addView(icon(previewNight?"☾":"☀\uFE0E",previewNight?"切换日间预览":"切换夜间预览",()->{history.finish();previewNight=!previewNight;colorState.hex=null;colorContext="";show();}));
        footer.addView(icon("⛶","全屏预览当前页",this::launchFullscreenPreview));
        footer.addView(icon(previewExpanded?"⌃":"⌄",previewExpanded?"收起预览":"展开预览",()->{previewExpanded=!previewExpanded;show();}));
        host.addView(footer,new LinearLayout.LayoutParams(-1,-2));
    }
    private TextView icon(String text,String description,Runnable action){
        TextView view=UiKit.compactButton(this,text,UiKit.PANEL,0,UiKit.TEXT,action);view.setContentDescription(description);view.setTooltipText(description);
        view.setMinWidth(dp(40));view.setMinHeight(dp(40));view.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,UiKit.sp(16));return view;
    }
    private String regionName(int index){
        if(page().layout==0)return "整页";
        if(page().layout==3)return new String[]{"左上","右上","左下","右下"}[index];
        return index==0?"左侧":"右侧";
    }
    private void showPageMenu(){
        ArrayList<String> labels=new ArrayList<>();ArrayList<Runnable> actions=new ArrayList<>();
        labels.add("浏览与排序页面");actions.add(()->{browsingPages=true;show();});
        labels.add(page().id.equals(draft.home)?"✓ 当前主页":"设为主页");actions.add(()->{draft.home=pageId;changed();show();});
        labels.add("重命名页面");actions.add(()->input("页面名称",page().name,value->{page().name=value;page().autoName=false;changed();show();}));
        labels.add("名称跟随组件 · "+(page().autoName?"开":"关"));actions.add(()->{page().autoName=!page().autoName;changed();show();});
        labels.add("复制此页");actions.add(()->{Scene.Page copy=page().duplicate();draft.pages.add(draft.index(pageId)+1,copy);pageId=copy.id;changed();show();showNotice("已复制页面");});
        labels.add("移动到…");actions.add(()->{String[] positions=new String[draft.pages.size()];for(int i=0;i<positions.length;i++)positions[i]="第 "+(i+1)+" 页";new StudioAlertBuilder().setTitle("移动页面").setItems(positions,(d,n)->{draft.movePage(pageId,n);changed();show();}).show();});
        labels.add("添加页面");actions.add(()->showLayoutPicker(true));
        labels.add("全屏预览当前页");actions.add(this::launchFullscreenPreview);
        labels.add(previewNight?"切换日间预览":"切换夜间预览");actions.add(()->{previewNight=!previewNight;colorState.hex=null;show();});
        labels.add("重做"+(history.canRedo()?"":" · 暂无"));actions.add(this::redoEdit);
        labels.add("删除此页");actions.add(()->{if(draft.pages.size()==1){showNotice("至少保留一个页面");return;}int index=draft.index(pageId);Scene.Page old=page();draft.remove(old);pageId=draft.pages.get(Math.min(index,draft.pages.size()-1)).id;slot=0;changed();show();showNotice("已删除「"+old.name+"」");});
        new StudioAlertBuilder().setTitle(page().name).setItems(labels.toArray(new String[0]),(d,n)->actions.get(n).run()).setNegativeButton("关闭",null).show();
    }
    private void showLayoutPicker(boolean adding){
        InputDialog dialog=new InputDialog(this,adding?"添加页面":"页面布局",adding?"选择布局与默认搭配，随后点击区域修改内容":"切换布局会保留暂时隐藏的区域内容");
        LinearLayout content=dialog.content();
        for(int i=0;i<4;i++){
            final int layout=i;Scene sample=draft.copy();Scene.Page target=adding?new Scene.Page():sample.pages.get(sample.index(pageId));target.layout=i;
            if(adding){String[][] defaults={{"clock"},{"clock","weather"},{"clock","date"},{"clock","weather","date","battery"}};for(int n=0;n<defaults[i].length;n++)target.slots[n].setType(defaults[i][n]);target.refreshName();sample.pages.add(target);}
            LinearLayout card=UiKit.card(this,content,Dashboard.LAYOUTS[i]+" · "+target.contentName(),null);
            AspectPreview frame=new AspectPreview(this);ClockFace face=new ClockFace(this,prefs);face.managedRefresh=true;face.demo=true;face.bind(sample,sample.index(target.id));face.nightPreview=previewNight;frame.addView(face);card.addView(frame,new LinearLayout.LayoutParams(-1,dp(110)));
            Runnable choose=()->{history.finish();if(adding){Scene.Page page=Scene.Page.from(target.json());draft.pages.add(page);pageId=page.id;slot=0;}else{page().layout=layout;slot=Math.min(slot,page().count()-1);}browsingPages=false;tab=1;changed();dialog.dismiss();show();if(adding)showNotice("页面已添加 · 点击区域编辑");};
            face.setOnClickListener(v->choose.run());card.setOnClickListener(v->choose.run());UiKit.action(this,card,"使用"+Dashboard.LAYOUTS[i],choose);
        }
        openInputDialog(dialog);
    }

    /** Integrated right-pane (landscape) or lower-pane (portrait) Workbench unifying Styles, Edit, Palette, and Pages. */
    private void buildIntegratedWorkbench(LinearLayout host, boolean parallel) {
        int innerWidth=paneInnerWidth(false);
        LinearLayout header=UiKit.column(this);header.setPadding(dp(10),dp(6),dp(10),0);
        LinearLayout extras=UiKit.column(this);
        LinearLayout context=UiKit.row(this);context.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=UiKit.text(this,regionName(slot)+" · "+Scene.typeName(component().type),12,UiKit.ACCENT);title.setMaxLines(1);title.setEllipsize(android.text.TextUtils.TruncateAt.END);title.setTypeface(null,Typeface.BOLD);
        title.setContentDescription("当前编辑："+page().name+" · "+regionName(slot)+" · "+Scene.typeName(component().type));context.addView(title,new LinearLayout.LayoutParams(0,dp(40),1));
        TextView replace=UiKit.compactButton(this,"更换组件",UiKit.ROW,UiKit.ROW_BORDER,UiKit.TEXT,()->openSelector(true));context.addView(replace);header.addView(context);
        if(page().count()>1){
            HorizontalScrollView regions=new HorizontalScrollView(this);regions.setHorizontalScrollBarEnabled(false);LinearLayout row=UiKit.row(this);
            for(int i=0;i<page().count();i++){final int n=i;TextView button=UiKit.compactButton(this,regionName(i),i==slot?UiKit.ACTIVE_BG:UiKit.PANEL,0,i==slot?UiKit.ACCENT:UiKit.MUTED,()->{slot=n;browsingPages=false;libraryType=component().type;selectionBaseline();show();});row.addView(button);}
            regions.addView(row);extras.addView(regions);
        }
        LinearLayout tabs=UiKit.row(this);String[] names={"内容","外观","配色"};
        for(int i=0;i<3;i++){final int n=i;TextView button=UiKit.compactButton(this,names[i],studioPanel==i?UiKit.ACTIVE_BG:UiKit.PANEL,0,studioPanel==i?UiKit.ACCENT:UiKit.MUTED,()->{history.finish();studioPanel=n;browsingPages=false;show();});button.setTag("studio:tab:"+i);tabs.addView(button,new LinearLayout.LayoutParams(0,-2,1));}extras.addView(tabs);header.addView(extras);
        host.addView(header,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout body=scrollColumn(host,"studio:"+studioPanel+":"+pageId+":"+slot);body.setTag("studio:body");
        if(host instanceof EditorPane){EditorPane pane=(EditorPane)host;pane.fixedHeader=header;pane.extras=extras;pane.body=body;pane.compact=false;}
        if(!prefs.getBoolean("studio_guided",false)){UiKit.note(this,body,"点击预览中的区域选择组件；外观和配色随改随存，可撤销。");UiKit.action(this,body,"知道了",()->{prefs.edit().putBoolean("studio_guided",true).apply();show();});}
        if(studioPanel==2)renderStudioPalette(body,innerWidth);
        else if(studioPanel==1){
            LinearLayout style=UiKit.card(this,body,"组件外观",null);UiKit.action(this,style,"更换外观 · "+ComponentStyles.names(component().type)[ComponentStyles.selectedIndex(component())]+"  →",()->openSelector(false));
            if(component().type.equals("clock")){ComponentInspector.render(this,prefs,body,component(),0,paletteScope,innerWidth,inspectorHost());ComponentInspector.render(this,prefs,body,component(),1,paletteScope,innerWidth,inspectorHost());}
            else{UiKit.slider(this,style,"显示大小",component().options.optInt("scale",100),75,125,"%",v->{Scene.put(component().options,"scale",v);changed();});UiKit.toggle(this,style,"显示组件边框",component().bool("card",false),v->{Scene.put(component().options,"card",v);changed();});}
        }else ComponentInspector.render(this,prefs,body,component(),component().type.equals("clock")?3:0,paletteScope,innerWidth,inspectorHost());
        savedStatus=UiKit.text(this,"已自动保存",10,UiKit.MUTED);savedStatus.setPadding(dp(2),dp(8),0,0);body.addView(savedStatus);

    }
    private void openSelector(boolean types){history.finish();componentPicker=types;libraryType=component().type;portraitStyleScreen=true;show();}
    private void renderStudioPalette(LinearLayout body,int innerWidth){
        String[] names={"全场景","当前页","当前组件"};
        LinearLayout card=UiKit.card(this,body,previewNight?"夜间配色":"日间配色",null);
        UiKit.action(this,card,"应用范围 · "+names[Math.min(2,paletteScope)]+" ▾",()->new StudioAlertBuilder().setTitle("配色应用范围").setSingleChoiceItems(names,Math.min(2,paletteScope),(d,n)->{history.finish();paletteScope=n;colorState.hex=null;colorContext="";d.dismiss();show();}).show());
        if(previewNight){UiKit.toggle(this,card,"此场景使用独立夜间配色",Boolean.TRUE.equals(draft.ownNightColors),v->{draft.ownNightColors=v;changed();show();});if(!Boolean.TRUE.equals(draft.ownNightColors)){UiKit.note(this,card,"当前沿用日间配色。开启后可独立编辑夜间颜色。");return;}}
        JSONObject selected=theme(paletteScope);UiKit.note(this,card,selected.length()==0?"颜色来自上层主题":"此范围已有独立配色 · 可恢复跟随上层");
        int overrides=0;for(Scene.Page page:draft.pages){if(paletteScope==0&&(previewNight?page.nightTheme:page.theme).length()>0)overrides++;if(paletteScope==0||page.id.equals(pageId)&&paletteScope==1)for(int i=0;i<page.count();i++)if((previewNight?page.slots[i].nightTheme:page.slots[i].theme).length()>0)overrides++;}
        if(overrides>0){final int scope=paletteScope;UiKit.note(this,card,"有 "+overrides+" 处独立配色，会优先于本次修改。");UiKit.action(this,card,"让下级恢复跟随",()->{for(Scene.Page page:draft.pages){if(scope==0)clearTheme(previewNight?page.nightTheme:page.theme);if(scope==0||scope==1&&page.id.equals(pageId))for(Scene.Component c:page.slots)clearTheme(previewNight?c.nightTheme:c.theme);}changed();show();showNotice("已恢复跟随");});}
        palette(card,paletteScope);
    }
    private void clearTheme(JSONObject theme){ArrayList<String> keys=new ArrayList<>();for(Iterator<String> i=theme.keys();i.hasNext();)keys.add(i.next());for(String key:keys)theme.remove(key);}

    /** Secondary full-screen Style Gallery in portrait (style previews are self-contained live ClockFaces). */
    private void renderPortraitStyleScreen(LinearLayout root) {
        LinearLayout top=UiKit.row(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(10),dp(6),dp(10),dp(4));
        top.addView(UiKit.compactButton(this,"← 返回编辑",UiKit.ROW,UiKit.ROW_BORDER,UiKit.ACCENT,()->{portraitStyleScreen=componentPicker=false;tab=1;show();}));
        TextView target=UiKit.text(this,(componentPicker?"更换组件":"更换外观")+" · "+regionName(slot),12,UiKit.TEXT);target.setPadding(dp(8),0,0,0);target.setMaxLines(2);top.addView(target,new LinearLayout.LayoutParams(0,-2,1));root.addView(top);
        LinearLayout body=scrollColumn(root,"selector:"+componentPicker+":"+libraryType);renderStyleGalleryBody(body,Math.max(120,widthDp-44));
    }
    private void renderStyleGalleryBody(LinearLayout host,int innerWidth){
        if(libraryType==null)libraryType=component().type;
        String[] names=componentPicker?Scene.TYPE_NAMES:ComponentStyles.names(libraryType);
        int cols=Math.max(1,Math.min(names.length==4?2:3,innerWidth/Math.round(145*Math.max(1f,getResources().getConfiguration().fontScale*UiKit.customFontScale*.8f))));
        for(int start=0;start<names.length;start+=cols){
            LinearLayout row=UiKit.row(this);
            for(int k=start;k<Math.min(start+cols,names.length);k++){
                final int n=k;final String type=componentPicker?Scene.TYPES[k]:libraryType;final boolean types=componentPicker;
                boolean active=types?component().type.equals(type):isVariantActive(component(),type,n);
                LinearLayout card=UiKit.column(this);card.setPadding(dp(8),dp(8),dp(8),dp(8));card.setBackground(UiKit.surface(this,active?UiKit.ACTIVE_BG:UiKit.ROW,12,active?UiKit.ACTIVE_BORDER:UiKit.ROW_BORDER,1));
                Scene sample=draft.copy();Scene.Page page=sample.pages.get(sample.index(pageId));page.layout=0;Scene.Component c=Scene.Component.from(component().json());page.slots[0]=c;
                if(types)c.setType(type);else applyVariant(c,type,n);
                if(type.equals("todo")&&TodoItems.all(c).length()==0)TodoItems.add(c,"准备明天的计划");
                AspectPreview frame=new AspectPreview(this);ClockFace face=new ClockFace(this,prefs);face.managedRefresh=true;face.demo=true;face.bind(sample,sample.index(pageId));face.nightPreview=previewNight;frame.addView(face);previews.add(face);card.addView(frame,new LinearLayout.LayoutParams(-1,dp(policy.shortWindow?90:120)));
                TextView name=UiKit.text(this,(active?"✓ ":"")+names[k],12,active?UiKit.ACCENT:UiKit.TEXT);name.setGravity(Gravity.CENTER);name.setPadding(0,dp(6),0,dp(4));card.addView(name);
                Runnable choose=()->{history.finish();if(types)component().setType(type);else applyVariant(component(),type,n);libraryType=component().type;portraitStyleScreen=componentPicker=false;browsingPages=false;tab=1;changed();show();};
                face.setOnClickListener(v->choose.run());name.setOnClickListener(v->choose.run());card.setOnClickListener(v->choose.run());card.setContentDescription((types?"更换组件 · ":"应用外观 · ")+names[k]);card.setTag(types?"component:"+type:"style:"+type+":"+ComponentStyles.ids(type)[n]);
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(0,0,k+1<Math.min(start+cols,names.length)?dp(8):0,dp(8));row.addView(card,lp);
            }
            for(int i=Math.min(start+cols,names.length);i<start+cols;i++)row.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));host.addView(row);
        }
    }

    private boolean isVariantActive(Scene.Component c, String type, int variant) {
        if (!c.type.equals(type)) return false;
        return ComponentStyles.selectedIndex(c) == variant;
    }

    private void applyVariant(Scene.Component c, String type, int variant) {
        ComponentStyles.select(c, type, variant);
    }

    private ComponentInspector.Host inspectorHost() {
        return new ComponentInspector.Host() {
            public void onDraftChanged() { changed(); }
            public void onRebuild() { show(); }
            public void onSwitchComponentType(String newType) {
                component().setType(newType);
                inspectorGroup = 0;
                libraryType = newType;
                changed();
                show();
            }
            public void onSelectPaletteScope(int scope) {
                paletteScope = scope;
                colorState.hex = null;
                if (scope == 3) { paletteScope=0;previewNight=true; }
                show();
            }
            public void onEmbedPalette(LinearLayout host, int scope) { palette(host, scope); }
            public void onOpenTimezone(Scene.Component c) { zone(c); }
            public void onOpenCitySearch() { city(); }
            public void onUseCurrentLocation() { useCurrentLocation(); }
            public void onOpenCoordinates() { coordinates(); }
            public void onOpenTodoInput(String title, String initial, Consumer<String> onValue) { input(title, initial, onValue); }
            public void onRequestCalendarPermission() {
                requestPermissions(new String[] { android.Manifest.permission.READ_CALENDAR }, 12);
            }
            public void onRequestMusicPermission() { musicPermission(); }
        };
    }

    private boolean parallelSettings() { return widthDp >= Math.round(550*Math.max(1f,getResources().getConfiguration().fontScale*UiKit.customFontScale*.8f)) && heightDp>=260; }

    private int settingsMenuWidthDp() { return Math.min(220, Math.max(140, Math.round(widthDp * .27f))); }

    /** Settings use a category/detail split in landscape and a single list in portrait. */
    private void renderSettingsShell(LinearLayout root) {
        workspace = UiKit.row(this);
        workspace.setPadding(dp(6), dp(5), dp(6), dp(6));
        root.addView(workspace, new LinearLayout.LayoutParams(-1, 0, 1));
        first = UiKit.column(this);
        first.setBackground(UiKit.surface(this, UiKit.PANEL, 14, UiKit.PANEL_BORDER, 1f));
        workspace.addView(first, new LinearLayout.LayoutParams(parallelSettings() ? dp(settingsMenuWidthDp()) : -1, -1));

        LinearLayout top = UiKit.row(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8), dp(6), dp(8), dp(4));
        top.addView(UiKit.compactButton(this, navExpanded ? "✕" : "☰", UiKit.ROW, UiKit.ROW_BORDER, UiKit.TEXT, () -> {
            navExpanded = !navExpanded;
            show();
        }));
        first.addView(top, new LinearLayout.LayoutParams(-1, -2));
        String[] groups = { "显示与夜间", "页面与轮播", "组件数据", "检测与权限", "我的场景", "关于" };
        if (parallelSettings()) {
            TextView heading = UiKit.text(this, "设置", 13, UiKit.TEXT);
            heading.setTypeface(null, Typeface.BOLD);
            heading.setPadding(dp(8), 0, 0, 0);
            top.addView(heading);
            LinearLayout menu = scrollColumn(first, "settingsMenu");
            first.setTag("settings:categories");
            for (int i = 0; i < groups.length; i++) {
                final int n = i;
                boolean selected = i == category;
                TextView button = UiKit.styledButton(this, groups[i], selected ? UiKit.ACTIVE_BG : UiKit.ROW,
                    selected ? UiKit.ACTIVE_BORDER : UiKit.ROW_BORDER, selected ? UiKit.ACCENT : UiKit.TEXT,
                    () -> { category = n; show(); });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                lp.bottomMargin = dp(4);
                menu.addView(button, lp);
            }
            second = UiKit.column(this);
            second.setBackground(UiKit.surface(this, UiKit.PANEL, 14, UiKit.PANEL_BORDER, 1f));
            LinearLayout.LayoutParams detail = new LinearLayout.LayoutParams(0, -1, 1);
            detail.leftMargin = dp(8);
            workspace.addView(second, detail);
        } else {
            LinearLayout picker = UiKit.column(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.leftMargin = dp(6);
            top.addView(picker, lp);
            UiKit.choice(this, picker, "设置", groups, category, n -> { category = n; show(); });
            second = first;
        }
        second.setTag("settings:detail");
        settings(second);
    }

    private void settings(LinearLayout host) {
        String[] groups = { "显示与夜间", "页面与轮播", "组件数据", "检测与权限", "我的场景", "关于" };
        LinearLayout l = scrollColumn(host, "settings:" + category);
        int innerWidth = Math.max(200, widthDp - (parallelSettings() ? settingsMenuWidthDp() + 8 : 0) - 48);
        if (parallelSettings()) UiKit.title(this, l, groups[category], null);

        switch (category) {
            case 0: {
                LinearLayout uiCard = UiKit.card(this, l, "界面与文字大小", null);
                String[] scaleNames = { "小 (85%)", "标准 (100%)", "大 (115%)", "特大 (130%)" };
                float[] scaleVals = { 0.85f, 1.0f, 1.15f, 1.3f };
                float curScale = prefs.getFloat("uiFontScale", 1.0f);
                int curScaleIdx = 1;
                for (int i = 0; i < scaleVals.length; i++) {
                    if (Math.abs(scaleVals[i] - curScale) < 0.04f) curScaleIdx = i;
                }
                UiKit.chips(this, uiCard, innerWidth, scaleNames, curScaleIdx, n -> {
                    prefs.edit().putFloat("uiFontScale", scaleVals[n]).apply();
                    show();
                });

                LinearLayout brightCard = UiKit.card(this, l, "日夜亮度与时段", null);
                prefToggle(brightCard, "按时段进入夜间", "night", true);
                hours(brightCard, "夜间开始", "nightStart", 22);
                hours(brightCard, "夜间结束", "nightEnd", 7);
                UiKit.slider(this, brightCard, "日间亮度", Math.round(prefs.getFloat("brightness", .25f) * 100), 10, 100, "%",
                    v -> prefs.edit().putFloat("brightness", v / 100f).apply());
                UiKit.nightBrightnessSlider(this, brightCard, "夜间亮度", prefs.getFloat("nightBrightness", .06f),
                    v -> prefs.edit().putFloat("nightBrightness", v).apply());
                prefToggle(brightCard, "夜间联动系统极暗", "nightExtraDim", true);

                LinearLayout sleepCard = UiKit.card(this, l, "夜间按需显示与息屏", null);
                prefToggle(sleepCard, "夜间按需显示，允许系统息屏", "nightSleep", true);
                prefChoice(sleepCard, "短时查看", new String[] { "10 秒", "20 秒", "30 秒", "60 秒" }, new int[] { 10, 20, 30, 60 }, "nightViewSeconds", 20);
        

                LinearLayout nightThemeCard = UiKit.card(this, l, "独立夜间配色", null);
                UiKit.toggle(this,nightThemeCard,"此场景使用独立夜间配色",Boolean.TRUE.equals(draft.ownNightColors),v->{draft.ownNightColors=v;changed();show();});
                UiKit.action(this, nightThemeCard, "应用暖红夜间预设", () -> {
                    ColorThemes.apply(draft.nightTheme, 11);
                    draft.ownNightColors=true;
                    previewNight = true;
                    changed();
                    show();
                });
                UiKit.action(this,nightThemeCard,"编辑夜间配色  →",()->{previewNight=true;paletteScope=0;studioPanel=2;tab=1;browsingPages=false;show();});
                break;
            }
            case 1: {
                LinearLayout homeCard = UiKit.card(this, l, "主页与返回策略", null);
                UiKit.action(this, homeCard, "主页 · " + draft.pages.get(draft.homeIndex()).name, () -> {
                    String[] names = new String[draft.pages.size()];
                    for (int i = 0; i < names.length; i++) names[i] = draft.pages.get(i).name;
                    new StudioAlertBuilder()
                        .setTitle("指定主页")
                        .setSingleChoiceItems(names, draft.homeIndex(), (d, n) -> {
                            draft.home = draft.pages.get(n).id;
                            d.dismiss();
                            changed();
                            show();
                        })
                        .show();
                });
                prefChoice(homeCard, "闲置返回主页", new String[] { "关闭", "15 秒", "30 秒", "60 秒", "120 秒" }, new int[] { 0, 15, 30, 60, 120 }, "homeAfter", 60);

                LinearLayout motionCard = UiKit.card(this, l, "自动轮播与页面过渡", null);
                prefToggle(motionCard, "自动轮播", "autoplay", false);
                prefChoice(motionCard, "轮播间隔", new String[] { "10 秒", "20 秒", "30 秒", "60 秒" }, new int[] { 10, 20, 30, 60 }, "pageInterval", 20);
                prefChoice(motionCard, "页面切换动画", PageMotion.NAMES, new int[] { 0, 1, 2 }, "pageMotion", 0);
                prefChoice(motionCard, "切换速度", new String[] { "轻快", "自然", "舒缓" }, new int[] { 240, 360, 520 }, "pageMotionDuration", 360);
                prefToggle(motionCard, "动态效果", "motion", true);

                break;
            }
            case 2: {
                LinearLayout weatherCard = UiKit.card(this, l, "天气数据源", null);
                UiKit.action(this, weatherCard, "使用当前位置", this::useCurrentLocation);
                UiKit.action(this, weatherCard, "天气城市 · " + WeatherCities.simplified(prefs.getString("city", "未选择")), this::city);
                UiKit.action(this, weatherCard, "使用经纬度设置城市", this::coordinates);
                UiKit.note(
                    this,
                    weatherCard,
                    "定位权限 · " + (WeatherLocation.allowed(this) ? "已允许近似定位" : "未授权，点击使用当前位置时申请")
                );
                UiKit.note(
                    this,
                    weatherCard,
                    DeskData.weatherBusy
                        ? "天气更新中…"
                        : DeskData.weatherError.isEmpty()
                            ? (DeskData.weatherAt > 0 ? "天气已缓存，自动定时更新" : "选择城市后自动更新天气")
                            : DeskData.weatherError + "；已有缓存会继续显示"
                );
                prefToggle(weatherCard, "华氏温度", "fahrenheit", false);
                UiKit.action(this, weatherCard, "刷新天气", () -> {
                    DeskData.refresh(this, true);
                    Toast.makeText(this, "已请求更新", Toast.LENGTH_SHORT).show();
                });

                LinearLayout focusCard = UiKit.card(this, l, "番茄专注默认值", null);
                prefChoice(focusCard, "专注时长", new String[] { "5 分钟", "15 分钟", "25 分钟", "45 分钟", "60 分钟" }, new int[] { 5, 15, 25, 45, 60 }, "focusMinutes", 25);
                UiKit.action(this, focusCard, "重置专注", () -> {
                    DeskData.resetFocus(prefs);
                    Toast.makeText(this, "专注计时已重置", Toast.LENGTH_SHORT).show();
                });
                ComponentInspector.alarmDataCard(this, l);
                break;
            }
            case 3: {
                LinearLayout postureCard = UiKit.card(this, l, "帐篷与支架自动识别", StandbyService.status);
                UiKit.statusAction(
                    this,
                    postureCard,
                    StandbyService.running ? "停止检测" : "开启检测",
                    StandbyService.running,
                    this::toggleStandbyService
                );
                UiKit.note(this, postureCard, "半折支起、锁屏，静置 3 秒进入待机。");
                prefToggle(postureCard, "自动识别帐篷姿态", "detectTent", true);
                prefToggle(postureCard, "自动识别悬停与支架姿态", "detectStand", true);


                LinearLayout permCard = UiKit.card(this, l, "组件权限与锁屏隐私", null);
                prefToggle(permCard, "锁屏显示日程与待办详情", "private", false);
                UiKit.action(this, permCard, "日历授权", () -> requestPermissions(new String[] { android.Manifest.permission.READ_CALENDAR }, 12));
                UiKit.action(this, permCard, "音乐授权", this::musicPermission);
                UiKit.action(this, permCard, "通知显示", () -> startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())));
                UiKit.action(this, permCard, "系统权限", () -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
                break;
            }
            case 4: {
                LinearLayout currentCard = UiKit.card(this, l, "当前场景 · " + draft.name, null);
                UiKit.action(this, currentCard, "另存为命名场景", () -> input("场景名称", draft.name, value -> {
                    saveNamedScene(value);
                    show();
                }));
                UiKit.action(this, currentCard, "重命名当前场景", () -> input("场景名称", draft.name, value -> {
                    draft.name = value;
                    changed();
                    show();
                }));
                UiKit.dangerAction(this, currentCard, "恢复默认初始场景", () -> withRecovery("替换场景前", () -> {
                    SharedPreferences fresh = getSharedPreferences("default_template", 0);
                    fresh.edit().clear().commit();
                    draft = Scene.load(fresh);
                    pageId = draft.home;
                    slot = 0;
                    libraryType = component().type;
                    changed();
                    show();
                }));

                UiKit.action(this,currentCard,"恢复点与找回配置  →",this::showRecoveryPoints);
                LinearLayout savedCard = UiKit.card(this, l, "已保存的完整场景快照", "包含待办内容与完成状态；载入会替换当前场景");
                ArrayList<String> names = new ArrayList<>();
                for (String key : prefs.getAll().keySet()) {
                    if (key.startsWith("scene_saved_")) names.add(key.substring(12));
                }
                Collections.sort(names);
                for (String name : names) {
                    UiKit.action(this, savedCard, name, () -> new StudioAlertBuilder()
                        .setTitle(name)
                        .setItems(new String[] { "载入场景", "删除保存的场景" }, (d, n) -> {
                            if (n == 1) {
                                saveRecoveryPoint("删除快照「"+name+"」前");
                                prefs.edit().remove("scene_saved_" + name).apply();changed();
                                show();showNotice("已删除场景快照");
                            } else {
                                withRecovery("替换场景前", () -> {
                                    Scene s = Scene.parse(prefs.getString("scene_saved_" + name, ""));
                                    if (s != null) {
                                    if(s.ownNightColors==null)s.ownNightColors=prefs.getBoolean("nightOwnColors",false);
                    draft = s;
                                        pageId = s.home;
                                        slot = 0;
                                        libraryType = component().type;
                                        changed();
                                        show();
                                    }
                                });
                            }
                        })
                        .show());
                }
                if (names.isEmpty()) {
                    UiKit.note(this, savedCard, "暂无保存的场景");
                }
                ArrayList<String> legacy = new ArrayList<>();
                for (String key : prefs.getAll().keySet()) {
                    if (key.startsWith("saved_")) legacy.add(key.substring(6));
                }
                for (String name : legacy) {
                    UiKit.action(this, savedCard, "旧版搭配 · " + name, () -> withRecovery("替换场景前", () -> {
                        SharedPreferences migration = getSharedPreferences("legacy_import", 0);
                        migration.edit().clear().commit();
                        Dashboard.restore(migration, prefs.getString("saved_" + name, ""));
                        draft = Scene.load(migration);
                        draft.name = name;
                        pageId = draft.home;
                        slot = 0;
                        libraryType = component().type;
                        changed();
                        show();
                    }));
                }
                break;
            }
            default: {
                LinearLayout infoCard = UiKit.card(this, l, "折光时钟 " + BuildConfig.VERSION_NAME, null);



                LinearLayout diagCard = UiKit.card(this, l, "设备诊断与屏幕恢复", null);
                UiKit.action(this, diagCard, "设备诊断", () -> message(Fold.diagnostics(this) + "\n" + StandbyService.status));
                UiKit.action(this, diagCard, "恢复屏幕", () -> {
                    try {
                        if (Fold.supported(this)) Fold.release(this);
                    } catch (Exception e) {
                        message("恢复失败，请合上后重新展开。");
                    }
                });

                LinearLayout creditCard = UiKit.card(this, l, "数据源与许可", null);
                UiKit.note(this, creditCard, "天气：Open-Meteo · 外屏控制：fold-toggle / MIT\n无账号、广告或遥测。");
                break;
            }
        }
    }

    private void toggleStandbyService() {
        if (StandbyService.running) {
            stopService(new Intent(this, StandbyService.class));
        } else if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        } else {
            startForegroundService(new Intent(this, StandbyService.class));
        }
        handler.postDelayed(this::show, 500);
    }

    private void showSceneManagerDialog() {
        ArrayList<String> items = new ArrayList<>();
        ArrayList<Runnable> actions = new ArrayList<>();
        items.add("另存为命名场景…");
        actions.add(() -> input("场景名称", draft.name, value -> {
            saveNamedScene(value);
            show();
        }));
        items.add("重命名当前场景…");
        actions.add(() -> input("场景名称", draft.name, value -> {
            draft.name = value;
            changed();
            show();
        }));
        ArrayList<String> names = new ArrayList<>();
        for (String key : prefs.getAll().keySet()) {
            if (key.startsWith("scene_saved_")) names.add(key.substring(12));
        }
        Collections.sort(names);
        for (String name : names) {
            items.add("载入场景 · " + name);
            actions.add(() -> withRecovery("替换场景前", () -> {
                Scene s = Scene.parse(prefs.getString("scene_saved_" + name, ""));
                if (s != null) {
                    if(s.ownNightColors==null)s.ownNightColors=prefs.getBoolean("nightOwnColors",false);
                    draft = s;
                    pageId = s.home;
                    slot = 0;
                    libraryType = component().type;
                    changed();
                    show();
                }
            }));
        }
        items.add("打开完整场景管理  →");
        actions.add(() -> { navExpanded = false; tab = 3; category = 4; show(); });

        new StudioAlertBuilder()
            .setTitle("当前场景 · " + draft.name)
            .setItems(items.toArray(new String[0]), (d, which) -> actions.get(which).run())
            .setNegativeButton("关闭", null)
            .show();
    }

    private void prefToggle(LinearLayout l, String label, String key, boolean def) {
        UiKit.toggle(this, l, label, prefs.getBoolean(key, def), v -> prefs.edit().putBoolean(key, v).apply());
    }

    private void prefChoice(LinearLayout l, String label, String[] names, int[] values, String key, int def) {
        int at = 0;
        for (int i = 0; i < values.length; i++) if (values[i] == prefs.getInt(key, def)) at = i;
        UiKit.choice(this, l, label, names, at, n -> {
            if (key.equals("focusMinutes")) DeskData.setFocusMinutes(prefs, values[n]);
            else prefs.edit().putInt(key, values[n]).apply();
            show();
        });
    }

    private void hours(LinearLayout l, String label, String key, int def) {
        UiKit.action(
            this,
            l,
            label + "  ·  " + String.format(Locale.ROOT, "%02d:%02d", prefs.getInt(key, def), prefs.getInt(key + "Minute", 0)),
            () -> new TimePickerDialog(
                this,
                (view, h, m) -> {
                    prefs.edit().putInt(key, h).putInt(key + "Minute", m).apply();
                    show();
                },
                prefs.getInt(key, def),
                prefs.getInt(key + "Minute", 0),
                true
            ).show()
        );
    }

    private JSONObject theme(int scope) {
        boolean night=scope==3||previewNight;
        return scope==0?(night?draft.nightTheme:draft.theme):scope==1?(night?page().nightTheme:page().theme):scope==2?(night?component().nightTheme:component().theme):draft.nightTheme;
    }

    private int resolvedColor(int scope,int role){
        if(role==0)return Color.BLACK;
        String key=Scene.ROLES[role];boolean night=scope==3||previewNight;
        int value=draft.theme.optInt(key,Scene.DEFAULT_COLORS[role]);
        if(night)value=draft.nightTheme.optInt(key,value);
        if(scope==1||scope==2)value=(night?page().nightTheme:page().theme).optInt(key,value);
        if(scope==2)value=(night?component().nightTheme:component().theme).optInt(key,value);return value;
    }

    private void rememberColor(String value) {
        LinkedHashSet<String> colors = new LinkedHashSet<>();
        colors.add(value);
        String previous = prefs.getString("recentColors", "");
        if (!previous.isEmpty()) colors.addAll(Arrays.asList(previous.split(",")));
        ArrayList<String> list = new ArrayList<>(colors);
        if (list.size() > 6) list = new ArrayList<>(list.subList(0, 6));
        prefs.edit().putString("recentColors", TextUtils.join(",", list)).apply();
    }

    private void palette(LinearLayout host, int scope) {
        String key = tab + ":" + pageId + ":" + component().id + ":" + scope + ":" + previewNight;
        if (!key.equals(colorContext)) {
            colorState.hex = null;
            colorContext = key;
        }
        colorEditor = new PaletteEditor(
            this,
            theme(scope),
            role -> resolvedColor(scope, role),
            colorState,
            prefs.getString("recentColors", ""),
            this::changed,
            this::rememberColor,
            scope==2?component():null, scope==3||previewNight, scope==0||scope==3?"恢复默认":"恢复跟随"
        );
        host.addView(colorEditor, new LinearLayout.LayoutParams(-1, -2));
    }

    private void zone(Scene.Component c) {
        InputDialog dialog = new InputDialog(this, "世界时区", "输入城市英文名或时区，点击结果即可选择");
        InputDialog.Field search = dialog.field("搜索时区", "例如 Shanghai / Asia", "", InputType.TYPE_CLASS_TEXT);
        ArrayList<String> all = new ArrayList<>(Arrays.asList(TimeZone.getAvailableIDs()));
        ListView list = dialog.list(new ArrayList<>(all));
        @SuppressWarnings("unchecked")
        ArrayAdapter<String> adapter = (ArrayAdapter<String>) list.getAdapter();
        list.setOnItemClickListener((p, v, n, id) -> {
            Scene.put(c.options, "zone", adapter.getItem(n));
            changed();
            dialog.dismiss();
            show();
        });
        search.input.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int d) {}
            public void onTextChanged(CharSequence s, int a, int b, int d) {
                String query = s.toString().trim().toLowerCase(Locale.ROOT);
                ArrayList<String> matches = new ArrayList<>();
                for (String zone : all) if (zone.toLowerCase(Locale.ROOT).contains(query)) matches.add(zone);
                adapter.setNotifyOnChange(false);
                adapter.clear();
                adapter.addAll(matches);
                adapter.notifyDataSetChanged();
            }
            public void afterTextChanged(Editable e) {}
        });
        UiKit.inputAction(search.input, android.view.inputmethod.EditorInfo.IME_ACTION_DONE);
        search.input.setOnEditorActionListener((v, action, event) -> {
            if (action != android.view.inputmethod.EditorInfo.IME_ACTION_DONE) return false;
            getSystemService(android.view.inputmethod.InputMethodManager.class).hideSoftInputFromWindow(v.getWindowToken(), 0);
            return true;
        });
        openInputDialog(dialog);
    }

    private void input(String label, String initial, Consumer<String> cb) {
        boolean todo = label.equals("待办内容");
        boolean adding = todo && initial.isEmpty();
        InputDialog dialog = new InputDialog(this,
            todo ? (adding ? "添加待办" : "修改待办") : label,
            todo ? "记下一件要做的事，添加后自动保存" : "起一个便于辨认的名称");
        InputDialog.Field field = dialog.field(label, todo ? "例如：阅读二十分钟" : "请输入" + label, initial,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        dialog.primary(adding ? "添加" : "保存", android.view.inputmethod.EditorInfo.IME_ACTION_DONE, () -> {
            if (!field.require(todo ? "请输入待办内容" : "请输入名称")) return;
            cb.accept(field.value());
            dialog.dismiss();
        });
        openInputDialog(dialog);
    }

    private void openInputDialog(InputDialog dialog) {
        if (inputDialog != null) inputDialog.dismiss();
        inputDialog = dialog;
        dialog.setOnDismissListener(d -> { if (inputDialog == dialog) inputDialog = null; });
        dialog.show();
    }

    private void city() {
        InputDialog dialog = new InputDialog(this, "搜索天气城市", "支持简体、繁体和英文城市名");
        InputDialog.Field search = dialog.field("城市名称", "例如：西雅图 / Seattle", "", InputType.TYPE_CLASS_TEXT);
        dialog.secondary("使用当前位置", this::useCurrentLocation);
        dialog.primary("搜索", android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH, () -> {
            if (!search.require("请输入城市名称")) return;
            dialog.dismiss();
            searchCity(search.value());
        });
        openInputDialog(dialog);
    }

    private void searchCity(String query) {
        if (searchDialog != null) searchDialog.dismiss();
        AlertDialog progress = new StudioAlertBuilder()
            .setMessage("正在搜索城市…")
            .setNegativeButton("取消", null)
            .create();
        searchDialog = progress;
        progress.show();
        DeskData.search(query, (cities, error) -> {
            if (!progress.isShowing()) return;
            progress.dismiss();
            if (searchDialog == progress) searchDialog = null;
            if (isFinishing() || isDestroyed()) return;
            if (cities == null || cities.length() == 0) {
                new StudioAlertBuilder()
                    .setMessage(error.isEmpty() ? "未找到城市，可换用其他城市名称、当前位置或经纬度。" : error)
                    .setNeutralButton("使用当前位置", (d, n) -> useCurrentLocation())
                    .setPositiveButton("经纬度设置", (d, n) -> coordinates())
                    .setNegativeButton("重新搜索", (d, n) -> city())
                    .show();
                return;
            }
            String[] names = new String[cities.length()];
            for (int i = 0; i < names.length; i++) {
                names[i] = WeatherCities.label(cities.optJSONObject(i));
            }
            InputDialog choices = new InputDialog(this, "选择城市", "点击对应地区，应用到天气组件");
            ListView list = choices.list(Arrays.asList(names));
            list.setOnItemClickListener((parent, view, n, id) -> {
                JSONObject c = cities.optJSONObject(n);
                setCity(WeatherCities.simplified(c.optString("name")), c.optString("latitude"), c.optString("longitude"));
                choices.dismiss();
            });
            openInputDialog(choices);
        });
    }

    private void useCurrentLocation() {
        if (!WeatherLocation.allowed(this)) {
            if (prefs.getBoolean("weatherLocationAsked", false)
                && !shouldShowRequestPermissionRationale(android.Manifest.permission.ACCESS_COARSE_LOCATION)) {
                new StudioAlertBuilder()
                    .setMessage("定位权限尚未开启，可在应用权限中允许位置信息，或继续搜索城市。")
                    .setPositiveButton("打开应用权限", (d, n) -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))))
                    .setNeutralButton("搜索城市", (d, n) -> city())
                    .setNegativeButton("取消", null)
                    .show();
                return;
            }
            prefs.edit().putBoolean("weatherLocationAsked", true).apply();
            requestPermissions(new String[] { android.Manifest.permission.ACCESS_COARSE_LOCATION }, WEATHER_LOCATION_PERMISSION);
            return;
        }
        prefs.edit().remove("weatherLocationAsked").apply();
        cancelWeatherLocation();
        AlertDialog progress = new StudioAlertBuilder()
            .setMessage("正在获取当前位置…")
            .setNegativeButton("取消", null)
            .create();
        locationDialog = progress;
        progress.setOnDismissListener(d -> {
            if (locationDialog == progress) cancelWeatherLocation();
        });
        progress.show();
        locationRequest = new WeatherLocation.Request(this, (loc, name, error) -> {
            cancelWeatherLocation();
            if (isFinishing() || isDestroyed()) return;
            if (loc != null) {
                setCity(name, String.format(Locale.ROOT, "%.4f", loc.getLatitude()), String.format(Locale.ROOT, "%.4f", loc.getLongitude()));
                Toast.makeText(this, "已定位到 " + name, Toast.LENGTH_SHORT).show();
            } else {
                new StudioAlertBuilder()
                    .setMessage(error)
                    .setPositiveButton(error.contains("系统定位未开启") ? "定位设置" : "重试", (d, n) -> {
                        if (error.contains("系统定位未开启")) startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                        else useCurrentLocation();
                    })
                    .setNeutralButton("搜索城市", (d, n) -> city())
                    .setNegativeButton("关闭", null)
                    .show();
            }
        });
        locationRequest.start();
    }

    private void cancelWeatherLocation() {
        if (locationRequest != null) locationRequest.cancel();
        locationRequest = null;
        AlertDialog progress = locationDialog;
        locationDialog = null;
        if (progress != null) progress.dismiss();
    }

    private void setCity(String name, String lat, String lon) {
        prefs.edit()
            .putString("city", WeatherCities.simplified(name))
            .putString("lat", lat)
            .putString("lon", lon)
            .remove("weatherCache")
            .remove("weatherAt")
            .apply();
        DeskData.weather = null;
        DeskData.weatherAt = 0;
        DeskData.weatherError = "";
        DeskData.weatherFailures = 0;
        DeskData.attempted = 0;
        if (!testMode) DeskData.refresh(this, true);
        show();
    }

    private void coordinates() {
        InputDialog dialog = new InputDialog(this, "按经纬度设置城市", "为天气地点指定名称与坐标");
        InputDialog.Field name = dialog.field("城市名称", "例如：上海", WeatherCities.simplified(prefs.getString("city", "")), InputType.TYPE_CLASS_TEXT);
        int number = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED;
        InputDialog.Field lat = dialog.field("纬度 · −90～90", "例如：31.23", prefs.getString("lat", ""), number);
        InputDialog.Field lon = dialog.field("经度 · −180～180", "例如：121.47", prefs.getString("lon", ""), number);
        dialog.primary("应用", android.view.inputmethod.EditorInfo.IME_ACTION_DONE, () -> {
            if (!name.require("请输入城市名称") || !validCoordinate(lat, 90, "纬度") || !validCoordinate(lon, 180, "经度")) return;
            setCity(name.value(), lat.value(), lon.value());
            dialog.dismiss();
        });
        openInputDialog(dialog);
    }

    private boolean validCoordinate(InputDialog.Field field, int limit, String label) {
        try {
            double value = Double.parseDouble(field.value());
            if (Double.isFinite(value) && Math.abs(value) <= limit) return true;
        } catch (NumberFormatException ignored) {}
        field.error("请输入 −" + limit + "～" + limit + " 之间的有效" + label);
        return false;
    }

    private void musicPermission() {
        String value = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        if (value == null || !value.contains(getPackageName())) {
            new StudioAlertBuilder()
                .setMessage("音乐控制需要通知使用权，仅读取媒体会话。")
                .setPositiveButton("前往授权", (d, n) -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)))
                .setNegativeButton("取消", null)
                .show();
        } else {
            message("音乐访问已开启");
        }
    }

    final class StudioAlertBuilder extends AlertDialog.Builder {
        StudioAlertBuilder(){super(MainActivity.this);}
        public AlertDialog show(){AlertDialog dialog=super.show();studioDialog=dialog;fitDialog(dialog);return dialog;}
    }
    private void fitDialog(Dialog dialog){
        if(dialog.getWindow()==null)return;
        Rect area=dialogSafeBounds();WindowMetrics metrics=getWindowManager().getCurrentWindowMetrics();Insets bars=metrics.getWindowInsets().getInsetsIgnoringVisibility(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
        int width=Math.min(dp(460),Math.max(1,area.width()-dp(20))),height=Math.max(1,area.height()-dp(20));
        View decor=dialog.getWindow().getDecorView();decor.measure(View.MeasureSpec.makeMeasureSpec(width,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(height,View.MeasureSpec.AT_MOST));
        WindowManager.LayoutParams lp=dialog.getWindow().getAttributes();lp.width=width;lp.height=Math.min(height,decor.getMeasuredHeight());lp.gravity=Gravity.TOP|Gravity.LEFT;
        lp.x=area.left-bars.left+(area.width()-width)/2;lp.y=Math.max(0,area.top-bars.top+(area.height()-lp.height)/2);dialog.getWindow().setAttributes(lp);
    }
    void deletedForEditor(String label){showNotice(label);}
    AlertDialog.Builder alertForEditor(){return new StudioAlertBuilder();}

    private void message(String value) {
        new StudioAlertBuilder().setMessage(value).setPositiveButton("好", null).show();
    }

    private void withRecovery(String label,Runnable action){persistDraft();saveRecoveryPoint(label);action.run();}

    private void withSavedScene(Runnable action) {
        persistDraft();
        action.run();
    }

    public void onBackPressed() {
        if (navExpanded) {
            navExpanded = false;
            show();
            return;
        }
        if (portraitStyleScreen) {
            componentPicker=false;portraitStyleScreen = false;
            tab = 1;
            show();
            return;
        }
        if (tab == 3) {
            tab = 1;
            show();
            return;
        }
        withSavedScene(this::finish);
    }

    protected void onSaveInstanceState(Bundle out) {
        rememberScroll();
        history.finish();
        out.putBoolean("browsingPages",browsingPages);out.putBoolean("previewExpanded",previewExpanded);out.putInt("studioPanel",studioPanel);out.putBoolean("componentPicker",componentPicker);
        out.putStringArrayList("undoStates",history.undoStates());out.putStringArrayList("redoStates",history.redoStates());
        out.putBoolean("pageOverview", pageOverview);
        out.putBoolean("navExpanded", navExpanded);
        out.putBoolean("portraitStyleScreen", portraitStyleScreen);
        out.putString("libraryType", libraryType);
        out.putString("draft", draft.json());
        out.putString("baseline", baseline);
        out.putString("page", pageId);
        out.putInt("tab", tab);
        out.putInt("slot", slot);
        out.putInt("category", category);
        out.putInt("inspectorGroup", inspectorGroup);
        out.putInt("paletteScope", paletteScope);
        out.putInt("colorMode", colorState.mode);
        out.putInt("colorRole", colorState.role);
        out.putString("colorHex", colorState.hex);
        out.putString("colorContext", colorContext);
        out.putBoolean("previewNight", previewNight);
        JSONObject j = new JSONObject();
        for (Map.Entry<String, Integer> e : scrolls.entrySet()) Scene.put(j, e.getKey(), e.getValue());
        out.putString("scrolls", j.toString());
        super.onSaveInstanceState(out);
    }

    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        show();
        if (inputDialog != null) inputDialog.resize();
        if(studioDialog!=null&&studioDialog.isShowing())fitDialog(studioDialog);
    }

    protected void onResume() {
        super.onResume();
        // Fullscreen task changes are saved there and reflected when returning to the studio.
        String saved=prefs.getString(Scene.KEY,baseline);Scene restored=Scene.load(prefs);String normalized=restored.json();
        if(!normalized.equals(baseline)){
            String previous=historyState;draft=restored;pageId=page().id;slot=Math.min(slot,page().count()-1);baseline=normalized;
            historyState=captureEditorState();history.record(previous,historyState);show();
        }
        if(!saved.equals(normalized))prefs.edit().putString(Scene.KEY,normalized).apply();
        if (!testMode) {
            ClockActivity.applyExtraDim(this, prefs, false, 0f);
            AlarmData.observe(this, alarmChanged);
            int boot = Settings.Global.getInt(getContentResolver(), Settings.Global.BOOT_COUNT, 0);
            if (prefs.getLong("timerBoot", -1) != boot) {
                DeskData.resetFocus(prefs);
                prefs.edit().putLong("timerBoot", boot).apply();
            }
            DeskData.refresh(this, false);
        }
        pulseRunning = true;
        handler.removeCallbacks(clockPulse);
        handler.post(clockPulse);
    }

    public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request == WEATHER_LOCATION_PERMISSION) {
            if (WeatherLocation.allowed(this)) useCurrentLocation();
            else message("未获得定位权限，仍可搜索城市或使用经纬度设置天气地点。");
            return;
        }
        if (!testMode) DeskData.refresh(this, true);
        show();
    }

    protected void onPause() {
        history.finish();
        persistDraft();
        AlarmData.forget(this, alarmChanged);
        cancelWeatherLocation();
        if (searchDialog != null) searchDialog.dismiss();
        searchDialog = null;
        pulseRunning = false;
        handler.removeCallbacks(clockPulse);
        super.onPause();
    }

    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        cancelWeatherLocation();
        if (inputDialog != null) inputDialog.dismiss();
        if (folds != null) folds.stop();
        super.onDestroy();
    }

    void selectForCheck(int tabIndex, int settingsGroup) {
        tab = tabIndex;
        category = settingsGroup;
        studioPanel=tabIndex==0?1:0;browsingPages=tabIndex==2;
        portraitStyleScreen = tabIndex==0;
        navExpanded = false;
    }
    void inspectorForCheck(int group) { inspectorGroup=group;studioPanel=component().type.equals("clock")?(group==2?2:group==3?0:1):(group==1?2:0); }
    void paletteModeForCheck(int mode) { colorState.mode = mode; colorState.hex = null; }
    void libraryForCheck(String type) {
        libraryType = type;
        tab = 0;
        portraitStyleScreen=true;componentPicker=false;
    }
    boolean overviewForCheck() { return pageOverview; }
    PaletteEditor colorEditorForCheck() { return colorEditor; }
    WatchCarouselScrollView carouselForCheck() { return carouselScroll; }
    void foldForCheck(Rect bounds) { foldBounds = bounds; }
    void navigationForCheck(boolean expanded) { navExpanded = expanded; }
    void prepareForCheck(Context context) {
        attachBaseContext(context);
        testMode = true;
        prefs = context.getSharedPreferences("ui_checks", 0);
        draft = Scene.load(prefs);
        baseline = draft.json();
        pageId = draft.home;
        historyState = captureEditorState();
    }

    /** Caps the top Portrait Watch Carousel stage height so lower controls and keyboard input stay visible. */
    final class WatchStageContainer extends LinearLayout {
        private final int requestedHeight;
        WatchStageContainer(Context c, int requestedHeightDp) {
            super(c);
            setOrientation(VERTICAL);
            requestedHeight = UiKit.dp(c, requestedHeightDp);
        }
        protected void onMeasure(int w, int h) {
            int maxAvail=MeasureSpec.getSize(h);float density=getResources().getDisplayMetrics().density;
            WindowInsets insets=getRootWindowInsets();boolean keyboard=insets!=null?insets.isVisible(WindowInsets.Type.ime()):imeVisible;
            View tools=findViewWithTag("preview:tools");
            int cap=UiKit.dp(getContext(),AdaptiveLayout.previewHeight(widthDp,Math.round(maxAvail/density),browsingPages,previewExpanded,keyboard,getResources().getConfiguration().fontScale*UiKit.customFontScale));
            View header=getChildAt(0);header.measure(w,MeasureSpec.makeMeasureSpec(0,MeasureSpec.UNSPECIFIED));
            int headerH=header.getMeasuredHeight();
            if(tools!=null){tools.setVisibility(View.VISIBLE);tools.measure(w,MeasureSpec.makeMeasureSpec(0,MeasureSpec.UNSPECIFIED));tools.setVisibility(keyboard||cap<headerH+tools.getMeasuredHeight()+UiKit.dp(getContext(),80)?View.GONE:View.VISIBLE);}
            cap=Math.min(Math.max(cap,headerH+UiKit.dp(getContext(),maxAvail<UiKit.dp(getContext(),300)?24:52)),Math.max(0,maxAvail));
            boolean labels=browsingPages&&cap-headerH-(tools!=null&&tools.getVisibility()==View.VISIBLE?tools.getMeasuredHeight():0)>UiKit.dp(getContext(),100);
            if(carouselScroll!=null&&carouselScroll.getChildCount()>0){ViewGroup track=(ViewGroup)carouselScroll.getChildAt(0);for(int i=0;i<track.getChildCount();i++){View child=track.getChildAt(i);if(child instanceof ViewGroup)((ViewGroup)child).getChildAt(0).setVisibility(labels?View.VISIBLE:View.GONE);}}
            super.onMeasure(w, MeasureSpec.makeMeasureSpec(cap, MeasureSpec.EXACTLY));
        }
    }

    /** Middle-only scrollable smartwatch carousel applying 3D perspective zoom, dim, and snap selection. */
    static final class WatchCarouselScrollView extends ScrollView {
        private List<LinearLayout> items = Collections.emptyList();
        private int selectedIndex;
        private java.util.function.IntConsumer onSelectIndex;
        private boolean userDragged, touching, settling, initialCentered, flinging;
        private ValueAnimator snapAnimator;
        private final Runnable settleCheck = () -> snapClosest();
        private java.util.function.BiConsumer<String, Integer> onMove;
        private boolean reordering;
        private float dragY;
        private int dropIndex = -1, dragIndex = -1;
        private float[] reorderOffsets = new float[0];
        private ValueAnimator reorderAnimator;
        private long edgeFrameTime;
        private TextView dragLabel;
        private CharSequence originalDragLabel;
        private final Runnable edgeScroll = new Runnable() {
            public void run() {
                if (!reordering) return;
                int edge = Math.min(UiKit.dp(getContext(), 72), getHeight() / 3);
                float direction = dragY < edge ? -(edge - dragY) / Math.max(1, edge)
                    : dragY > getHeight() - edge ? (dragY - getHeight() + edge) / Math.max(1, edge) : 0;
                long now = SystemClock.uptimeMillis();
                float elapsed = edgeFrameTime == 0 ? 16f : Math.min(32f, now - edgeFrameTime);
                edgeFrameTime = now;
                int step = Math.round(UiKit.dp(getContext(), 760) * elapsed / 1000f * Math.max(-1f, Math.min(1f, direction)));
                if (step != 0) scrollBy(0, step);
                previewDrop(closestIndexForScroll(getScrollY() + dragY - getHeight() / 2f));
                postOnAnimation(this);
            }
        };

        WatchCarouselScrollView(Context c) { super(c); }

        int dropIndexForCheck() { return dropIndex; }
        float reorderOffsetForCheck(int index) { return reorderOffsets[index]; }

        @Override public boolean onDragEvent(DragEvent event) {
            if (!(event.getLocalState() instanceof String)) return false;
            switch (event.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    dragIndex = -1;
                    for (int i = 0; i < items.size(); i++) if (("page:" + event.getLocalState()).equals(items.get(i).getTag())) dragIndex = i;
                    if (dragIndex < 0) return false;
                    dragLabel = (TextView) ((ViewGroup) items.get(dragIndex).getChildAt(0)).getChildAt(0);
                    originalDragLabel = dragLabel.getText();
                    reordering = true;
                    reorderOffsets = new float[items.size()];
                    edgeFrameTime = 0;
                    touching = settling = flinging = false;
                    cancelSnap();
                    super.fling(0);
                    removeCallbacks(settleCheck);
                    previewDrop(dragIndex);
                    return true;
                case DragEvent.ACTION_DRAG_LOCATION:
                    dragY = event.getY();
                    removeCallbacks(edgeScroll);
                    edgeScroll.run();
                    return true;
                case DragEvent.ACTION_DRAG_EXITED:
                    removeCallbacks(edgeScroll);
                    edgeFrameTime = 0;
                    previewDrop(-1);
                    return true;
                case DragEvent.ACTION_DROP:
                    int target = closestIndexForScroll(getScrollY() + event.getY() - getHeight() / 2f);
                    removeCallbacks(edgeScroll);
                    if (onMove != null) onMove.accept((String) event.getLocalState(), target);
                    return true;
                case DragEvent.ACTION_DRAG_ENDED:
                    reordering = false;
                    dropIndex = -1;
                    dragIndex = -1;
                    if (dragLabel != null) dragLabel.setText(originalDragLabel);
                    dragLabel = null;
                    removeCallbacks(edgeScroll);
                    if (reorderAnimator != null) { reorderAnimator.cancel(); reorderAnimator = null; }
                    Arrays.fill(reorderOffsets, 0);
                    refreshPerspective();
                    centerIndex(selectedIndex, true);
                    return true;
                default: return true;
            }
        }

        /** Preview the final order without changing the scene until a successful drop. */
        private void previewDrop(int target) {
            if (dropIndex == target) return;
            dropIndex = target;
            if (dragLabel != null) dragLabel.setText(target < 0 ? originalDragLabel : (target + 1) + "  " + originalDragLabel.toString().replaceFirst("^\\d+\\s+", ""));
            if (reorderAnimator != null) reorderAnimator.cancel();
            float[] start = reorderOffsets.clone(), end = new float[items.size()];
            if (target >= 0 && dragIndex >= 0) {
                for (int i = 0; i < items.size(); i++) {
                    int destination = i;
                    if (i == dragIndex) destination = target;
                    else if (dragIndex < target && i > dragIndex && i <= target) destination = i - 1;
                    else if (dragIndex > target && i >= target && i < dragIndex) destination = i + 1;
                    end[i] = items.get(destination).getTop() - items.get(i).getTop();
                }
            }
            if (!ValueAnimator.areAnimatorsEnabled()) {
                reorderOffsets = end;
                refreshPerspective();
                return;
            }
            reorderAnimator = ValueAnimator.ofFloat(0, 1);
            reorderAnimator.setDuration(180);
            reorderAnimator.setInterpolator(new PathInterpolator(.2f, .7f, .3f, 1f));
            reorderAnimator.addUpdateListener(a -> {
                float progress = (Float) a.getAnimatedValue();
                for (int i = 0; i < end.length; i++) reorderOffsets[i] = start[i] + (end[i] - start[i]) * progress;
                refreshPerspective();
            });
            reorderAnimator.start();
        }

        void bind(List<LinearLayout> itemViews, int selected, java.util.function.IntConsumer selectCallback) {
            cancelSnap();
            items = itemViews;
            reorderOffsets = new float[items.size()];
            selectedIndex = selected;
            onSelectIndex = selectCallback;
            initialCentered = false;
        }

        void setSelectedIndex(int idx, boolean smooth) {
            if (selectedIndex == idx && !smooth) return;
            selectedIndex = idx;
            centerIndex(idx, smooth);
        }

        void refreshPerspective() {
            updatePerspective(getScrollY());
        }

        private void cancelSnap() {
            if (snapAnimator != null) {
                ValueAnimator a = snapAnimator;
                snapAnimator = null;
                a.cancel();
            }
        }

        private static int blendColor(int from, int to, float ratio) {
            float t = Math.max(0f, Math.min(1f, ratio));
            int a = Math.round(Color.alpha(from) + (Color.alpha(to) - Color.alpha(from)) * t);
            int r = Math.round(Color.red(from) + (Color.red(to) - Color.red(from)) * t);
            int g = Math.round(Color.green(from) + (Color.green(to) - Color.green(from)) * t);
            int b = Math.round(Color.blue(from) + (Color.blue(to) - Color.blue(from)) * t);
            return Color.argb(a, r, g, b);
        }

        protected void onDetachedFromWindow() {
            reordering = false;
            removeCallbacks(edgeScroll);
            if (reorderAnimator != null) { reorderAnimator.cancel(); reorderAnimator = null; }
            cancelSnap();
            removeCallbacks(settleCheck);
            super.onDetachedFromWindow();
        }

        @Override
        public void computeScroll() {
            if (reordering) return;
            if (snapAnimator != null && snapAnimator.isRunning()) return;
            super.computeScroll();
        }

        @Override
        public void fling(int velocityY) {
            if (items.isEmpty() || getHeight() <= 0) {
                super.fling(velocityY);
                return;
            }
            flinging = true;
            settling = false;
            removeCallbacks(settleCheck);
            int cur = closestIndex();
            float projectedY = getScrollY() + velocityY * 0.18f;
            int targetIdx = closestIndexForScroll(projectedY);
            if (Math.abs(velocityY) > UiKit.dp(getContext(), 220) && targetIdx == cur) {
                targetIdx = Math.max(0, Math.min(items.size() - 1, cur + (velocityY > 0 ? 1 : -1)));
            }
            snapToIndex(targetIdx);
        }

        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
            int vh = getMeasuredHeight();
            if (vh > 0 && !items.isEmpty() && getChildCount() > 0) {
                View track = getChildAt(0);
                // Fit the selected cover-ratio preview to the reserved area in both orientations.
                int maxW = Math.max(1, getMeasuredWidth() - track.getPaddingLeft() - track.getPaddingRight() - UiKit.dp(getContext(), 8));
                int labelH = items.get(0).getChildAt(0).getVisibility()==View.GONE?0:items.get(0).getChildAt(0).getMeasuredHeight();
                int previewH = Math.max(1, Math.min(Math.round(maxW * 1248f / 1972f), vh - labelH - UiKit.dp(getContext(), 16)));
                int previewW = Math.round(previewH * 1972f / 1248f);
                boolean resized = false;
                for (LinearLayout item : items) {
                    View frame = item.getChildAt(1);
                    ViewGroup.LayoutParams lp = frame.getLayoutParams();
                    if (lp.width != previewW || lp.height != previewH) {
                        lp.width = previewW;
                        lp.height = previewH;
                        frame.setLayoutParams(lp);
                        resized = true;
                    }
                }
                if (resized) super.onMeasure(widthMeasureSpec, heightMeasureSpec);
                int firstH = items.get(0).getMeasuredHeight();
                int lastH = items.get(items.size() - 1).getMeasuredHeight();
                int padTop = Math.max(UiKit.dp(getContext(), 4), (vh - firstH) / 2);
                int padBottom = Math.max(UiKit.dp(getContext(), 4), (vh - lastH) / 2);
                if (track.getPaddingTop() != padTop || track.getPaddingBottom() != padBottom) {
                    track.setPadding(track.getPaddingLeft(), padTop, track.getPaddingRight(), padBottom);
                    super.onMeasure(widthMeasureSpec, heightMeasureSpec);
                }
            }
        }

        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            super.onLayout(changed, l, t, r, b);
            if ((!initialCentered || changed && !touching && !reordering && snapAnimator == null) && getHeight() > 0 && !items.isEmpty()) {
                initialCentered = true;
                centerIndex(selectedIndex, false);
            }
            updatePerspective(getScrollY());
        }

        int maxScrollForCheck() {
            return getChildCount() > 0 ? Math.max(0, getChildAt(0).getHeight() - getHeight()) : 0;
        }

        void centerIndex(int idx, boolean smooth) {
            if (idx < 0 || idx >= items.size() || getHeight() <= 0) return;
            View target = items.get(idx);
            int desiredTop = target.getTop() - Math.max(0, (getHeight() - target.getHeight()) / 2);
            int maxScroll = maxScrollForCheck();
            int clamped = Math.max(0, Math.min(maxScroll, desiredTop));
            cancelSnap();
            if (!smooth || Math.abs(clamped - getScrollY()) <= 1 || !ValueAnimator.areAnimatorsEnabled()) {
                scrollTo(0, clamped);
                updatePerspective(clamped);
                return;
            }
            snapAnimator = ValueAnimator.ofInt(getScrollY(), clamped);
            long duration = Math.min(360L, Math.max(240L, Math.round(Math.abs(clamped - getScrollY()) * 1.2f)));
            snapAnimator.setDuration(duration);
            snapAnimator.setInterpolator(new PathInterpolator(0.22f, 0.61f, 0.36f, 1.0f));
            snapAnimator.addUpdateListener(a -> {
                int y = (Integer) a.getAnimatedValue();
                scrollTo(0, y);
                updatePerspective(y);
            });
            snapAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
                public void onAnimationEnd(android.animation.Animator animation) {
                    if (snapAnimator == animation) snapAnimator = null;
                }
                public void onAnimationCancel(android.animation.Animator animation) {
                    if (snapAnimator == animation) snapAnimator = null;
                }
            });
            snapAnimator.start();
        }

        protected void onScrollChanged(int l, int t, int oldl, int oldt) {
            super.onScrollChanged(l, t, oldl, oldt);
            updatePerspective(t);
            if (!reordering && !touching && settling && (snapAnimator == null || !snapAnimator.isRunning())) {
                removeCallbacks(settleCheck);
                postDelayed(settleCheck, Math.abs(t - oldt) > 4 ? 95 : 55);
            }
        }

        private void updatePerspective(int scrollY) {
            int vh = getHeight();
            if (vh <= 0 || items.isEmpty()) return;
            float vCenter = scrollY + vh * 0.5f;
            for (int index = 0; index < items.size(); index++) {
                LinearLayout child = items.get(index);
                float reorderOffset = index < reorderOffsets.length ? reorderOffsets[index] : 0;
                boolean placeholder = reordering && index == dragIndex && dropIndex >= 0;
                float normRange = Math.max(1f, child.getHeight());
                float cCenter = child.getTop() + reorderOffset + child.getHeight() * 0.5f;
                float dist = Math.max(-1f, Math.min(1f, (cCenter - vCenter) / normRange));
                float u = Math.abs(dist);
                if (u < 0.015f) {
                    u = 0f;
                    dist = 0f;
                }
                float s = u * u * (3f - 2f * u);
                float focus = 1f - s;
                float highlight = focus * focus;
                float scale = 1.0f - 0.38f * s;
                if (child.getWidth() > 0) child.setPivotX(child.getWidth() * 0.5f);
                if (child.getHeight() > 0) child.setPivotY(child.getHeight() * 0.5f);
                child.setScaleX(scale);
                child.setScaleY(scale);
                child.setRotationX(-dist * (0.8f + 0.2f * s) * 20f);
                child.setTranslationY(reorderOffset - dist * child.getHeight() * 0.18f * s);
                child.setTranslationZ(placeholder ? UiKit.dp(getContext(), 10) : focus * UiKit.dp(getContext(), 6));
                child.setAlpha((1.0f - 0.56f * s) * (reordering && index == dragIndex ? .55f : 1f));

                if (child.getChildCount() >= 2) {
                    View row = child.getChildAt(0);
                    if (row instanceof ViewGroup && ((ViewGroup) row).getChildCount() > 0) {
                        View labelView = ((ViewGroup) row).getChildAt(0);
                        if (labelView instanceof TextView) {
                            TextView tv = (TextView) labelView;
                            tv.setTextColor(blendColor(UiKit.MUTED, UiKit.ACCENT, highlight));
                            int wantStyle = focus > 0.7f ? Typeface.BOLD : Typeface.NORMAL;
                            if (tv.getTypeface() == null || tv.getTypeface().getStyle() != wantStyle) {
                                tv.setTypeface(null, wantStyle);
                            }
                        }
                    }
                    View frame = child.getChildAt(1);
                    if (frame.getBackground() instanceof GradientDrawable) {
                        GradientDrawable bg = (GradientDrawable) frame.getBackground();
                        bg.setStroke(
                            Math.max(1, UiKit.dp(getContext(), placeholder ? 3f : 1.0f + 1.2f * highlight)),
                            placeholder ? UiKit.ACCENT : blendColor(0xff222d3d, UiKit.ACCENT, highlight)
                        );
                    }
                }
            }
        }

        public boolean onInterceptTouchEvent(MotionEvent ev) {
            if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
                touching = true;
                settling = false;
                flinging = false;
                cancelSnap();
                removeCallbacks(settleCheck);
            }
            boolean intercepted = super.onInterceptTouchEvent(ev);
            if (intercepted) {
                touching = true;
                userDragged = true;
                settling = false;
                flinging = false;
                cancelSnap();
                removeCallbacks(settleCheck);
            }
            if (ev.getActionMasked() == MotionEvent.ACTION_UP || ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                touching = false;
            }
            return intercepted;
        }

        public boolean onTouchEvent(MotionEvent ev) {
            if (reordering) return true;
            if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
                touching = true;
                settling = false;
                flinging = false;
                cancelSnap();
                removeCallbacks(settleCheck);
            }
            if (ev.getActionMasked() == MotionEvent.ACTION_MOVE) {
                touching = true;
                userDragged = true;
                settling = false;
                flinging = false;
                cancelSnap();
                removeCallbacks(settleCheck);
            }
            if (ev.getActionMasked() == MotionEvent.ACTION_UP || ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                flinging = false;
            }
            boolean handled = super.onTouchEvent(ev);
            if (ev.getActionMasked() == MotionEvent.ACTION_UP || ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                touching = false;
                boolean wasDragged = userDragged;
                userDragged = false;
                if ((wasDragged || ev.getActionMasked() == MotionEvent.ACTION_UP) && !flinging) {
                    settling = false;
                    removeCallbacks(settleCheck);
                    snapClosest();
                }
            }
            return handled;
        }

        int closestIndex() {
            return closestIndexForScroll(getScrollY());
        }

        private int closestIndexForScroll(float scrollY) {
            int vh = getHeight();
            if (vh <= 0 || items.isEmpty()) return selectedIndex;
            int maxScroll = maxScrollForCheck();
            if (scrollY <= 2) return 0;
            if (maxScroll > 0 && scrollY >= maxScroll - 2) return items.size() - 1;
            float vCenter = scrollY + vh * 0.5f;
            int best = selectedIndex;
            float bestDist = Float.MAX_VALUE;
            for (int i = 0; i < items.size(); i++) {
                View child = items.get(i);
                float dist = Math.abs((child.getTop() + child.getHeight() * 0.5f) - vCenter);
                if (dist < bestDist) {
                    bestDist = dist;
                    best = i;
                }
            }
            return best;
        }

        private void snapClosest() {
            if (reordering) return;
            settling = false;
            if (getHeight() <= 0 || items.isEmpty()) return;
            snapToIndex(closestIndex());
        }

        private void snapToIndex(int best) {
            if (best < 0 || best >= items.size() || getHeight() <= 0) return;
            int prev = selectedIndex;
            selectedIndex = best;
            if (best != prev && onSelectIndex != null) {
                onSelectIndex.accept(best);
            }
            centerIndex(best, true);
        }
    }

    static final class AspectPreview extends FrameLayout {
        AspectPreview(Context c) { super(c); }
        protected void onMeasure(int w, int h) {
            int width = MeasureSpec.getSize(w), height = MeasureSpec.getSize(h);
            int innerW = Math.max(0, width - getPaddingLeft() - getPaddingRight());
            int innerH = Math.max(0, height - getPaddingTop() - getPaddingBottom());
            int cw = Math.min(innerW, Math.round(innerH * 1972f / 1248f));
            int ch = Math.round(cw * 1248f / 1972f);
            for (int i = 0; i < getChildCount(); i++) {
                getChildAt(i).measure(
                    MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY)
                );
            }
            setMeasuredDimension(width, height);
        }
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int padL = getPaddingLeft(), padT = getPaddingTop();
            int innerW = Math.max(0, getWidth() - padL - getPaddingRight());
            int innerH = Math.max(0, getHeight() - padT - getPaddingBottom());
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                int x = padL + (innerW - child.getMeasuredWidth()) / 2;
                int y = padT + (innerH - child.getMeasuredHeight()) / 2;
                child.layout(x, y, x + child.getMeasuredWidth(), y + child.getMeasuredHeight());
            }
        }
    }

    static final class HsvPicker extends View {
        private final Paint p = new Paint(3);
        private final float[] hsv = new float[3];
        private final java.util.function.IntConsumer callback;
        HsvPicker(Context c, int color, java.util.function.IntConsumer onColor) {
            super(c);
            Color.colorToHSV(color, hsv);
            callback = onColor;
            setContentDescription("调色盘，横向饱和度，纵向明度，底部色相");
        }
        void setColor(int color) { Color.colorToHSV(color, hsv); invalidate(); }
        protected void onDraw(Canvas c) {
            float h = getHeight() - dpLocal(22);
            int hue = Color.HSVToColor(new float[] { hsv[0], 1, 1 });
            p.setShader(new LinearGradient(0, 0, getWidth(), 0, Color.WHITE, hue, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, getWidth(), h, p);
            p.setShader(new LinearGradient(0, 0, 0, h, Color.TRANSPARENT, Color.BLACK, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, getWidth(), h, p);
            p.setShader(new LinearGradient(0, 0, getWidth(), 0, new int[] { 0xffff0000, 0xffffff00, 0xff00ff00, 0xff00ffff, 0xff0000ff, 0xffff00ff, 0xffff0000 }, null, Shader.TileMode.CLAMP));
            c.drawRect(0, h + dpLocal(6), getWidth(), getHeight(), p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dpLocal(2));
            p.setColor(Color.WHITE);
            c.drawCircle(hsv[1] * getWidth(), (1 - hsv[2]) * h, dpLocal(5), p);
            c.drawCircle(hsv[0] / 360 * getWidth(), h + dpLocal(14), dpLocal(5), p);
            p.setStyle(Paint.Style.FILL);
        }
        private float dpLocal(int n) { return n * getResources().getDisplayMetrics().density; }
        public boolean onTouchEvent(MotionEvent e) {
            if(e.getAction()==MotionEvent.ACTION_DOWN){if(getContext() instanceof Activity){View focused=((Activity)getContext()).getCurrentFocus();if(focused instanceof EditText)focused.clearFocus();}UiKit.beginEdit(getContext());}
            if(e.getAction()==MotionEvent.ACTION_CANCEL){UiKit.endEdit(getContext());if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);return true;}
            if (e.getAction() == MotionEvent.ACTION_DOWN || e.getAction() == MotionEvent.ACTION_MOVE) {
                getParent().requestDisallowInterceptTouchEvent(true);
                float h = getHeight() - dpLocal(22);
                if (e.getY() > h) hsv[0] = Math.max(0, Math.min(359, e.getX() / getWidth() * 360));
                else {
                    hsv[1] = Math.max(0, Math.min(1, e.getX() / getWidth()));
                    hsv[2] = Math.max(0, Math.min(1, 1 - e.getY() / h));
                }
                callback.accept(Color.HSVToColor(hsv));
                invalidate();
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_UP) {
                UiKit.endEdit(getContext());if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);
                performClick();
                return true;
            }
            return true;
        }
        public boolean performClick() { super.performClick(); return true; }
    }
}
