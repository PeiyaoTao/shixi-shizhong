package com.foldstandby.clock;
import android.app.*;
import android.content.*;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;

public class ClockActivity extends Activity {
    static volatile boolean sessionOpen;
    static volatile ClockActivity currentInstance;
    private final Handler h=new Handler(Looper.getMainLooper());
    private ClockFace face;
    private SharedPreferences prefs;private Scene scene;private int page;
    private boolean automatic,previewMode,sleeping,receiverRegistered,wasNight,checkMode;
    private long activeSince,lastInteraction,pageSince,wakeGraceUntil;
    private float lastBrightness=-1f;
    private boolean resumed;
    private final Runnable clearTurnScreenOn=()->setTurnScreenOn(false);
    private final BroadcastReceiver screen=new BroadcastReceiver(){public void onReceive(Context c,Intent i){if(Intent.ACTION_SCREEN_OFF.equals(i.getAction())){if(!(automatic&&!sleeping&&SystemClock.elapsedRealtime()-activeSince<1500L))rest();}else if(Intent.ACTION_SCREEN_ON.equals(i.getAction()))wake(true);}};
    private final Runnable tick=new Runnable(){public void run(){
        if(automatic&&!StandbyService.resting&&SystemClock.elapsedRealtime()>wakeGraceUntil&&(!StandbyService.active||!ScreenIdentity.isPrimaryCover(ClockActivity.this))){finish();return;}
        if(sleeping)return;
        DeskData.refresh(ClockActivity.this,false);long now=SystemClock.elapsedRealtime();
        if(DeskData.batteryTempTenths>=435){StandbyService.suppressedUntil=now+300000;rest();finish();return;}
        boolean night=face.night();if(night!=wasNight){wasNight=night;lastInteraction=now;}
        if(!previewMode&&night&&prefs.getBoolean("nightSleep",true)&&now-lastInteraction>=prefs.getInt("nightViewSeconds",20)*1000L){rest();return;}
        float rawNight=prefs.getFloat("nightBrightness",.06f);
        float target=night?Math.max(.0001f,rawNight):prefs.getFloat("brightness",.25f);
        long elapsed=now-activeSince;if(elapsed>14400000)target=Math.min(target,.05f);else if(elapsed>7200000)target=Math.min(target,.08f);if(DeskData.batteryTempTenths>=400)target=Math.min(target,.05f);
        if(Math.abs(target-lastBrightness)>.0002f){WindowManager.LayoutParams a=getWindow().getAttributes();a.screenBrightness=target;getWindow().setAttributes(a);lastBrightness=target;}
        float faceAlpha=(night&&rawNight<.01f)?Math.max(.22f,Math.min(.95f,.15f+rawNight*85f)):1f;
        if(Math.abs(face.getAlpha()-faceAlpha)>.01f)face.setAlpha(faceAlpha);
        if(!checkMode)applyExtraDim(ClockActivity.this,prefs,night&&prefs.getBoolean("nightExtraDim",true),rawNight);
        boolean autoplay=!previewMode&&!night&&prefs.getBoolean("autoplay",false);long interval=prefs.getInt("pageInterval",20)*1000L;
        if(autoplay&&now-pageSince>=interval&&now-lastInteraction>=Math.max(30000,interval*2))changePage((page+1)%scene.pages.size(),true,false,1);
        int homeAfter=previewMode?0:prefs.getInt("homeAfter",60);if(!autoplay&&homeAfter>0&&page!=scene.homeIndex()&&now-lastInteraction>=homeAfter*1000L)changePage(scene.homeIndex(),true,false,0);
        face.invalidate();
        long delay=face.nextDelayMs();
        if(automatic&&!StandbyService.resting&&now<=wakeGraceUntil)delay=Math.min(delay,Math.max(50L,wakeGraceUntil-now+20L));
        if(night&&!previewMode&&prefs.getBoolean("nightSleep",true))delay=Math.min(delay,Math.max(100L,prefs.getInt("nightViewSeconds",20)*1000L-(now-lastInteraction)));
        if(autoplay&&scene.pages.size()>1){long nextAuto=Math.max(pageSince+interval,lastInteraction+Math.max(30000L,interval*2))-now;delay=Math.min(delay,Math.max(100L,nextAuto));}
        if(!autoplay&&homeAfter>0&&page!=scene.homeIndex()){long nextHome=lastInteraction+homeAfter*1000L-now;delay=Math.min(delay,Math.max(100L,nextHome));}
        h.removeCallbacks(this);h.postDelayed(this,delay);
    }};
    private final SharedPreferences.OnSharedPreferenceChangeListener prefsListener=(p,key)->h.post(()->{
        if(resumed&&!sleeping&&!isFinishing()){
            h.removeCallbacks(tick);
            h.post(tick);
        }
    });
    static void onPostureOrDisplayChanged(){
        ClockActivity instance=currentInstance;
        if(instance!=null){
            instance.h.post(()->{
                if(!instance.isFinishing()&&instance.automatic&&!StandbyService.resting&&SystemClock.elapsedRealtime()>instance.wakeGraceUntil&&(!StandbyService.active||!ScreenIdentity.isPrimaryCover(instance))){
                    instance.finish();return;
                }
                if(instance.resumed&&!instance.sleeping&&!instance.isFinishing()){
                    instance.h.removeCallbacks(instance.tick);
                    instance.h.post(instance.tick);
                }
            });
        }
    }
    public void onCreate(Bundle b){super.onCreate(b);checkMode=getIntent().getBooleanExtra("uiCheck",false);prefs=getSharedPreferences(checkMode?"ui_checks":"clock",0);prefs.registerOnSharedPreferenceChangeListener(prefsListener);currentInstance=this;applyLaunchIntent();sessionOpen=!checkMode;
        applyOrientation();setShowWhenLocked(true);setTurnScreenOn(true);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);getWindow().getDecorView().setBackgroundColor(Color.BLACK);getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);getWindow().getDecorView().setSystemUiVisibility(5894);
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);face=new ClockFace(this,prefs);face.bind(scene,page);if(previewMode){page=scene.index(getIntent().getStringExtra("previewPage"));face.selectPage(page);if(getIntent().hasExtra("previewNight"))face.nightPreview=getIntent().getBooleanExtra("previewNight",false);}face.flipFeedbackEnabled=true;face.sceneChanged=()->scene.save(prefs);face.externalTick=true;face.pageSwipe=direction->{int next=page+direction;if(next>=0&&next<scene.pages.size())changePage(next,true,true,direction);};face.interaction=()->wake(false);root.addView(face,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);updatePageDescription();
        IntentFilter f=new IntentFilter();f.addAction(Intent.ACTION_SCREEN_ON);f.addAction(Intent.ACTION_SCREEN_OFF);registerReceiver(screen,f);receiverRegistered=true;wake(true);
    }
    private void updatePageDescription(){if(face!=null)face.setContentDescription((page+1)+"/"+scene.pages.size()+" · "+scene.pages.get(page).name);}
    private void changePage(int next,boolean animate,boolean user,int direction){if(next<0||next>=scene.pages.size()||next==page)return;if(user)wake(false);page=next;pageSince=SystemClock.elapsedRealtime();updatePageDescription();int style=prefs.getInt("pageMotion",0);if(direction==0&&style==0)style=1;if(animate)face.animatePage(page,direction,style,prefs.getInt("pageMotionDuration",360));else face.selectPage(page);}
    private void wake(boolean home){if(face==null)return;PowerManager pm=getSystemService(PowerManager.class);if(!home&&pm!=null&&!pm.isInteractive())return;boolean wasSleeping=sleeping;sleeping=false;face.setMotionActive(true);if(!checkMode)StandbyService.leaveRest(this);setTurnScreenOn(true);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);h.removeCallbacks(clearTurnScreenOn);h.postDelayed(clearTurnScreenOn,1500);long now=SystemClock.elapsedRealtime();lastInteraction=now;if(home)DeskData.keyguardAt=0;if(home||wasSleeping){wakeGraceUntil=now+4000;activeSince=now;page=previewMode?scene.index(getIntent().getStringExtra("previewPage")):scene.homeIndex();pageSince=now;face.selectPage(page);updatePageDescription();}lastBrightness=-1;h.removeCallbacks(tick);h.post(tick);}
    private void rest(){sleeping=true;if(face!=null)face.setMotionActive(false);h.removeCallbacks(clearTurnScreenOn);setTurnScreenOn(false);getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(!checkMode){applyExtraDim(this,prefs,false,0f);StandbyService.enterRest(this);}h.removeCallbacks(tick);}
    private void applyLaunchIntent(){automatic=getIntent().getBooleanExtra("auto",false);scene=Scene.parse(getIntent().getStringExtra("scenePreview"));previewMode=scene!=null;if(scene==null)scene=Scene.load(prefs);page=previewMode?scene.index(getIntent().getStringExtra("previewPage")):scene.homeIndex();if(face!=null){face.bind(scene,page);face.nightPreview=previewMode&&getIntent().hasExtra("previewNight")?getIntent().getBooleanExtra("previewNight",false):null;}}
    protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);applyLaunchIntent();wake(true);applyOrientation();}
    // The active cover panel can face a different way from the half carrying gravity.
    // Keep landscape, letting the platform's display-aware sensor choose either direction.
    private void applyOrientation(){setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    protected void onResume(){super.onResume();currentInstance=this;resumed=true;if(face!=null){if(!previewMode){scene=Scene.load(prefs);face.bind(scene,scene.homeIndex());}wake(true);}}
    protected void onPause(){resumed=false;if(face!=null)face.setMotionActive(false);if(!checkMode)applyExtraDim(this,prefs,false,0f);h.removeCallbacks(tick);super.onPause();}
    protected void onStop(){super.onStop();if(!checkMode&&!isFinishing()){PowerManager pm=getSystemService(PowerManager.class);KeyguardManager km=getSystemService(KeyguardManager.class);if(pm!=null&&pm.isInteractive()&&(previewMode||!automatic||!StandbyService.active||km==null||!km.isKeyguardLocked())){if(!previewMode)StandbyService.leaveRest(this);finish();}}}
    protected void onDestroy(){if(currentInstance==this)currentInstance=null;if(prefs!=null)prefs.unregisterOnSharedPreferenceChangeListener(prefsListener);if(!checkMode)applyExtraDim(this,prefs,false,0f);sessionOpen=false;h.removeCallbacksAndMessages(null);if(receiverRegistered)unregisterReceiver(screen);if(Fold.requestedByApp&&isFinishing())try{Fold.release(this);}catch(Exception ignored){}super.onDestroy();}
    static void applyExtraDim(Context c,SharedPreferences prefs,boolean enable,float nightBrightness){
        if(c==null||prefs==null)return;
        try{
            ContentResolver cr=c.getContentResolver();
            boolean overridden=prefs.getBoolean("extraDimOverridden",false);
            if(enable){
                if(!overridden){
                    int origAct=android.provider.Settings.Secure.getInt(cr,"reduce_bright_colors_activated",0);
                    int origLvl=android.provider.Settings.Secure.getInt(cr,"reduce_bright_colors_level",38);
                    prefs.edit().putInt("origExtraDimAct",origAct).putInt("origExtraDimLvl",origLvl).putBoolean("extraDimOverridden",true).apply();
                }
                int targetLevel;
                if(nightBrightness<.01f){
                    float t=Math.max(0f,Math.min(1f,(.009f-nightBrightness)/.008f));
                    targetLevel=Math.round(50+t*40);
                }else{
                    targetLevel=Math.max(38,prefs.getInt("origExtraDimLvl",38));
                }
                if(android.provider.Settings.Secure.getInt(cr,"reduce_bright_colors_activated",0)!=1){
                    android.provider.Settings.Secure.putInt(cr,"reduce_bright_colors_activated",1);
                }
                if(android.provider.Settings.Secure.getInt(cr,"reduce_bright_colors_level",-1)!=targetLevel){
                    android.provider.Settings.Secure.putInt(cr,"reduce_bright_colors_level",targetLevel);
                }
            }else if(overridden){
                int origAct=prefs.getInt("origExtraDimAct",0);
                int origLvl=prefs.getInt("origExtraDimLvl",38);
                android.provider.Settings.Secure.putInt(cr,"reduce_bright_colors_activated",origAct);
                android.provider.Settings.Secure.putInt(cr,"reduce_bright_colors_level",origLvl);
                prefs.edit().putBoolean("extraDimOverridden",false).apply();
            }
        }catch(Throwable ignored){}
    }
    public void onBackPressed(){if(!checkMode){if(!previewMode&&automatic&&StandbyService.active)StandbyService.enterRest(this);else if(!previewMode)StandbyService.leaveRest(this);}super.onBackPressed();}
    boolean restingForCheck(){return sleeping;}
    String stateForCheck(){return "night="+face.night()+", preview="+previewMode+", resumed="+resumed+", idle="+(SystemClock.elapsedRealtime()-lastInteraction)+", interactive="+getSystemService(PowerManager.class).isInteractive();}
}
