package com.foldstandby.clock;

import android.app.*;
import android.content.*;
import android.content.pm.ActivityInfo;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import org.json.*;

/** Isolated editor regression: real Android measurement, local recovery and keyboard/rotation. */
final class StudioChecks {
    private final Instrumentation runner;
    private Context context; private SharedPreferences prefs; private MainActivity live;
    private int checks,renders; private File output; private String activeCase="model";
    StudioChecks(Instrumentation runner){this.runner=runner;}
    private void check(boolean b,String label){checks++;if(!b)throw new AssertionError(label+" ["+activeCase+"]");}
    private Object call(Object target,String method,Class<?>[] types,Object...args){
        try{Method m=target.getClass().getDeclaredMethod(method,types);m.setAccessible(true);return m.invoke(target,args);}
        catch(Exception e){throw new AssertionError(method,e);}
    }
    private Object call(Object target,String method){return call(target,method,new Class<?>[0]);}
    private void set(Object target,String field,Object value){
        try{Field f=target.getClass().getDeclaredField(field);f.setAccessible(true);f.set(target,value);}catch(Exception e){throw new AssertionError(e);}
    }
    private Object get(Object target,String field){
        try{Field f=target.getClass().getDeclaredField(field);f.setAccessible(true);return f.get(target);}catch(Exception e){throw new AssertionError(e);}
    }
    private void sync(Runnable action){Throwable[] error={null};runner.runOnMainSync(()->{try{action.run();}catch(Throwable t){error[0]=t;}});if(error[0]!=null)throw new AssertionError(error[0]);}
    static Bundle run(Instrumentation runner){return new StudioChecks(runner).run();}
    private Bundle run(){
        context=runner.getTargetContext();prefs=context.getSharedPreferences("ui_checks",0);Map<String,?> original=prefs.getAll();
        output=new File(context.getFilesDir(),"qa-0.5.0");output.mkdirs();Bundle result=new Bundle();
        try{
            sync(()->{prefs.edit().clear().putBoolean("night",false).putBoolean("motion",false).putBoolean("studio_guided",true).commit();models();layouts();});
            runtime();result.putBoolean("passed",true);result.putString("result","PASS: "+checks+" studio checks, "+renders+" renders; keyboard, rotation, selection, undo and recovery");
        }catch(Throwable t){result.putBoolean("passed",false);result.putString("result",android.util.Log.getStackTraceString(t));}
        finally{sync(()->{if(live!=null)live.finish();SharedPreferences.Editor e=prefs.edit().clear();for(Map.Entry<String,?> entry:original.entrySet()){Object v=entry.getValue();String k=entry.getKey();if(v instanceof String)e.putString(k,(String)v);else if(v instanceof Boolean)e.putBoolean(k,(Boolean)v);else if(v instanceof Integer)e.putInt(k,(Integer)v);else if(v instanceof Long)e.putLong(k,(Long)v);else if(v instanceof Float)e.putFloat(k,(Float)v);else if(v instanceof Set)e.putStringSet(k,new HashSet<>((Set<String>)v));}e.commit();});}
        return result;
    }
    private Scene sample(){
        Scene s=Scene.load(prefs);s.pages.get(0).layout=3;s.pages.get(0).autoName=false;s.pages.get(0).name="我的书桌 · 一个用于检查窄屏换行与省略的很长页面名称";
        s.pages.get(0).slots[1].setType("weather");s.pages.get(0).slots[2].setType("todo");TodoItems.add(s.pages.get(0).slots[2],"保留事项");
        s.home=s.pages.get(0).id;s.ownNightColors=true;return s;
    }
    private void models(){
        Scene s=sample();Scene.Page page=s.pages.get(0);Scene.Component c=page.slots[0];
        Scene.put(s.nightTheme,"time",0xffff6622);Scene.put(c.theme,"time",0xff44ff88);
        check(s.color(page,c,"time",true,false)==0xffff6622,"day override does not cover night");
        Scene.put(c.nightTheme,"time",0xffdd7799);check(s.color(page,c,"time",true,false)==0xffdd7799,"local night override");
        Scene copy=s.copy();check(Boolean.TRUE.equals(copy.ownNightColors),"night enabled state follows snapshot");
        check(copy.color(copy.pages.get(0),copy.pages.get(0).slots[0],"time",true,false)==0xffdd7799,"night override follows snapshot");
        try{JSONObject legacy=new JSONObject(s.json());legacy.put("version",3);Scene old=Scene.parse(legacy.toString());check(old.color(old.pages.get(0),old.pages.get(0).slots[0],"time",true,false)==0xff44ff88,"legacy local night appearance preserved");}catch(JSONException e){throw new AssertionError(e);}
        Scene.Component todo=page.slots[2];todo.setType("clock");todo.setType("todo");check(TodoItems.all(todo).length()==1,"component switch retains tasks");
        page.layout=0;Scene restored=s.copy();restored.pages.get(0).layout=3;check(TodoItems.all(restored.pages.get(0).slots[2]).length()==1,"hidden layout region retains data");
        s.save(prefs);MainActivity editor=new MainActivity();editor.prepareForCheck(context);
        String before=editor.draft.json();Scene.put(editor.draft.pages.get(0).slots[0].options,"scale",110);call(editor,"changed");
        editor.beginEdit();for(int scale:new int[]{112,115,120}){Scene.put(editor.draft.pages.get(0).slots[0].options,"scale",scale);call(editor,"changed");}editor.endEdit();
        EditHistory history=(EditHistory)get(editor,"history");String previous=history.undo();call(editor,"restoreEditorState",new Class[]{String.class},previous);
        check(editor.draft.pages.get(0).slots[0].options.optInt("scale")==110,"one undo reverses complete slider drag");
        previous=history.undo();call(editor,"restoreEditorState",new Class[]{String.class},previous);check(editor.draft.json().equals(before),"second undo restores previous model");
        prefs.edit().putString("scene_saved_keep",editor.draft.json()).commit();
        call(editor,"saveRecoveryPoint",new Class[]{String.class},"测试恢复点");String points=prefs.getString("studio_recovery","");
        prefs.edit().remove("scene_saved_keep").commit();
        MainActivity reopened=new MainActivity();reopened.prepareForCheck(context);
        try{String state=new JSONArray(points).getJSONObject(0).getString("state");call(reopened,"restoreEditorState",new Class[]{String.class},state);check(prefs.contains("scene_saved_keep"),"persistent recovery restores deleted snapshot");}catch(JSONException e){throw new AssertionError(e);}
        sample().save(prefs);
    }
    private void draw(View view,int w,int h,String name){
        view.measure(View.MeasureSpec.makeMeasureSpec(w,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(h,View.MeasureSpec.EXACTLY));view.layout(0,0,w,h);view.getViewTreeObserver().dispatchOnPreDraw();
        Bitmap image=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);view.draw(new Canvas(image));renders++;
        if(name!=null)try(FileOutputStream stream=new FileOutputStream(new File(output,name+".png"))){image.compress(Bitmap.CompressFormat.PNG,100,stream);}catch(IOException e){throw new AssertionError(e);}image.recycle();
    }
    private void bounds(View view){
        if(!(view instanceof ViewGroup))return;ViewGroup group=(ViewGroup)view;
        for(int i=0;i<group.getChildCount();i++){
            View child=group.getChildAt(i);if(child.getVisibility()!=View.VISIBLE)continue;
            if(!(group instanceof HorizontalScrollView))check(child.getLeft()>=-1&&child.getRight()<=group.getWidth()+1,"child width "+child.getClass().getSimpleName()+" in "+group.getClass().getSimpleName()+" "+child.getLeft()+".."+child.getRight()+"/"+group.getWidth());
            if(!(group instanceof ScrollView))check(child.getTop()>=-1&&child.getBottom()<=group.getHeight()+1,"child height "+child.getClass().getSimpleName()+" in "+group.getClass().getSimpleName()+" tag="+group.getTag()+" "+child.getTop()+".."+child.getBottom()+"/"+group.getHeight());
            bounds(child);
        }
    }
    private void layouts(){
        MainActivity editor=new MainActivity();editor.prepareForCheck(context);
        int[][] windows={{320,480},{360,500},{400,820},{820,400},{876,320},{700,980},{980,700},{820,1088},{580,620},{1600,900}};
        float density=context.getResources().getDisplayMetrics().density;
        for(float font:new float[]{1,1.3f,2.08f})for(int[] window:windows)for(boolean browse:new boolean[]{true,false})for(int panel=0;panel<3;panel++){
            activeCase=window[0]+"x"+window[1]+" font="+font+" browse="+browse+" panel="+panel;
            prefs.edit().putFloat("uiFontScale",font).commit();set(editor,"browsingPages",browse);set(editor,"studioPanel",panel);
            String name=font==1&&panel==0&&!browse?"editor-"+window[0]+"x"+window[1]:null;
            View root=editor.createUi(window[0],window[1]);draw(root,Math.round(window[0]*density),Math.round(window[1]*density),name);try{bounds(root);}catch(AssertionError e){draw(root,Math.round(window[0]*density),Math.round(window[1]*density),"failure-layout");throw e;}
            View body=root.findViewWithTag("studio:body");check(body!=null&&((View)body.getParent()).getHeight()>30*density,"editor remains scrollable");
            ClockFace face=face(root);check(face!=null&&face.getHeight()>0,"preview remains visible");
        }
        prefs.edit().putFloat("uiFontScale",1).commit();
        for(int[] size:new int[][]{{400,820},{820,400},{980,700},{700,980}})for(boolean horizontal:new boolean[]{false,true})for(boolean navigation:new boolean[]{false,true}){
            int w=size[0],h=size[1];activeCase="fold "+w+"x"+h+" horizontal="+horizontal+" navigation="+navigation;Rect fold=horizontal?new Rect(0,Math.round(h*.45f*density),Math.round(w*density),Math.round(h*.45f*density)+8):new Rect(Math.round(w*.43f*density),0,Math.round(w*.43f*density)+8,Math.round(h*density));
            editor.foldForCheck(fold);editor.navigationForCheck(navigation);View root=editor.createUi(w,h);draw(root,Math.round(w*density),Math.round(h*density),!navigation?"fold-"+w+"x"+h+"-"+horizontal:null);bounds(root);
            ClockFace preview=face(root);Rect frame=position(preview,root);check(!Rect.intersects(frame,fold),"preview avoids hinge");
            View body=root.findViewWithTag("studio:body");Rect detail=position((View)body.getParent(),root);check(!Rect.intersects(detail,fold),"editor avoids hinge");
        }
        for(boolean vertical:new boolean[]{false,true}){
            Rect fold=vertical?new Rect(UiKit.dp(context,300),0,UiKit.dp(context,304),UiKit.dp(context,980)):new Rect(0,UiKit.dp(context,440),UiKit.dp(context,700),UiKit.dp(context,444));
            editor.foldForCheck(fold);editor.navigationForCheck(false);View resized=editor.createUi(700,980);draw(resized,UiKit.dp(context,700),UiKit.dp(context,500),"fold-resized-"+vertical);bounds(resized);
            check(!Rect.intersects(position((View)resized.findViewWithTag("studio:body").getParent(),resized),fold),"resized editor avoids hinge");
        }
        Rect lowFold=new Rect(0,UiKit.dp(context,120),UiKit.dp(context,700),UiKit.dp(context,124));editor.foldForCheck(lowFold);set(editor,"browsingPages",true);
        View lower=editor.createUi(700,800);draw(lower,UiKit.dp(context,700),UiKit.dp(context,300),"fold-low-ime");bounds(lower);check(!Rect.intersects(position((View)lower.findViewWithTag("studio:body").getParent(),lower),lowFold),"low hinge IME uses correct lower region coordinates");
        editor.foldForCheck(null);editor.navigationForCheck(false);
        set(editor,"browsingPages",false);set(editor,"studioPanel",2);
        View imeSized=editor.createUi(400,820);draw(imeSized,UiKit.dp(context,400),UiKit.dp(context,260),"editor-ime-small");bounds(imeSized);
        check(((View)imeSized.findViewWithTag("studio:body").getParent()).getHeight()>=UiKit.dp(context,48),"short IME editor retains usable scroll area");
        set(editor,"portraitStyleScreen",true);for(int[] size:new int[][]{{320,480},{820,400},{700,980}}){View root=editor.createUi(size[0],size[1]);draw(root,UiKit.dp(context,size[0]),UiKit.dp(context,size[1]),"selector-"+size[0]+"x"+size[1]);bounds(root);}
    }
    private Rect position(View v,View root){Rect rect=new Rect(0,0,v.getWidth(),v.getHeight());((ViewGroup)root).offsetDescendantRectToMyCoords(v,rect);return rect;}
    private ClockFace face(View view){if(view instanceof ClockFace)return(ClockFace)view;if(view instanceof ViewGroup)for(int i=0;i<((ViewGroup)view).getChildCount();i++){ClockFace found=face(((ViewGroup)view).getChildAt(i));if(found!=null)return found;}return null;}
    private View text(View root,String value){if(root instanceof TextView&&((TextView)root).getText().toString().equals(value))return root;if(root instanceof ViewGroup)for(int i=0;i<((ViewGroup)root).getChildCount();i++){View found=text(((ViewGroup)root).getChildAt(i),value);if(found!=null)return found;}return null;}
    private void runtime()throws Exception{
        try{JSONObject old=new JSONObject(sample().json());old.put("version",3);old.remove("ownNightColors");prefs.edit().putString(Scene.KEY,old.toString()).putBoolean("nightOwnColors",true).putFloat("uiFontScale",1).commit();}catch(JSONException e){throw new AssertionError(e);}
        live=(MainActivity)runner.startActivitySync(new Intent(context,MainActivity.class).putExtra("uiCheck",true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));runner.waitForIdleSync();
        sync(()->{check(Boolean.TRUE.equals(live.draft.ownNightColors),"legacy night setting survives creation and resume");check(!((EditHistory)get(live,"history")).canUndo(),"normalization does not create phantom history");live.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);live.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);});
        SystemClock.sleep(700);runner.waitForIdleSync();
        sync(()->{set(live,"browsingPages",false);set(live,"studioPanel",2);call(live,"show");text(live.getWindow().getDecorView(),"自定义").performClick();});runner.waitForIdleSync();SystemClock.sleep(200);
        sync(()->{EditText input=live.colorEditorForCheck().hexInput();input.requestFocus();input.setText("#48A1F2");live.getSystemService(android.view.inputmethod.InputMethodManager.class).showSoftInput(input,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);});
        SystemClock.sleep(900);runner.waitForIdleSync();
        sync(()->{EditText input=live.colorEditorForCheck().hexInput();Rect visible=new Rect();check(live.getWindow().getDecorView().getRootWindowInsets().isVisible(WindowInsets.Type.ime()),"real IME is visible");check(input.getGlobalVisibleRect(visible)&&visible.height()==input.getHeight(),"HEX visible above keyboard");check(face(live.getWindow().getDecorView()).getHeight()>0,"keyboard retains preview");draw(live.getWindow().getDecorView(),live.getWindow().getDecorView().getWidth(),live.getWindow().getDecorView().getHeight(),"runtime-keyboard-portrait");live.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);});
        SystemClock.sleep(900);runner.waitForIdleSync();
        sync(()->{check(live.colorEditorForCheck().hexInput().getText().toString().equals("#48A1F2"),"color draft survives rotation");live.getSystemService(android.view.inputmethod.InputMethodManager.class).hideSoftInputFromWindow(live.colorEditorForCheck().hexInput().getWindowToken(),0);call(live,"openSelector",new Class[]{boolean.class},true);});
        runner.waitForIdleSync();
        sync(()->{View type=live.getWindow().getDecorView().findViewWithTag("component:weather");check(type!=null,"explicit component selector");type.performClick();check(live.draft.pages.get(0).slots[0].type.equals("weather"),"component selector replaces current region");call(live,"undoEdit");check(live.draft.pages.get(0).slots[0].type.equals("clock"),"undo returns previous component");});
        sync(()->{int count=live.draft.pages.size();String home=live.draft.home;call(live,"showPageMenu");AlertDialog menu=(AlertDialog)get(live,"studioDialog");ListView list=menu.getListView();int last=list.getCount()-1;list.performItemClick(null,last,list.getAdapter().getItemId(last));check(live.draft.pages.size()==count-1,"page menu deletes page");call(live,"undoEdit");check(live.draft.pages.size()==count&&live.draft.home.equals(home),"undo restores page position and home identity");});
        sync(()->call(live,"showLayoutPicker",new Class[]{boolean.class},true));runner.waitForIdleSync();
        sync(()->{InputDialog picker=(InputDialog)get(live,"inputDialog");check(picker!=null&&picker.isShowing(),"visual layout chooser");View choice=text(picker.getWindow().getDecorView(),"使用双栏");check(choice!=null,"layout card has explicit action");int old=live.draft.pages.size();choice.performClick();check(live.draft.pages.size()==old+1&&live.draft.pages.get(old).layout==1,"layout selection creates complete page");call(live,"undoEdit");check(live.draft.pages.size()==old,"undo removes added page");});
        Instrumentation.ActivityMonitor monitor=runner.addMonitor(ClockActivity.class.getName(),null,false);
        sync(()->{set(live,"pageId",live.draft.pages.get(1).id);set(live,"previewNight",true);call(live,"launchFullscreenPreview");});
        ClockActivity preview=(ClockActivity)runner.waitForMonitorWithTimeout(monitor,5000);runner.removeMonitor(monitor);check(preview!=null,"fullscreen opened");runner.waitForIdleSync();
        sync(()->{ClockFace f=face(preview.getWindow().getDecorView());check(Boolean.TRUE.equals(f.nightPreview),"fullscreen continues selected night preview");check(f.pageIdForEditor().equals(live.draft.pages.get(1).id),"fullscreen continues selected page");preview.finish();});
    }
}
